<?php
// auth_check.php - Reusable authentication checker

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to check if user is logged in
function isLoggedIn() {
    return isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true;
}

// Function to check if user has required role
function hasRole($required_role) {
    return isset($_SESSION['role']) && $_SESSION['role'] === $required_role;
}

// Function to require authentication
function requireAuth($required_role = null) {
    if (!isLoggedIn()) {
        // Not logged in - redirect to login
        // FIXED: Correct path to login
        header('Location: ../LOGIN/login.html');
        exit();
    }
    
    // Check role if specified
    if ($required_role !== null && !hasRole($required_role)) {
        // Wrong role - redirect to login
        session_destroy();
        header('Location: ../LOGIN/login.html?error=unauthorized');
        exit();
    }
}

// Optional: Session timeout (30 minutes of inactivity)
function checkSessionTimeout($timeout = 1800) {
    if (isset($_SESSION['login_time'])) {
        $elapsed = time() - $_SESSION['login_time'];
        if ($elapsed > $timeout) {
            session_destroy();
            header('Location: ../LOGIN/login.html?error=timeout');
            exit();
        }
    }
    $_SESSION['login_time'] = time(); // Update last activity time
}

?>