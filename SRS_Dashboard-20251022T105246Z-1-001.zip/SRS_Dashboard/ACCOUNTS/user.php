<?php
// Require authentication with 'user' role
require_once 'auth_check.php';
requireAuth('user');
checkSessionTimeout();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SRS - NAIA Terminal 1 Dashboard</title>
    <link rel="icon" type="images/png" href="../Logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="../Logo.png" alt="Logo">
            </div>
            <div class="sidebar-title">SRS - NAIA<br>TERMINAL 1</div>
            <button class="sidebar-close" id="sidebarClose">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <nav class="nav-section">
            <a href="#" class="nav-item active" data-page="dashboard">
                <div class="nav-icon">
                    <i class="fas fa-tachometer-alt"></i>
                </div>
                <span>Dashboard</span>
            </a>
            <a href="#" class="nav-item" data-page="dailyReport">
                <div class="nav-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <span>Daily Report</span>
            </a>
            <a href="#" class="nav-item" data-page="interception">
                <div class="nav-icon">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <span>Interception</span>
            </a>
            <a href="#" class="nav-item" data-page="faqs">
                <div class="nav-icon">
                    <i class="fas fa-question-circle"></i>
                </div>
                <span>FAQs</span>
            </a>
            
            <div class="nav-divider"></div>
            
            <a href="#" class="nav-item" data-page="help">
                <div class="nav-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <span>Help Center</span>
            </a>
            <a href="#" class="nav-item" data-page="notifications">
                <div class="nav-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <span>Notifications</span>
            </a>
            <a href="#" class="nav-item" data-page="logout">
                <div class="nav-icon">
                    <i class="fas fa-sign-out-alt"></i>
                </div>
                <span>Logout</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <div class="hamburger"></div>
                </button>
                <?php
                // Get user's full name from session, fallback to username if not set
                $displayName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : $_SESSION['username'];
                $firstName = explode(' ', $displayName)[0]; // Get first name for mobile
                ?>
                <h1 class="welcome-text">Welcome, <?php echo htmlspecialchars($displayName); ?></h1>
                <h1 class="mobile-welcome">Welcome, <?php echo htmlspecialchars($firstName); ?></h1>
            </div>
            <div class="header-actions">
                <button class="settings-btn" title="Settings">
                    <i class="fas fa-cog"></i>
                </button>
                <?php
                // Generate initials from full name
                $nameParts = explode(' ', $displayName);
                $initials = '';
                foreach ($nameParts as $part) {
                    if (!empty($part)) {
                        $initials .= strtoupper(substr($part, 0, 1));
                    }
                }
                // Limit to 2 characters
                $initials = substr($initials, 0, 2);
                ?>
                <div class="user-avatar" title="Profile"><?php echo htmlspecialchars($initials); ?></div>
            </div>
        </header>

        <!-- Content Area -->
        <div class="content">
            <!-- Dashboard Content -->
            <div id="dashboardContent" class="page-content active">
                <!-- Stats Section -->
                <section class="stats-section">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-users" style="color: var(--primary-blue); font-size: 20px;"></i>
                        </div>
                        <div>
                            <div class="section-title">Personnel Overview</div>
                            <div class="section-subtitle">Current personnel assignment for NAIA Terminal 1</div>
                        </div>
                    </div>

                    <div class="stats-grid" id="personnelStatsGrid">
                        <div class="stat-card">
                            <div class="stat-label">Terminal Chief</div>
                            <div class="stat-value" id="userTerminalChief">Captain Chris</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Total Personnel</div>
                            <div class="stat-value" id="userTotalPersonnel">55</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Total Number of SSO</div>
                            <div class="stat-value" id="userTotalSSO">42</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Airport Clerk</div>
                            <div class="stat-value" id="userAdmins">2</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Shift-in-Charges</div>
                            <div class="stat-value" id="userShiftInCharges">4</div>
                        </div>
                        <div class="stat-card">
                            <div class="stat-label">Checkpoint Supervisors</div>
                            <div class="stat-value" id="userCheckpointSupervisors">6</div>
                        </div>
                        <div class="stat-card male">
                            <div class="stat-label">Male SSO</div>
                            <div class="stat-value" id="userSsoMale">24</div>
                        </div>
                        <div class="stat-card female">
                            <div class="stat-label">Female SSO</div>
                            <div class="stat-value" id="userSsoFemale">6</div>
                        </div>
                    </div>

                    <!-- Update indicator -->
                    <div class="update-indicator" id="updateIndicator" style="display: none;">
                        <i class="fas fa-sync-alt fa-spin"></i>
                        <span>Personnel data updated</span>
                    </div>
                </section>

                <!-- Activity Section -->
                <section class="activity-section">
                    <div class="activity-header">
                        <div class="activity-icon">
                            <i class="fas fa-chart-line" style="color: var(--primary-blue); font-size: 18px;"></i>
                        </div>
                        <div class="activity-title">Recent Activity</div>
                        <div class="activity-subtitle">Your recent activity - use date selection, search and filters to find specific reports</div>
                    </div>

                    <div class="activity-controls" id="dashboardActivityControls">
                        <input type="date" id="dashboardDate" class="date-input">
                        <input type="text" id="dashboardSearch" class="search-input" placeholder="Search by date, passenger, flight, item, or shift...">
                        <select id="dashboardReportType" class="filter-select">
                            <option value="">All Report Types</option>
                            <option value="daily">Daily Report</option>
                            <option value="interception">Interception Report</option>
                        </select>
                    </div>

                    <div class="reports-showing" id="dashboardShowing">
                        Loading reports...
                    </div>

                    <div id="dashboardActivityItems">
                        <!-- Reports will be loaded here dynamically -->
                    </div>

                    <div class="activity-footer">
                        <div class="activity-footer-text">You can edit your reports for up to 24 hours after submission.</div>
                    </div>
                </section>
            </div>
            <!-- Daily Report Content -->
            <div id="dailyReportContent" class="page-content">
                <!-- Report Header -->
                <section class="report-header-section">
                    <div class="report-title-bar">
                        <div class="report-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <h2 class="report-title">Daily Operational Data Report</h2>
                    </div>
                </section>

                <form id="dailyReportForm" method="POST" enctype="multipart/form-data">
                    <section class="report-header-section">
                        <div class="form-grid-3">
                            <div class="form-group">
                                <label>Date</label>
                                <input type="date" id="reportDate" name="report_date" class="date-input" required>
                            </div>
                            <div class="form-group">
                                <label>Shift</label>
                                <select class="form-select" name="shift" required>
                                    <option value="">Select shift</option>
                                    <option value="1st Shift">1st Shift</option>
                                    <option value="2nd Shift">2nd Shift</option>
                                    <option value="3rd Shift">3rd Shift</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Team</label>
                                <select class="form-select" name="team" required>
                                    <option value="">Select team</option>
                                    <option value="Alpha">Team Alpha</option>
                                    <option value="Bravo">Team Bravo</option>
                                    <option value="Charlie">Team Charlie</option>
                                    <option value="Delta">Team Delta</option>
                                </select>
                            </div>
                        </div>
                    </section>

                    <!-- Personnel Data Section -->
                    <section class="report-section">
                        <div class="section-header">
                            <div class="section-icon">
                                <i class="fas fa-user-tie" style="color: var(--primary-blue); font-size: 18px;"></i>
                            </div>
                            <div>
                                <div class="section-title">Personnel Data</div>
                            </div>
                        </div>
                        
                        <div class="form-grid-2">
                            <div class="form-group">
                                <label>Screeners on Duty</label>
                                <input type="number" class="form-input" name="screeners_on_duty" min="0" placeholder="0" required>
                            </div>
                            <div class="form-group">
                                <label>Screeners Off</label>
                                <input type="number" class="form-input" name="screeners_off" min="0" placeholder="0" required>
                            </div>
                            <div class="form-group">
                                <label>Screeners on Leave</label>
                                <input type="number" class="form-input" name="screeners_on_leave" min="0" placeholder="0" required>
                            </div>
                            <div class="form-group">
                                <label>Screeners Absent</label>
                                <input type="number" class="form-input" name="screeners_absent" min="0" placeholder="0" required>
                            </div>
                        </div>
                    </section>

                    <!-- Flight Summary Section -->
                    <section class="report-section">
                        <div class="section-header">
                            <div class="section-icon">
                                <i class="fas fa-plane" style="color: var(--primary-blue); font-size: 18px;"></i>
                            </div>
                            <div>
                                <div class="section-title">Flight Summary</div>
                            </div>
                        </div>
                        
                        <div class="summary-cards">
                            <div class="summary-card">
                                <div class="summary-label">Domestic Flights</div>
                                <div class="form-grid-2">
                                    <div class="form-group">
                                        <label>Departing Flights</label>
                                        <input type="number" class="form-input" name="domestic_departing_flights" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Passengers</label>
                                        <input type="number" class="form-input" name="domestic_passengers" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Cancelled Flights</label>
                                        <input type="number" class="form-input" name="domestic_cancelled_flights" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Affected Passengers</label>
                                        <input type="number" class="form-input" name="domestic_affected_passengers" value="0" min="0">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="summary-card">
                                <div class="summary-label">International Flights</div>
                                <div class="form-grid-2">
                                    <div class="form-group">
                                        <label>Departing Flights</label>
                                        <input type="number" class="form-input" name="international_departing_flights" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Passengers</label>
                                        <input type="number" class="form-input" name="international_passengers" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Cancelled Flights</label>
                                        <input type="number" class="form-input" name="international_cancelled_flights" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Affected Passengers</label>
                                        <input type="number" class="form-input" name="international_affected_passengers" value="0" min="0">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <!-- Prohibited Items Section -->
                    <section class="report-section">
                        <div class="section-header">
                            <div class="section-icon">
                                <i class="fas fa-ban" style="color: var(--primary-blue); font-size: 18px;"></i>
                            </div>
                            <div>
                                <div class="section-title">Prohibited Items (Enter quantities only)</div>
                            </div>
                        </div>
                        
                        <div class="summary-cards">
                            <div class="summary-card">
                                <div class="form-grid-2">
                                    <div class="form-group">
                                        <label>Blunt instruments</label>
                                        <input type="number" class="form-input" name="blunt_instruments" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Liquid aerosols and gels</label>
                                        <input type="number" class="form-input" name="liquid_aerosols_gels" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Objects with sharp point and sharp edges</label>
                                        <input type="number" class="form-input" name="sharp_objects" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Workers tool</label>
                                        <input type="number" class="form-input" name="workers_tools" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Explosive and incendiary substance and devices</label>
                                        <input type="number" class="form-input" name="explosives_incendiary" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Stunning devices</label>
                                        <input type="number" class="form-input" name="stunning_devices" value="0" min="0">
                                    </div>
                                    <div class="form-group">
                                        <label>Chemical and toxic substances</label>
                                        <input type="number" class="form-input" name="chemical_toxic" value="0" min="0">
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="form-group" style="margin-top: 20px;">
                            <label>Additional Notes</label>
                            <textarea class="form-textarea" name="additional_notes" rows="4" placeholder="Any additional observations or incidents..." inputmode="text" autocomplete="off"></textarea>
                        </div>
                    </section>

                    <!-- Upload Section with Image Preview -->
                    <section class="report-section">
                        <div class="section-header">
                            <div class="section-icon">
                                <i class="fas fa-camera" style="color: var(--primary-blue); font-size: 18px;"></i>
                            </div>
                            <div>
                                <div class="section-title">Upload Images (2-4 images)</div>
                            </div>
                        </div>
                        
                        <div class="upload-area">
                            <div class="upload-preview" id="imagePreviewContainer" style="display: none; margin-bottom: 16px;">
                                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 12px;" id="imagePreviewGrid"></div>
                            </div>
                            
                            <div class="upload-dropzone" id="imageDropzone">
                                <i class="fas fa-cloud-upload-alt"></i>
                                <p>Choose files or drag and drop</p>
                                <span id="uploadStatus">No file chosen</span>
                                <input type="file" id="reportImages" name="report_images[]" multiple accept="image/jpeg,image/jpg,image/png,image/gif" style="display: none;">
                            </div>
                            
                            <div class="info-note" style="margin-top: 12px;">
                                <i class="fas fa-info-circle"></i>
                                <span>Accepted formats: JPG, PNG, GIF. Max size: 5MB per image. Upload 2-4 images (Required).</span>
                            </div>
                        </div>
                    </section>

                    <!-- Submit Section -->
                    <section class="submit-section">
                        <button type="button" class="btn-submit" id="dailyReportSubmit">
                            <i class="fas fa-paper-plane"></i> Submit Daily Report
                        </button>
                    </section>
                </form>
            </div>
            <!-- Interception Content -->
<div id="interceptionContent" class="page-content">
    <form id="interceptionReportForm" method="POST" enctype="multipart/form-data">
        <section class="report-header-section">
            <div class="report-title-bar">
                <div class="report-icon" style="background: var(--accent-red);">
                    <i class="fas fa-shield-alt"></i>
                </div>
                <h2 class="report-title">High-Priority Interception Report</h2>
            </div>
            
            <div class="form-grid-3">
                <div class="form-group">
                    <label>Date</label>
                    <input type="date" id="interceptionDate" name="report_date" class="date-input" required>
                </div>
                <div class="form-group">
                    <label>Shift</label>
                    <select class="form-select" name="shift" id="interceptionShift" required>
                        <option value="">Select shift</option>
                        <option value="1st Shift">1st Shift</option>
                        <option value="2nd Shift">2nd Shift</option>
                        <option value="3rd Shift">3rd Shift</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Team</label>
                    <select class="form-select" name="team" id="interceptionTeam" required>
                        <option value="">Select team</option>
                        <option value="Alpha">Team Alpha</option>
                        <option value="Bravo">Team Bravo</option>
                        <option value="Charlie">Team Charlie</option>
                        <option value="Delta">Team Delta</option>
                    </select>
                </div>
            </div>
        </section>

        <!-- Personnel Data Section -->
        <section class="report-section">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-user-tie" style="color: var(--primary-blue); font-size: 18px;"></i>
                </div>
                <div>
                    <div class="section-title">Personal Data</div>
                </div>
            </div>
            
            <div class="form-grid-2">
                <div class="form-group">
                    <label>Passenger Name</label>
                    <input type="text" class="form-input" name="passenger_name" id="passengerName" placeholder="Enter passenger's name" required>
                </div>
                <div class="form-group">
                    <label>Occupation</label>
                    <input type="text" class="form-input" name="occupation" id="occupation" placeholder="Enter passenger's occupation" required>
                </div>
            </div>
        </section>

        <!-- Flight Details Section -->
        <section class="report-section">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-plane-departure" style="color: var(--primary-blue); font-size: 18px;"></i>
                </div>
                <div>
                    <div class="section-title">Flight Details</div>
                </div>
            </div>
            
            <div class="form-grid-2">
                <div class="form-group">
                    <label>Flight Number</label>
                    <input type="text" class="form-input" name="flight_number" id="flightNumber" placeholder="E.g., PR318, CEB456" required>
                </div>
                <div class="form-group">
                    <label>Destination</label>
                    <input type="text" class="form-input" name="destination" id="destination" placeholder="E.g., Manila, Cebu, Singapore">
                </div>
            </div>
        </section>

        <!-- Intercepted Item Details -->
        <section class="report-section">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-exclamation-triangle" style="color: var(--primary-blue); font-size: 18px;"></i>
                </div>
                <div>
                    <div class="section-title">Intercepted Item Details</div>
                </div>
            </div>
            
            <div class="form-grid-2">
                <div class="form-group">
                    <label>Intercepted Item</label>
                    <select class="form-input" name="intercepted_item" id="interceptedItem" required>
                        <option value="">Select intercepted item</option>
                        <option value="Suspected Ammo">Suspected Ammo</option>
                        <option value="Suspected Empty Shell">Suspected Empty Shell</option>
                        <option value="Suspected Firearms">Suspected Firearms</option>
                        <option value="Suspected Firearms Parts">Suspected Firearms Parts and Components</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Quantity</label>
                    <input type="number" class="form-input" name="quantity" id="quantity" value="1" min="1">
                </div>
            </div>
        </section>

        <!-- Intercepted By Section -->
        <section class="report-section">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-user-check" style="color: var(--primary-blue); font-size: 18px;"></i>
                </div>
                <div>
                    <div class="section-title">Intercepted By</div>
                </div>
            </div>
            
            <div class="form-grid-2">
                <div class="form-group">
                    <label>X-ray Operator</label>
                    <input type="text" class="form-input" name="xray_operator" id="xrayOperator" placeholder="Name of X-ray operator">
                </div>
                <div class="form-group">
                    <label>Baggage Inspector</label>
                    <input type="text" class="form-input" name="baggage_pusher" id="baggagePusher" placeholder="Name of baggage handler">
                </div>
            </div>
            
            <div class="form-group">
                <label>Remarks</label>
                <textarea class="form-textarea" name="remarks" id="remarks" rows="3" placeholder="Action taken"></textarea>
            </div>
        </section>

        <!-- Evidence Photos Section -->
        <section class="report-section">
            <div class="section-header">
                <div class="section-icon">
                    <i class="fas fa-camera" style="color: var(--primary-blue); font-size: 18px;"></i>
                </div>
                <div>
                    <div class="section-title">Evidence Photos (2-4 images)</div>
                </div>
            </div>
            
            <div class="info-note">
                <i class="fas fa-info-circle"></i>
                <span>Note: This interception data will automatically be included in your Daily Operational Report. High-priority items require immediate reporting and documentation.</span>
            </div>
            
            <div class="upload-area">
                <div class="upload-dropzone interception-upload">
                    <i class="fas fa-cloud-upload-alt"></i>
                    <p>Choose files or drag and drop</p>
                    <span>No file chosen</span>
                    <input type="file" multiple accept="image/jpeg,image/jpg,image/png,image/gif" style="display: none;">
                </div>
                
                <div class="info-note" style="margin-top: 12px;">
                    <i class="fas fa-info-circle"></i>
                    <span>Accepted formats: JPG, PNG, GIF. Max size: 5MB per image. Upload 2-4 images.</span>
                </div>
            </div>
        </section>

        <!-- Submit Section -->
        <section class="submit-section">
            <button type="button" class="btn-submit" id="interceptionReportSubmit">
                <i class="fas fa-exclamation-circle"></i> Submit Interception Report
            </button>
        </section>
    </form>
</div>

            <!-- FAQs Content -->
            <div id="faqsContent" class="page-content">
                <!-- FAQs Header -->
                <section class="report-header-section">
                    <div class="report-title-bar">
                        <div class="report-icon" style="background: var(--notif-green);">
                            <i class="fas fa-question-circle"></i>
                        </div>
                        <h2 class="report-title">Passenger Frequently Asked Questions</h2>
                    </div>
                </section>

                <!-- FAQ Items -->
                <section class="faqs-container">
                    <div class="faq-item">
                        <div class="faq-question">
                            <i class="fas fa-chevron-right faq-icon"></i>
                            <h3>What items are prohibited in carry-on luggage?</h3>
                        </div>
                        <div class="faq-answer">
                            <p>Prohibited items include: liquids over 100ml, sharp objects, weapons, firearms, explosive materials, and flammable substances. Check the full list in the prohibited items section below.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <i class="fas fa-chevron-right faq-icon"></i>
                            <h3>Can I bring medications in my carry-on?</h3>
                        </div>
                        <div class="faq-answer">
                            <p>Yes, essential medications are allowed. Prescription medications should be in original containers with labels. Liquid medications over 100ml require separate screening.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <i class="fas fa-chevron-right faq-icon"></i>
                            <h3>What is the liquid rule for carry-on baggage?</h3>
                        </div>
                        <div class="faq-answer">
                            <p>Liquids must be in containers of 100ml or less, placed in a clear, resealable plastic bag (maximum 1 liter). Each passenger is allowed one such bag.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <i class="fas fa-chevron-right faq-icon"></i>
                            <h3>Can I bring food items through security?</h3>
                        </div>
                        <div class="faq-answer">
                            <p>Solid food items are generally allowed. Liquids, gels, or spreads (like peanut butter) must follow the 100ml rule. Baby food and formula are exempt from liquid restrictions.</p>
                        </div>
                    </div>

                    <div class="faq-item">
                        <div class="faq-question">
                            <i class="fas fa-chevron-right faq-icon"></i>
                            <h3>What should I do if my item is confiscated?</h3>
                        </div>
                        <div class="faq-answer">
                            <p>Confiscated items cannot be returned. You may have the option to dispose of the item, store it (if available), or return it to your vehicle before re-entering security.</p>
                        </div>
                    </div>
                </section>

                <!-- Prohibited Items Reference Guide -->
                <section class="report-section">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-ban" style="color: var(--accent-red); font-size: 18px;"></i>
                        </div>
                        <div>
                            <div class="section-title">Prohibited Items Reference Guide</div>
                        </div>
                    </div>
                    
                    <div class="prohibited-categories">
                        <div class="category-card">
                            <h4 class="category-title">Weapons & Sharp Objects</h4>
                            <ul class="category-list">
                                <li>Knives</li>
                                <li>Scissors over 6cm</li>
                                <li>Razor blades</li>
                                <li>Martial arts equipment</li>
                                <li>Firearms</li>
                                <li>Ammunition</li>
                            </ul>
                        </div>
                        
                        <div class="category-card">
                            <h4 class="category-title">Liquids & Gels</h4>
                            <ul class="category-list">
                                <li>Containers over 100ml</li>
                                <li>Alcoholic beverages over 70% ABV</li>
                                <li>Paints</li>
                                <li>Aerosols</li>
                            </ul>
                        </div>
                        
                        <div class="category-card">
                            <h4 class="category-title">Explosive & Flammable</h4>
                            <ul class="category-list">
                                <li>Fireworks</li>
                                <li>Flares</li>
                                <li>Lighter fluid</li>
                                <li>Gasoline</li>
                                <li>Propane cylinders</li>
                                <li>Matches (strike-anywhere)</li>
                            </ul>
                        </div>
                        
                        <div class="category-card">
                            <h4 class="category-title">Tools & Equipment</h4>
                            <ul class="category-list">
                                <li>Drills</li>
                                <li>Saws</li>
                                <li>Hammers</li>
                                <li>Crowbars</li>
                                <li>Large tools over 7 inches</li>
                            </ul>
                        </div>
                        
                        <div class="category-card">
                            <h4 class="category-title">Sports Equipment</h4>
                            <ul class="category-list">
                                <li>Baseball bats</li>
                                <li>Hockey sticks</li>
                                <li>Golf clubs</li>
                                <li>Pool cues</li>
                                <li>Ski poles</li>
                            </ul>
                        </div>
                        
                        <div class="category-card">
                            <h4 class="category-title">Other Items</h4>
                            <ul class="category-list">
                                <li>Bleach</li>
                                <li>Pesticides</li>
                                <li>Poison</li>
                                <li>Self-defense sprays</li>
                                <li>Car airbags</li>
                            </ul>
                        </div>
                    </div>
                </section>

                <section class="report-section">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-shield" style="color: var(--primary-blue); font-size: 18px;"></i>
                        </div>
                        <div>
                            <div class="section-title">Operational Guidelines for SSOs</div>
                        </div>
                    </div>
                    <div class="form-grid-2">
                        <div class="category-card">
                                <h4 class="summary-label">X-ray Screening Procedures</h4>
                                <p>Follow standard operating procedures for bag screening. Flag suspicious items immediately and call for supervisor assistance when needed.</p>
                        </div>
                        <div class="category-card">
                                <h4 class="summary-label">Physical Search Protocol</h4>
                                <p>Conduct searches with dignity and respect. Always have a witness present and follow gender-appropriate search procedures.</p>
                        </div>
                        <div class="category-card">
                                <h4 class="summary-label">Document Management</h4>
                                <p>Complete all required forms accurately and submit within designated timeframes. Ensure proper photo documentation for evidence.</p>
                        </div>
                        <div class="category-card">
                                <h4 class="summary-label">Emergency Procedures</h4>
                                <p>In case of security threats, immediately notify the Terminal Chief and follow established emergency protocols.</p>
                        </div>
                    </div>
                </section>

                
            </div>
        </div>
    </main>

    <!-- Confirmation Modal -->
    <div class="confirmation-modal" id="confirmationModal">
        <div class="confirmation-modal-content">
            <div class="confirmation-modal-header">
                <div class="confirmation-icon">
                    <i class="fas fa-exclamation-triangle"></i>
                </div>
                <h3 id="confirmationTitle">Confirm Submission</h3>
            </div>
            <div class="confirmation-modal-body">
                <p id="confirmationMessage">Are you sure that all information you input are all correct?</p>
                <p class="confirmation-warning">Please review all your entries before submitting. Once submitted, changes may be limited.</p>
            </div>
            <div class="confirmation-modal-footer">
                <button class="btn-cancel" id="cancelSubmission">
                    <i class="fas fa-times"></i> Cancel
                </button>
                <button class="btn-confirm" id="confirmSubmission">
                    <i class="fas fa-check"></i> Yes, Submit
                </button>
            </div>
        </div>
    </div>

    <script>
        // PersonnelDataManager Class
class PersonnelDataManager {
    constructor() {
        this.defaultData = {
            terminalChief: 'Captain Chris',
            totalPersonnel: 100,
            totalSSO: 42,
            admins: 2,
            shiftInCharges: 4,
            checkpointSupervisors: 6,
            ssoMale: 24,
            ssoFemale: 6
        };
        this.currentData = null;
        this.isInitialized = false;
        this.initPromise = null;
        // Clear any old localStorage data completely
        localStorage.removeItem('srs_personnel_data');
    }

    async ensureInitialized() {
        if (!this.initPromise) {
            this.initPromise = this.loadData();
        }
        await this.initPromise;
        this.isInitialized = true;
        return this.currentData;
    }

    async loadData() {
        try {
            const response = await fetch('../BACKEND/get_personnel_overview.php');
            const result = await response.json();
            
            if (result.success) {
                this.currentData = result.data;
                return result.data;
            } else {
                console.error('Failed to load personnel data:', result.message);
                this.currentData = this.defaultData;
                return this.defaultData;
            }
        } catch (error) {
            console.error('Error loading personnel data:', error);
            this.currentData = this.defaultData;
            return this.defaultData;
        }
    }

    getData() {
        return this.currentData || this.defaultData;
    }

    // Force refresh from database
    async refreshFromDatabase() {
        return await this.loadData();
    }

    // Listen for changes - poll every 30 seconds
    onDataChange(callback) {
        setInterval(async () => {
            const newData = await this.loadData();
            if (JSON.stringify(newData) !== JSON.stringify(this.currentData)) {
                this.currentData = newData;
                callback(newData);
            }
        }, 30000); // Check every 30 seconds
    }
}
        // User Personnel Display Functions
        // User Personnel Display Functions
async function initializeUserPersonnel() {
    const personnelManager = new PersonnelDataManager();
    
    // Load data immediately on page load
    await loadUserPersonnelData();

    // Set up automatic refresh every 30 seconds
    personnelManager.onDataChange((data) => {
        loadUserPersonnelData(data);
        showUpdateIndicator();
    });

    async function loadUserPersonnelData(data = null) {
        // Always load fresh data from database
        let personnelData;
        if (data) {
            personnelData = data;
        } else {
            await personnelManager.ensureInitialized();
            personnelData = await personnelManager.loadData();
        }
        
        if (personnelData) {
            updateWithAnimation('userTerminalChief', personnelData.terminalChief);
            updateWithAnimation('userTotalPersonnel', personnelData.totalPersonnel);
            updateWithAnimation('userTotalSSO', personnelData.totalSSO);
            updateWithAnimation('userAdmins', personnelData.admins);
            updateWithAnimation('userShiftInCharges', personnelData.shiftInCharges);
            updateWithAnimation('userCheckpointSupervisors', personnelData.checkpointSupervisors);
            updateWithAnimation('userSsoMale', personnelData.ssoMale);
            updateWithAnimation('userSsoFemale', personnelData.ssoFemale);
        }
    }

            function updateWithAnimation(elementId, newValue) {
                const element = document.getElementById(elementId);
                if (element && element.textContent != newValue) {
                    element.style.transform = 'scale(1.1)';
                    element.style.color = 'var(--primary-blue)';
                    element.style.transition = 'all 0.3s ease';
                    
                    setTimeout(() => {
                        element.textContent = newValue;
                        element.style.transform = 'scale(1)';
                        element.style.color = '';
                    }, 150);
                } else if (element) {
                    element.textContent = newValue;
                }
            }

            function showUpdateIndicator() {
                const indicator = document.getElementById('updateIndicator');
                if (indicator) {
                    indicator.style.display = 'flex';
                    setTimeout(() => {
                        indicator.style.display = 'none';
                    }, 2000);
                }
            }
        }

        // ===== DAILY REPORT IMAGE UPLOAD =====
        const imageDropzone = document.getElementById('imageDropzone');
        const imageInput = document.getElementById('reportImages');
        const uploadStatus = document.getElementById('uploadStatus');
        const previewContainer = document.getElementById('imagePreviewContainer');
        const previewGrid = document.getElementById('imagePreviewGrid');

        let selectedFiles = [];

        if (imageDropzone && imageInput) {
            imageDropzone.addEventListener('click', () => {
                imageInput.click();
            });
            
            imageDropzone.addEventListener('dragover', (e) => {
                e.preventDefault();
                imageDropzone.style.borderColor = 'var(--primary-blue)';
                imageDropzone.style.background = 'rgba(49, 56, 147, 0.05)';
            });
            
            imageDropzone.addEventListener('dragleave', (e) => {
                e.preventDefault();
                imageDropzone.style.borderColor = 'var(--border-color)';
                imageDropzone.style.background = 'var(--bg-gray)';
            });
            
            imageDropzone.addEventListener('drop', (e) => {
                e.preventDefault();
                imageDropzone.style.borderColor = 'var(--border-color)';
                imageDropzone.style.background = 'var(--bg-gray)';
                
                const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
                handleImageSelection(files);
            });
            
            imageInput.addEventListener('change', (e) => {
                const files = Array.from(e.target.files);
                handleImageSelection(files);
            });
        }

        function handleImageSelection(files) {
            if (files.length < 2) {
                alert('Please select at least 2 images');
                return;
            }
            
            if (files.length > 4) {
                alert('Maximum 4 images allowed. Only first 4 will be used.');
                files = files.slice(0, 4);
            }
            
            selectedFiles = files;
            uploadStatus.textContent = `${files.length} file(s) selected`;
            uploadStatus.style.color = 'var(--primary-blue)';
            
            displayImagePreviews(files);
        }

        function displayImagePreviews(files) {
            previewGrid.innerHTML = '';
            previewContainer.style.display = 'block';
            
            files.forEach((file, index) => {
                const reader = new FileReader();
                
                reader.onload = (e) => {
                    const previewItem = document.createElement('div');
                    previewItem.style.cssText = 'position: relative; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;';
                    
                    previewItem.innerHTML = `
                        <img src="${e.target.result}" style="width: 100%; height: 150px; object-fit: cover;">
                        <div style="position: absolute; top: 4px; right: 4px; background: var(--accent-red); color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 12px;" onclick="removeImage(${index})">
                            <i class="fas fa-times"></i>
                        </div>
                        <div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.7); color: white; padding: 4px 8px; font-size: 11px;">
                            Image ${index + 1}
                        </div>
                    `;
                    
                    previewGrid.appendChild(previewItem);
                };
                
                reader.readAsDataURL(file);
            });
        }

        function removeImage(index) {
            selectedFiles.splice(index, 1);
            
            if (selectedFiles.length === 0) {
                uploadStatus.textContent = 'No file chosen';
                uploadStatus.style.color = '';
                previewContainer.style.display = 'none';
            } else {
                uploadStatus.textContent = `${selectedFiles.length} file(s) selected`;
                displayImagePreviews(selectedFiles);
            }
        }

        // ===== INTERCEPTION REPORT IMAGE UPLOAD =====
        const interceptionDropzone = document.querySelector('.interception-upload');
        const interceptionUploadStatus = interceptionDropzone?.querySelector('span');
        let selectedInterceptionFiles = [];
        let interceptionPreviewContainer = null;
        let interceptionPreviewGrid = null;

        if (interceptionDropzone) {
            interceptionPreviewContainer = document.createElement('div');
            interceptionPreviewContainer.id = 'interceptionPreviewContainer';
            interceptionPreviewContainer.style.display = 'none';
            interceptionPreviewContainer.style.marginBottom = '16px';
            
            interceptionPreviewGrid = document.createElement('div');
            interceptionPreviewGrid.id = 'interceptionPreviewGrid';
            interceptionPreviewGrid.style.cssText = 'display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 12px;';
            
            interceptionPreviewContainer.appendChild(interceptionPreviewGrid);
            interceptionDropzone.parentElement.insertBefore(interceptionPreviewContainer, interceptionDropzone);
            
            const interceptionInput = interceptionDropzone.querySelector('input[type="file"]');
            
            interceptionDropzone.addEventListener('click', () => {
                interceptionInput.click();
            });
            
            interceptionDropzone.addEventListener('dragover', (e) => {
                e.preventDefault();
                interceptionDropzone.style.borderColor = 'var(--primary-blue)';
                interceptionDropzone.style.background = 'rgba(49, 56, 147, 0.05)';
            });
            
            interceptionDropzone.addEventListener('dragleave', (e) => {
                e.preventDefault();
                interceptionDropzone.style.borderColor = 'var(--border-color)';
                interceptionDropzone.style.background = 'var(--bg-gray)';
            });
            
            interceptionDropzone.addEventListener('drop', (e) => {
                e.preventDefault();
                interceptionDropzone.style.borderColor = 'var(--border-color)';
                interceptionDropzone.style.background = 'var(--bg-gray)';
                
                const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'));
                handleInterceptionImageSelection(files);
            });
            
            interceptionInput.addEventListener('change', (e) => {
                const files = Array.from(e.target.files);
                handleInterceptionImageSelection(files);
            });
        }

        function handleInterceptionImageSelection(files) {
            if (files.length < 2) {
                alert('Please select at least 2 images');
                return;
            }
            
            if (files.length > 4) {
                alert('Maximum 4 images allowed. Only first 4 will be used.');
                files = files.slice(0, 4);
            }
            
            selectedInterceptionFiles = files;
            interceptionUploadStatus.textContent = `${files.length} file(s) selected`;
            interceptionUploadStatus.style.color = 'var(--primary-blue)';
            
            displayInterceptionImagePreviews(files);
        }

        function displayInterceptionImagePreviews(files) {
            interceptionPreviewGrid.innerHTML = '';
            interceptionPreviewContainer.style.display = 'block';
            
            files.forEach((file, index) => {
                const reader = new FileReader();
                
                reader.onload = (e) => {
                    const previewItem = document.createElement('div');
                    previewItem.style.cssText = 'position: relative; border: 2px solid var(--border-color); border-radius: 8px; overflow: hidden;';
                    
                    previewItem.innerHTML = `
                        <img src="${e.target.result}" style="width: 100%; height: 150px; object-fit: cover;">
                        <div style="position: absolute; top: 4px; right: 4px; background: var(--accent-red); color: white; width: 24px; height: 24px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 12px;" onclick="removeInterceptionImage(${index})">
                            <i class="fas fa-times"></i>
                        </div>
                        <div style="position: absolute; bottom: 0; left: 0; right: 0; background: rgba(0,0,0,0.7); color: white; padding: 4px 8px; font-size: 11px;">
                            Evidence ${index + 1}
                        </div>
                    `;
                    
                    interceptionPreviewGrid.appendChild(previewItem);
                };
                
                reader.readAsDataURL(file);
            });
        }

        function removeInterceptionImage(index) {
            selectedInterceptionFiles.splice(index, 1);
            
            if (selectedInterceptionFiles.length === 0) {
                interceptionUploadStatus.textContent = 'No file chosen';
                interceptionUploadStatus.style.color = '';
                interceptionPreviewContainer.style.display = 'none';
            } else {
                interceptionUploadStatus.textContent = `${selectedInterceptionFiles.length} file(s) selected`;
                displayInterceptionImagePreviews(selectedInterceptionFiles);
            }
        }

        // Dashboard Search Functions
        function initializeDashboardSearch() {
            const dateInput = document.getElementById('dashboardDate');
            const searchInput = document.getElementById('dashboardSearch');
            const reportTypeFilter = document.getElementById('dashboardReportType');
            const showingElement = document.getElementById('dashboardShowing');
            
            // Set current date on dashboard date picker
            if (dateInput) {
                dateInput.valueAsDate = new Date();
                dateInput.addEventListener('change', filterDashboardActivity);
            }
            if (searchInput) searchInput.addEventListener('input', filterDashboardActivity);
            if (reportTypeFilter) reportTypeFilter.addEventListener('change', filterDashboardActivity);
            
            function filterDashboardActivity() {
                const selectedDate = dateInput?.value || '';
                const searchTerm = searchInput?.value.toLowerCase() || '';
                const selectedType = reportTypeFilter?.value || '';
                
                const items = document.querySelectorAll('#dashboardActivityItems .activity-item');
                let visibleCount = 0;
                
                items.forEach(item => {
                    const itemDate = item.getAttribute('data-date') || '';
                    const itemType = item.getAttribute('data-type') || '';
                    const searchText = item.getAttribute('data-search-text') || '';
                    const activityText = item.querySelector('.activity-text')?.textContent.toLowerCase() || '';
                    const timeText = item.querySelector('.activity-time')?.textContent.toLowerCase() || '';
                    
                    const matchesDate = !selectedDate || itemDate === selectedDate;
                    const matchesSearch = !searchTerm || 
                        searchText.includes(searchTerm) ||
                        activityText.includes(searchTerm) ||
                        timeText.includes(searchTerm);
                    const matchesType = !selectedType || itemType === selectedType;
                    
                    if (matchesDate && matchesSearch && matchesType) {
                        item.style.display = '';
                        visibleCount++;
                    } else {
                        item.style.display = 'none';
                    }
                });
                
                let displayDate = '';
                if (selectedDate) {
                    displayDate = formatDateToWords(selectedDate);
                } else if (dateInput?.value) {
                    displayDate = formatDateToWords(dateInput.value);
                } else {
                    displayDate = 'All Dates';
                }
                
                if (showingElement) {
                    showingElement.textContent = `Showing ${visibleCount} activities for ${displayDate}`;
                }
            }

            filterDashboardActivity();
        }

        function formatDateToWords(dateStr) {
            if (!dateStr) return 'Unknown Date';
            
            try {
                const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
                const date = new Date(dateStr);
                
                if (isNaN(date.getTime())) {
                    return 'Invalid Date';
                }
                
                return date.toLocaleDateString('en-US', options);
            } catch (error) {
                console.error('Error formatting date:', error);
                return 'Unknown Date';
            }
        }
        
        // Daily Report Submission with Edit Support
        function handleDailyReportSubmit(e) {
            e.preventDefault();
            
            const form = document.getElementById('dailyReportForm');
            const isEditing = form.dataset.editingId;
            
            const formData = new FormData(form);
            
            // Collect all validation errors
            const errors = [];

            // Validate required fields
            if (!formData.get('report_date') || !formData.get('shift') || !formData.get('team')) {
                const missingFields = [];
                if (!formData.get('report_date')) missingFields.push('Date');
                if (!formData.get('shift')) missingFields.push('Shift');
                if (!formData.get('team')) missingFields.push('Team');
                errors.push('Missing required fields: ' + missingFields.join(', '));
            }

            // Validate personnel data (all required)
            if (!formData.get('screeners_on_duty') || !formData.get('screeners_off') || 
                !formData.get('screeners_on_leave') || !formData.get('screeners_absent')) {
                const missingPersonnel = [];
                if (!formData.get('screeners_on_duty')) missingPersonnel.push('Screeners on Duty');
                if (!formData.get('screeners_off')) missingPersonnel.push('Screeners Off');
                if (!formData.get('screeners_on_leave')) missingPersonnel.push('Screeners on Leave');
                if (!formData.get('screeners_absent')) missingPersonnel.push('Screeners Absent');
                errors.push('Missing personnel data: ' + missingPersonnel.join(', '));
            }

            // Validate image uploads (2-4 required for new submissions)
            if (selectedFiles.length < 2 && !isEditing) {
                errors.push('Please upload 2-4 images (currently ' + selectedFiles.length + ' uploaded)');
            }

            // For editing, allow updates without new images
            if (selectedFiles.length > 4) {
                errors.push('Maximum 4 images allowed (you have ' + selectedFiles.length + ' selected)');
            }

            // Show all errors at once
            if (errors.length > 0) {
                alert('Please fix the following issues:\n\n• ' + errors.join('\n• '));
                hideConfirmationModal();
                return;
            }
            
            // Add report_id if editing
            if (isEditing) {
                formData.append('report_id', form.dataset.editingId);
                console.log('Editing report ID:', form.dataset.editingId); // Debug log
            }
            
            // Only add new images if they were selected
            formData.delete('report_images[]');
            if (selectedFiles.length > 0) {
                selectedFiles.forEach((file, index) => {
                    formData.append('report_image_' + (index + 1), file);
                });
            }
            
            const submitBtn = document.getElementById('dailyReportSubmit');
            const originalText = submitBtn.innerHTML;
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="loading-spinner"></i> ' + (isEditing ? 'Updating...' : 'Uploading...');
            
            const endpoint = isEditing ? '../BACKEND/update_daily_report.php' : '../BACKEND/submit_daily_report.php';
            
            console.log('Submitting to:', endpoint); // Debug log
            console.log('Is editing:', isEditing); // Debug log
            
            fetch(endpoint, {
                method: 'POST',
                body: formData
            })
            .then(response => {
                console.log('Response status:', response.status);
                return response.text().then(text => {
                    console.log('Full Response text:');
                    console.log(text); // Show full response
                    
                    if (!text || text.trim() === '') {
                        throw new Error('Server returned empty response');
                    }
                    
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        console.error('JSON parse error:', e);
                        console.error('Full server response:');
                        console.error(text);
                        
                        // Show first 500 characters of response
                        const preview = text.substring(0, 500);
                        throw new Error('Server returned invalid JSON. First 500 chars: ' + preview);
                    }
                });
            })
            .then(data => {
                if (data.success) {
                    alert(isEditing ? 'Report updated successfully!' : `Daily report submitted successfully! ${data.images_uploaded || 0} images uploaded.`);
                    
                    // Reset form
                    form.reset();
                    delete form.dataset.editingId;
                    selectedFiles = [];
                    uploadStatus.textContent = 'No file chosen';
                    uploadStatus.style.color = '';
                    previewContainer.style.display = 'none';
                    document.querySelector('.editing-indicator')?.remove();
                    submitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Daily Report';
                    
                    // Reload reports and return to dashboard
                    loadAllUserReports();
                    document.querySelector('.nav-item[data-page="dashboard"]').click();
                } else {
                    alert('Error: ' + (data.message || 'Unknown error occurred'));
                }
            })
            .catch(error => {
                console.error('Fetch error:', error);
                alert('Network error: ' + error.message);
            })
            .finally(() => {
                submitBtn.disabled = false;
                submitBtn.innerHTML = originalText;
                hideConfirmationModal();
            });
        }

        // Interception Report Submission with Edit Support
        function handleInterceptionReportSubmit(e) {
            e.preventDefault();
            
            const form = document.getElementById('interceptionReportForm');
            const isEditing = form.dataset.editingId;
            
            // Collect all validation errors
        const errors = [];

        // Validate required fields
        const reportDate = document.getElementById('interceptionDate').value;
        const shift = document.getElementById('interceptionShift').value;
        const team = document.getElementById('interceptionTeam').value;
        const passengerName = document.getElementById('passengerName').value;
        const occupation = document.getElementById('occupation').value;
        const flightNumber = document.getElementById('flightNumber').value;
        const interceptedItem = document.getElementById('interceptedItem').value;

        if (!reportDate || !shift || !team) {
            const missingFields = [];
            if (!reportDate) missingFields.push('Date');
            if (!shift) missingFields.push('Shift');
            if (!team) missingFields.push('Team');
            errors.push('Missing required fields: ' + missingFields.join(', '));
        }

        if (!passengerName || !occupation) {
            const missingPassenger = [];
            if (!passengerName) missingPassenger.push('Passenger Name');
            if (!occupation) missingPassenger.push('Occupation');
            errors.push('Missing passenger information: ' + missingPassenger.join(', '));
        }

        if (!flightNumber) {
            errors.push('Flight Number is required');
        }

        if (!interceptedItem) {
            errors.push('Intercepted Item is required');
        }

        // Validate images only for new submissions
        if (selectedInterceptionFiles.length < 2 && !isEditing) {
            errors.push('Please upload 2-4 evidence photos (currently ' + selectedInterceptionFiles.length + ' uploaded)');
        }

        if (selectedInterceptionFiles.length > 4) {
            errors.push('Maximum 4 images allowed (you have ' + selectedInterceptionFiles.length + ' selected)');
        }

        // Show all errors at once
        if (errors.length > 0) {
            alert('Please fix the following issues:\n\n• ' + errors.join('\n• '));
            hideConfirmationModal();
            return;
        }
    
    const formData = new FormData();
    
    // Add report_id if editing
    if (isEditing) {
        formData.append('report_id', form.dataset.editingId);
    }
    
    // Use IDs to get values reliably
    formData.append('report_date', document.getElementById('interceptionDate').value);
    formData.append('shift', document.getElementById('interceptionShift').value);
    formData.append('team', document.getElementById('interceptionTeam').value);
    
    // Personal data
    formData.append('passenger_name', document.getElementById('passengerName').value);
    formData.append('occupation', document.getElementById('occupation').value);
    
    // Flight details
    formData.append('flight_number', document.getElementById('flightNumber').value);
    formData.append('destination', document.getElementById('destination').value || '');
    
    // Intercepted item
    formData.append('intercepted_item', document.getElementById('interceptedItem').value);
    formData.append('quantity', document.getElementById('quantity').value);
    
    // Intercepted by
    formData.append('xray_operator', document.getElementById('xrayOperator').value || '');
    formData.append('baggage_pusher', document.getElementById('baggagePusher').value || '');
    formData.append('remarks', document.getElementById('remarks').value || '');
    
    // Add new images if uploaded
    if (selectedInterceptionFiles.length > 0) {
        selectedInterceptionFiles.forEach((file, index) => {
            formData.append('interception_image_' + (index + 1), file);
        });
    }
    
    const submitBtn = document.getElementById('interceptionReportSubmit');
    const originalText = submitBtn.innerHTML;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<i class="loading-spinner"></i> ' + (isEditing ? 'Updating...' : 'Submitting...');
    
    const endpoint = isEditing ? '../BACKEND/update_interception_report.php' : '../BACKEND/submit_interception_report.php';
    
    fetch(endpoint, {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(text => {
        console.log('Raw response:', text);
        try {
            const data = JSON.parse(text);
            if (data.success) {
                alert(isEditing ? 'Interception report updated successfully!' : 'Interception report submitted successfully!');
                
                // Reset form
                form.reset();
                delete form.dataset.editingId;
                selectedInterceptionFiles = [];
                if (interceptionUploadStatus) {
                    interceptionUploadStatus.textContent = 'No file chosen';
                    interceptionUploadStatus.style.color = '';
                }
                if (interceptionPreviewContainer) {
                    interceptionPreviewContainer.style.display = 'none';
                }
                document.querySelector('.editing-indicator')?.remove();
                submitBtn.innerHTML = '<i class="fas fa-exclamation-circle"></i> Submit Interception Report';
                
                // Reload and return to dashboard
                loadAllUserReports();
                document.querySelector('.nav-item[data-page="dashboard"]').click();
            } else {
                alert('Error: ' + (data.message || 'Unknown error occurred'));
            }
        } catch (e) {
            console.error('JSON Parse Error:', e);
            console.error('Response was:', text);
            alert('Server error: ' + text.substring(0, 200));
        }
    })
    .catch(error => {
        console.error('Network error:', error);
        alert('Network error: ' + error.message);
    })
    .finally(() => {
        submitBtn.disabled = false;
        submitBtn.innerHTML = originalText;
        hideConfirmationModal();
    });
}
        // Load both daily and interception reports
        function loadAllUserReports() {
            Promise.all([
                fetch('../BACKEND/get_user_reports.php').then(r => r.json()),
                fetch('../BACKEND/get_interception_reports.php').then(r => r.json())
            ])
            .then(([dailyData, interceptionData]) => {
                const allReports = [];
                
                if (dailyData.success) {
                    dailyData.reports.forEach(report => {
                        report.type = 'daily';
                        allReports.push(report);
                    });
                }
                
                if (interceptionData.success) {
                    interceptionData.reports.forEach(report => {
                        report.type = 'interception';
                        allReports.push(report);
                    });
                }
                
                allReports.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                
                displayAllReports(allReports);
            })
            .catch(error => console.error('Error loading reports:', error));
        }

        function displayAllReports(reports) {
            const container = document.getElementById('dashboardActivityItems');
            if (!container) return;
            
            container.innerHTML = '';
            
            if (reports.length === 0) {
                container.innerHTML = '<div class="activity-item"><div class="activity-content"><div class="activity-text">No reports found.</div></div></div>';
                // Update showing text even when no reports
                const showingElement = document.getElementById('dashboardShowing');
                if (showingElement) {
                    showingElement.textContent = 'Showing 0 activities for All Dates';
                }
                return;
            }
            
            reports.forEach(report => {
                const reportDate = new Date(report.report_date).toLocaleDateString();
                const createdAt = new Date(report.created_at);
                const timeStr = createdAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
                
                const div = document.createElement('div');
                div.className = 'activity-item';
                div.setAttribute('data-type', report.type);
                div.setAttribute('data-date', report.report_date);
                
                let avatar = 'DR';
                let title = '';
                let searchText = '';
                
                if (report.type === 'daily') {
                    avatar = 'DR';
                    title = `Daily Report - ${report.shift} - ${report.team}`;
                    searchText = `daily report ${report.shift} ${report.team}`;
                } else {
                    avatar = 'IR';
                    title = `Interception Report - ${report.passenger_name} - ${report.flight_number}`;
                    searchText = `interception report ${report.passenger_name} ${report.flight_number} ${report.intercepted_item}`;
                }
                
                div.setAttribute('data-search-text', searchText);
                
                let statusBadge = '';
                if (report.status === 'submitted') {
                    statusBadge = '<span class="report-status status-submitted">Submitted</span>';
                } else if (report.status === 'approved') {
                    statusBadge = '<span class="report-status" style="background: rgba(40, 167, 69, 0.1); color: var(--notif-green);">Approved</span>';
                }
                
                let editButton = '';
                if (report.can_edit) {
                    const hoursLeft = Math.floor(report.hours_remaining);
                    const minutesLeft = Math.floor((report.hours_remaining - hoursLeft) * 60);
                    
                    editButton = `
                        <button class="activity-action-btn edit-btn" onclick="editReport(${report.id}, '${report.type}')">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <div class="time-remaining">${hoursLeft}h ${minutesLeft}m left to edit</div>
                    `;
                }
                let deleteButton = '';
                
                if (report.can_edit) {
                    const hoursLeft = Math.floor(report.hours_remaining);
                    const minutesLeft = Math.floor((report.hours_remaining - hoursLeft) * 60);
                    
                    const deleteFunction = report.type === 'daily' ? 'deleteReport' : 'deleteInterceptionReport';
                    
                    editButton = `
                        <button class="activity-action-btn edit-btn" onclick="editReport(${report.id}, '${report.type}')">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <div class="time-remaining">${hoursLeft}h ${minutesLeft}m left to edit</div>
                    `;
                    
                    deleteButton = `
                        <button class="activity-action-btn delete-btn" onclick="${deleteFunction}(${report.id})">
                            <i class="fas fa-trash"></i> Delete
                        </button>
                    `;
                } else {
                    editButton = `
                        <button class="activity-action-btn edit-btn expired" disabled>
                            <i class="fas fa-edit"></i> Edit Expired
                        </button>
                    `;
                }
                
                div.innerHTML = `
                    <div class="activity-avatar" style="${report.type === 'interception' ? 'background: var(--accent-red);' : ''}">${avatar}</div>
                    <div class="activity-content">
                        <div class="activity-text">
                            ${title}
                            ${statusBadge}
                        </div>
                        <div class="activity-time">${reportDate} at ${timeStr}</div>
                    </div>
                    <div class="activity-actions">
                        <button class="activity-action-btn view-btn" onclick="viewReportDetails(${report.id}, '${report.type}')">
                            <i class="fas fa-eye"></i> View
                        </button>
                        ${editButton}
                        ${deleteButton}
                    </div>
                `;
                
                container.appendChild(div);
            });
            
            const showingElement = document.getElementById('dashboardShowing');
            if (showingElement) {
                showingElement.textContent = `Showing ${reports.length} activities`;
            }

            setTimeout(() => {
                const dateInput = document.getElementById('dashboardDate');
                if (dateInput) {
                    const event = new Event('change');
                    dateInput.dispatchEvent(event);
                }
            }, 100);
        }

        // Delete report function
        function deleteReport(reportId) {
            if (!confirm('Are you sure you want to delete this report? This action cannot be undone.')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('report_id', reportId);
            
            fetch('../BACKEND/delete_report.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Report deleted successfully');
                    
                    loadAllUserReports();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Network error: ' + error.message);
            });
        }

        // Delete interception report function
        function deleteInterceptionReport(reportId) {
            if (!confirm('Are you sure you want to delete this interception report? This action cannot be undone.')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('report_id', reportId);
            
            fetch('../BACKEND/delete_interception_report.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Interception report deleted successfully');
                    loadAllUserReports();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Network error: ' + error.message);
            });
        }

        // ===== NEW: VIEW REPORT DETAILS =====
        function viewReportDetails(reportId, reportType) {
            fetch(`../BACKEND/get_report_details.php?report_id=${reportId}&report_type=${reportType}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showReportModal(data.report, reportType);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network error: ' + error.message);
                });
        }

        // Show report in modal
        function showReportModal(report, reportType) {
            const modalHTML = `
                <div class="report-modal" id="reportModal">
                    <div class="report-modal-content">
                        <div class="report-modal-header">
                            <h3>${reportType === 'daily' ? 'Daily Report' : 'Interception Report'} Details</h3>
                            <button class="close-modal" onclick="closeReportModal()">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="report-modal-body">
                            ${reportType === 'daily' ? generateDailyReportHTML(report) : generateInterceptionReportHTML(report)}
                        </div>
                        <div class="report-modal-footer">
                            ${report.can_edit ? `
                                <button class="btn-edit" onclick="closeReportModal(); editReport(${report.id}, '${reportType}')">
                                    <i class="fas fa-edit"></i> Edit Report
                                </button>
                            ` : ''}
                            <button class="btn-close" onclick="closeReportModal()">
                                <i class="fas fa-times"></i> Close
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            document.getElementById('reportModal').style.display = 'flex';
        }

        // Generate daily report HTML
        function generateDailyReportHTML(report) {
            return `
                <div class="report-info">
                    <div class="info-row"><strong>Date:</strong> ${report.report_date}</div>
                    <div class="info-row"><strong>Shift:</strong> ${report.shift}</div>
                    <div class="info-row"><strong>Team:</strong> ${report.team}</div>
                    <div class="info-row"><strong>Status:</strong> ${report.status}</div>
                </div>
                
                <h4>Personnel Data</h4>
                <div class="report-info">
                    <div class="info-row"><strong>On Duty:</strong> ${report.screeners_on_duty}</div>
                    <div class="info-row"><strong>Off Duty:</strong> ${report.screeners_off}</div>
                    <div class="info-row"><strong>On Leave:</strong> ${report.screeners_on_leave}</div>
                    <div class="info-row"><strong>Absent:</strong> ${report.screeners_absent}</div>
                </div>
                
                <h4>Flight Summary</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Domestic Flights:</strong> ${report.domestic_departing_flights} (${report.domestic_passengers} passengers)</div>
                    <div class="info-row"><strong>International Flights:</strong> ${report.international_departing_flights} (${report.international_passengers} passengers)</div>
                </div>
                
                <h4>Prohibited Items</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Blunt Instruments:</strong> ${report.blunt_instruments}</div>
                    <div class="info-row"><strong>Sharp Objects:</strong> ${report.sharp_objects}</div>
                    <div class="info-row"><strong>Liquids/Gels:</strong> ${report.liquid_aerosols_gels}</div>
                </div>
                
                ${report.additional_notes ? `
                    <h4>Additional Notes</h4>
                    <div class="report-info">
                        <p>${report.additional_notes}</p>
                    </div>
                ` : ''}
                
                ${generateImageGallery(report, 'daily')}
            `;
        }

        // Generate interception report HTML
        function generateInterceptionReportHTML(report) {
            return `
                <div class="report-info">
                    <div class="info-row"><strong>Date:</strong> ${report.report_date}</div>
                    <div class="info-row"><strong>Shift:</strong> ${report.shift}</div>
                    <div class="info-row"><strong>Team:</strong> ${report.team}</div>
                </div>
                
                <h4>Passenger Information</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Name:</strong> ${report.passenger_name}</div>
                    <div class="info-row"><strong>Occupation:</strong> ${report.occupation}</div>
                </div>
                
                <h4>Flight Details</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Flight Number:</strong> ${report.flight_number}</div>
                    <div class="info-row"><strong>Destination:</strong> ${report.destination || 'N/A'}</div>
                </div>
                
                <h4>Intercepted Item</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Item:</strong> ${report.intercepted_item}</div>
                    <div class="info-row"><strong>Quantity:</strong> ${report.quantity}</div>
                </div>
                
                ${report.xray_operator || report.baggage_pusher ? `
                    <h4>Intercepted By</h4>
                    <div class="report-info">
                        ${report.xray_operator ? `<div class="info-row"><strong>X-ray Operator:</strong> ${report.xray_operator}</div>` : ''}
                        ${report.baggage_pusher ? `<div class="info-row"><strong>Baggage Inspector:</strong> ${report.baggage_pusher}</div>` : ''}
                    </div>
                ` : ''}
                
                ${report.remarks ? `
                    <h4>Remarks</h4>
                    <div class="report-info">
                        <p>${report.remarks}</p>
                    </div>
                ` : ''}
                
                ${generateImageGallery(report, 'interception')}
            `;
        }

        // Generate image gallery
        function generateImageGallery(report, type) {
            const images = [];
            const baseUrl = type === 'daily' ? '../uploads/daily_reports/' : '../uploads/interception_reports/';
            
            for (let i = 1; i <= 4; i++) {
                if (report[`image${i}`]) {
                    images.push(`${baseUrl}${report[`image${i}`]}`);
                }
            }
            
            if (images.length === 0) return '';
            
            return `
                <h4>Images</h4>
                <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 12px; margin-top: 12px;">
                    ${images.map(img => `
                        <img src="${img}" alt="Report image" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px; cursor: pointer;" onclick="window.open('${img}', '_blank')">
                    `).join('')}
                </div>
            `;
        }

        // Close report modal
        function closeReportModal() {
            const modal = document.getElementById('reportModal');
            if (modal) {
                modal.remove();
            }
        }
        // ===== NEW: EDIT REPORT FUNCTIONALITY =====
        function editReport(reportId, reportType) {
            fetch(`../BACKEND/get_report_details.php?report_id=${reportId}&report_type=${reportType}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (!data.report.can_edit) {
                            alert('This report can no longer be edited (24-hour window expired)');
                            return;
                        }
                        loadReportForEditing(data.report, reportType);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network error: ' + error.message);
                });
        }

        // Load report for editing
        function loadReportForEditing(report, reportType) {
            if (reportType === 'daily') {
                document.querySelector('.nav-item[data-page="dailyReport"]').click();
                setTimeout(() => populateDailyReportForm(report), 100);
            } else {
                document.querySelector('.nav-item[data-page="interception"]').click();
                setTimeout(() => populateInterceptionReportForm(report), 100);
            }
            
            window.scrollTo(0, 0);
        }

        // Populate daily report form
        function populateDailyReportForm(report) {
            const formContainer = document.getElementById('dailyReportContent');
            const existingIndicator = document.querySelector('.editing-indicator');
            if (existingIndicator) existingIndicator.remove();
            
            const indicator = document.createElement('div');
            indicator.className = 'editing-indicator';
            indicator.innerHTML = `
                <i class="fas fa-edit"></i>
                <span>Editing Report from ${report.report_date}</span>
                <button class="cancel-editing-btn" onclick="cancelEditing()">
                    <i class="fas fa-times"></i> Cancel
                </button>
            `;
            formContainer.insertBefore(indicator, formContainer.firstChild);
            
            document.getElementById('reportDate').value = report.report_date;
            document.querySelector('select[name="shift"]').value = report.shift;
            document.querySelector('select[name="team"]').value = report.team;
            
            document.querySelector('input[name="screeners_on_duty"]').value = report.screeners_on_duty;
            document.querySelector('input[name="screeners_off"]').value = report.screeners_off;
            document.querySelector('input[name="screeners_on_leave"]').value = report.screeners_on_leave;
            document.querySelector('input[name="screeners_absent"]').value = report.screeners_absent;
            
            document.querySelector('input[name="domestic_departing_flights"]').value = report.domestic_departing_flights;
            document.querySelector('input[name="domestic_passengers"]').value = report.domestic_passengers;
            document.querySelector('input[name="domestic_cancelled_flights"]').value = report.domestic_cancelled_flights;
            document.querySelector('input[name="domestic_affected_passengers"]').value = report.domestic_affected_passengers;
            
            document.querySelector('input[name="international_departing_flights"]').value = report.international_departing_flights;
            document.querySelector('input[name="international_passengers"]').value = report.international_passengers;
            document.querySelector('input[name="international_cancelled_flights"]').value = report.international_cancelled_flights;
            document.querySelector('input[name="international_affected_passengers"]').value = report.international_affected_passengers;
            
            document.querySelector('input[name="blunt_instruments"]').value = report.blunt_instruments;
            document.querySelector('input[name="liquid_aerosols_gels"]').value = report.liquid_aerosols_gels;
            document.querySelector('input[name="sharp_objects"]').value = report.sharp_objects;
            document.querySelector('input[name="workers_tools"]').value = report.workers_tools;
            document.querySelector('input[name="explosives_incendiary"]').value = report.explosives_incendiary;
            document.querySelector('input[name="stunning_devices"]').value = report.stunning_devices;
            document.querySelector('input[name="chemical_toxic"]').value = report.chemical_toxic;
            
            document.querySelector('textarea[name="additional_notes"]').value = report.additional_notes || '';
            
            document.getElementById('dailyReportForm').dataset.editingId = report.id;
            
            const submitBtn = document.getElementById('dailyReportSubmit');
            submitBtn.innerHTML = '<i class="fas fa-save"></i> Update Daily Report';
        }

        // Populate interception report form
function populateInterceptionReportForm(report) {
    const formContainer = document.getElementById('interceptionContent');
    const existingIndicator = document.querySelector('.editing-indicator');
    if (existingIndicator) existingIndicator.remove();
    
    const indicator = document.createElement('div');
    indicator.className = 'editing-indicator';
    indicator.innerHTML = `
        <i class="fas fa-edit"></i>
        <span>Editing Interception Report from ${report.report_date}</span>
        <button class="cancel-editing-btn" onclick="cancelEditing()">
            <i class="fas fa-times"></i> Cancel
        </button>
    `;
    formContainer.insertBefore(indicator, formContainer.firstChild);
    
    // Use IDs to populate fields reliably
    document.getElementById('interceptionDate').value = report.report_date;
    document.getElementById('interceptionShift').value = report.shift;
    document.getElementById('interceptionTeam').value = report.team;
    
    document.getElementById('passengerName').value = report.passenger_name;
    document.getElementById('occupation').value = report.occupation;
    
    document.getElementById('flightNumber').value = report.flight_number;
    document.getElementById('destination').value = report.destination || '';
    
    document.getElementById('interceptedItem').value = report.intercepted_item;
    document.getElementById('quantity').value = report.quantity;
    
    document.getElementById('xrayOperator').value = report.xray_operator || '';
    document.getElementById('baggagePusher').value = report.baggage_pusher || '';
    document.getElementById('remarks').value = report.remarks || '';
    
    const interceptionForm = document.getElementById('interceptionReportForm');
    interceptionForm.dataset.editingId = report.id;
    
    const submitBtn = document.getElementById('interceptionReportSubmit');
    submitBtn.innerHTML = '<i class="fas fa-save"></i> Update Interception Report';
}

        // Cancel editing
        function cancelEditing() {
            document.querySelector('.editing-indicator')?.remove();
            document.getElementById('dailyReportForm')?.reset();
            document.querySelector('#interceptionContent')?.querySelectorAll('input, select, textarea').forEach(el => {
                if (el.type === 'number') el.value = el.min || '0';
                else if (el.type !== 'file') el.value = '';
            });
            delete document.getElementById('dailyReportForm')?.dataset.editingId;
            delete document.querySelector('#interceptionContent')?.dataset.editingId;
            
            const dailySubmitBtn = document.getElementById('dailyReportSubmit');
            if (dailySubmitBtn) {
                dailySubmitBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Submit Daily Report';
            }
            
            const interceptionSubmitBtn = document.getElementById('interceptionReportSubmit');
            if (interceptionSubmitBtn) {
                interceptionSubmitBtn.innerHTML = '<i class="fas fa-exclamation-circle"></i> Submit Interception Report';
            }
            
            document.querySelector('.nav-item[data-page="dashboard"]').click();
        }
        // Confirmation Modal Functions
        let currentSubmissionType = '';
        
        function showConfirmationModal(type) {
            currentSubmissionType = type;
            const modal = document.getElementById('confirmationModal');
            const title = document.getElementById('confirmationTitle');
            const message = document.getElementById('confirmationMessage');
            
            if (type === 'daily') {
                title.textContent = 'Confirm Daily Report Submission';
                message.textContent = 'Are you sure that all information you input in the Daily Report are all correct?';
            } else if (type === 'interception') {
                title.textContent = 'Confirm Interception Report Submission';
                message.textContent = 'Are you sure that all information you input in the Interception Report are correct? This is a high-priority report.';
            }
            
            modal.style.display = 'flex';
            document.body.style.overflow = 'hidden';
        }
        
        function hideConfirmationModal() {
            const modal = document.getElementById('confirmationModal');
            modal.style.display = 'none';
            document.body.style.overflow = '';
            currentSubmissionType = '';
        }

        // Mobile menu toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const sidebarClose = document.getElementById('sidebarClose');

        function openSidebar() {
            sidebar.classList.add('active');
            mobileMenuToggle.classList.add('active');
            sidebarOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeSidebar() {
            sidebar.classList.remove('active');
            mobileMenuToggle.classList.remove('active');
            sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        mobileMenuToggle.addEventListener('click', () => {
            if (sidebar.classList.contains('active')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });

        sidebarClose.addEventListener('click', closeSidebar);
        sidebarOverlay.addEventListener('click', closeSidebar);

        // Navigation
        const navItems = document.querySelectorAll('.nav-item');
        const pageContents = document.querySelectorAll('.page-content');

        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                
                const targetPage = item.getAttribute('data-page');
                
                if (targetPage === 'logout') {
                    if (confirm('Are you sure you want to logout?')) {
                        window.location.href = '../BACKEND/logout.php';
                    }
                    return;
                }
                
                navItems.forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');
                
                pageContents.forEach(page => page.classList.remove('active'));
                
                if (targetPage === 'dashboard') {
                    document.getElementById('dashboardContent').classList.add('active');
                    initializeUserPersonnel();
                    initializeDashboardSearch();
                    loadAllUserReports();
                } else if (targetPage === 'dailyReport') {
                    document.getElementById('dailyReportContent').classList.add('active');
                    document.getElementById('reportDate').valueAsDate = new Date();
                } else if (targetPage === 'interception') {
                    document.getElementById('interceptionContent').classList.add('active');
                    document.getElementById('interceptionDate').valueAsDate = new Date();
                } else if (targetPage && document.getElementById(targetPage + 'Content')) {
                    document.getElementById(targetPage + 'Content').classList.add('active');
                } else if (targetPage) {
                    alert(`${item.querySelector('span').textContent} page coming soon!`);
                    document.querySelector('.nav-item[data-page="dashboard"]').classList.add('active');
                    document.getElementById('dashboardContent').classList.add('active');
                }
                
                if (window.innerWidth <= 1024) {
                    closeSidebar();
                }
            });
        });

        // Confirmation Modal Event Listeners
        document.getElementById('dailyReportSubmit').addEventListener('click', (e) => {
            e.preventDefault();
            showConfirmationModal('daily');
        });

        document.getElementById('interceptionReportSubmit').addEventListener('click', (e) => {
            e.preventDefault();
            showConfirmationModal('interception');
        });

        document.getElementById('cancelSubmission').addEventListener('click', () => {
            hideConfirmationModal();
        });

        document.getElementById('confirmSubmission').addEventListener('click', () => {
            if (currentSubmissionType === 'daily') {
                handleDailyReportSubmit({ preventDefault: () => {} });
            } else if (currentSubmissionType === 'interception') {
                handleInterceptionReportSubmit({ preventDefault: () => {} });
            }
        });

        // Close modal when clicking outside
        document.getElementById('confirmationModal').addEventListener('click', (e) => {
            if (e.target === document.getElementById('confirmationModal')) {
                hideConfirmationModal();
            }
        });

        // Close modal with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                if (document.getElementById('confirmationModal').style.display === 'flex') {
                    hideConfirmationModal();
                }
                if (document.getElementById('reportModal')) {
                    closeReportModal();
                }
            }
        });

        // Initialize everything when DOM is loaded
        document.addEventListener('DOMContentLoaded', () => {
            initializeUserPersonnel();
            initializeDashboardSearch();
            loadAllUserReports();
            
            const reportDate = document.getElementById('reportDate');
            if (reportDate) {
                reportDate.valueAsDate = new Date();
            }

            const interceptionDate = document.getElementById('interceptionDate');
            if (interceptionDate) {
                interceptionDate.valueAsDate = new Date();
            }

            initializeFAQs();
        });

        // Handle window resize
        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                if (window.innerWidth > 1024) {
                    closeSidebar();
                }
            }, 250);
        });

        // Initialize FAQs accordion
        function initializeFAQs() {
            const faqItems = document.querySelectorAll('.faq-item');
            
            faqItems.forEach(item => {
                const question = item.querySelector('.faq-question');
                
                const newQuestion = question.cloneNode(true);
                question.parentNode.replaceChild(newQuestion, question);
                
                newQuestion.addEventListener('click', () => {
                    const isActive = item.classList.contains('active');
                    
                    faqItems.forEach(faq => faq.classList.remove('active'));
                    
                    if (!isActive) {
                        item.classList.add('active');
                    }
                });
            });
        }

        // Add this function before the form submission handler
        function validateImageUploads() {
            const imageInputs = ['report_image_1', 'report_image_2', 'report_image_3', 'report_image_4'];
            let uploadedCount = 0;
            
            imageInputs.forEach(inputId => {
                const input = document.getElementById(inputId);
                if (input && input.files && input.files.length > 0) {
                    uploadedCount++;
                }
            });
            
            if (uploadedCount < 2) {
                return false;
            }
            
            return true;
        }

    </script>

    <style>
        @keyframes slideOut {
            from {
                opacity: 1;
                transform: translateX(0);
            }
            to {
                opacity: 0;
                transform: translateX(-100px);
            }
        }

        .loading-spinner {
            display: inline-block;
            width: 16px;
            height: 16px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid var(--primary-blue);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>

    
</body>
</html>