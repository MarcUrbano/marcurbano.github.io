<?php
// Require authentication with 'executive' role
require_once 'auth_check.php';
requireAuth('executive');
checkSessionTimeout();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SRS - NAIA Terminal 1 Dashboard</title>
    <link rel="icon" type="images/png" href="Logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../ACCOUNTS/style.css">
    <style>
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 2000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            animation: fadeIn 0.3s ease;
        }

        .modal.active {
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            width: 90%;
            max-width: 500px;
            animation: slideUp 0.3s ease;
        }

        .modal-header {
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .modal-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-primary);
        }

        .modal-close {
            background: none;
            border: none;
            font-size: 24px;
            color: var(--text-secondary);
            cursor: pointer;
            padding: 0;
            width: 30px;
            height: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .modal-close:hover {
            background: var(--bg-gray);
            color: var(--text-primary);
        }

        .modal-body {
            padding: 24px;
        }

        .modal-subtitle {
            color: var(--text-secondary);
            font-size: 14px;
            margin-bottom: 20px;
        }

        .personnel-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 16px;
        }

        .personnel-item {
            display: flex;
            justify-content: space-between;
            padding: 12px 0;
            border-bottom: 1px solid var(--border-color);
        }

        .personnel-label {
            color: var(--text-secondary);
            font-size: 14px;
        }

        .personnel-value {
            font-weight: 600;
            color: var(--text-primary);
            font-size: 14px;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes slideUp {
            from {
                transform: translateY(30px);
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .modal-content {
                width: 95%;
                margin: 20px;
            }

            .personnel-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Personnel Modal -->
    <div class="modal" id="personnelModal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="modalTitle">Personnel Information</h3>
                <button class="modal-close" onclick="closeModal()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="modal-subtitle" id="modalSubtitle">Detailed personnel breakdown for this airport</div>
                <div class="personnel-grid">
                    <div class="personnel-item">
                        <span class="personnel-label">Terminal Chief</span>
                        <span class="personnel-value" id="modalChief">-</span>
                    </div>
                    <div class="personnel-item">
                        <span class="personnel-label">Total Personnel</span>
                        <span class="personnel-value" id="modalTotalPersonnel">-</span>
                    </div>
                    <div class="personnel-item">
                        <span class="personnel-label">Airport Clerk</span>
                        <span class="personnel-value" id="modalAdmins">-</span>
                    </div>
                    <div class="personnel-item">
                        <span class="personnel-label">Shift-in-Charges</span>
                        <span class="personnel-value" id="modalShiftCharges">-</span>
                    </div>
                    <div class="personnel-item">
                        <span class="personnel-label">Checkpoint Supervisors</span>
                        <span class="personnel-value" id="modalSupervisors">-</span>
                    </div>
                    <div class="personnel-item">
                        <span class="personnel-label">Total SSOs</span>
                        <span class="personnel-value" id="modalTotalSSOs">-</span>
                    </div>
                    <div class="personnel-item">
                        <span class="personnel-label">Male SSO</span>
                        <span class="personnel-value" id="modalMaleSSOs">-</span>
                    </div>
                    <div class="personnel-item">
                        <span class="personnel-label">Female SSO</span>
                        <span class="personnel-value" id="modalFemaleSSOs">-</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="Logo.png" alt="Logo">
            </div>
            <div class="sidebar-title">SRS - NAIA<br>TERMINAL 1</div>
            <button class="sidebar-close" id="sidebarClose">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <nav class="nav-section">
            <a href="#" class="nav-item active" data-page="dashboard">
                <div class="nav-icon">
                    <i class="fas fa-tachometer-alt"></i>
                </div>
                <span>Dashboard</span>
            </a>
            <a href="#" class="nav-item" data-page="airports">
                <div class="nav-icon">
                    <i class="fas fa-plane-departure"></i>
                </div>
                <span>List of Airports</span>
            </a>
            <a href="#" class="nav-item" data-page="reportsManagement">
                <div class="nav-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <span>Reports Management</span>
            </a>
            
            <div class="nav-divider"></div>
            
            <a href="#" class="nav-item" data-page="help">
                <div class="nav-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <span>Help Center</span>
            </a>
            <a href="#" class="nav-item" data-page="notifications">
                <div class="nav-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <span>Notifications</span>
            </a>
            <a href="#" class="nav-item" data-page="logout">
                <div class="nav-icon">
                    <i class="fas fa-sign-out-alt"></i>
                </div>
                <span>Logout</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <div class="hamburger"></div>
                </button>
                <?php
                $displayName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : $_SESSION['username'];
                $firstName = explode(' ', $displayName)[0];
                ?>
                <h1 class="welcome-text">Welcome, <?php echo htmlspecialchars($displayName); ?></h1>
                <h1 class="mobile-welcome">Welcome, <?php echo htmlspecialchars($firstName); ?></h1>
            </div>
            <div class="header-actions">
                <button class="settings-btn" title="Settings">
                    <i class="fas fa-cog"></i>
                </button>
                <?php
                $nameParts = explode(' ', $displayName);
                $initials = '';
                foreach ($nameParts as $part) {
                    if (!empty($part)) {
                        $initials .= strtoupper(substr($part, 0, 1));
                    }
                }
                $initials = substr($initials, 0, 2);
                ?>
                <div class="user-avatar" title="Profile"><?php echo htmlspecialchars($initials); ?></div>
            </div>
        </header>

        <!-- Content Area -->
        <div class="content">
            <!-- Dashboard Content -->
            <div id="dashboardContent" class="page-content active">
                <!-- NAIA Airports Summary -->
                <section class="report-section">
                    <div class="summary-cards">
                        <div class="summary-card">
                            <div class="summary-label">NAIA Airports Summary</div>
                            <div class="form-grid-2">
                                <div class="form-group">
                                    <label>Total Screeners</label>
                                    <input type="number" class="form-input" value="156" min="0">
                                </div>
                                <div class="form-group">
                                    <label>Active Terminals</label>
                                    <input type="number" class="form-input" value="8" min="0">
                                </div>
                            </div>
                        </div>
                        
                        <div class="summary-card">
                            <div class="summary-label">Outlying Airports Summary</div>
                            <div class="form-grid-2">
                                <div class="form-group">
                                    <label>Total Screeners</label>
                                    <input type="number" class="form-input" value="89" min="0">
                                </div>
                                <div class="form-group">
                                    <label>Active Airports</label>
                                    <input type="number" class="form-input" value="12" min="0">
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Live Feed of Interceptions -->
                <section class="activity-section">
                    <div class="activity-header">
                        <div class="activity-icon">
                            <i class="fas fa-rss" style="color: var(--primary-blue); font-size: 18px;"></i>
                        </div>
                        <div class="activity-title">Live Feed of Interceptions</div>
                        <div class="activity-subtitle" style="margin-left: auto;">
                            <span style="display: inline-flex; align-items: center;">
                                <i class="fas fa-circle" style="color: var(--notif-green); font-size: 8px; margin-right: 5px;"></i>
                                Real-time monitoring of prohibited items interception across all airports
                            </span>
                        </div>
                    </div>

                    <div class="activity-controls">
                        <input type="date" class="date-input" value="2025-08-21" id="interceptionDate">
                        <input type="text" class="search-input" placeholder="Search interceptions..." style="flex: 1;">
                    </div>

                    <div class="activity-item">
                        <div class="activity-avatar" style="background: var(--accent-red);">SA</div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>Suspected Ammo</strong> - 2 pcs</div>
                            <div class="activity-time">Davao Airport • Flight PR2813 to Bali • Male Terminal 1 • Reported by OTS Danilo</div>
                        </div>
                        <button class="action-btn view-btn" style="margin-left: auto;">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                    </div>

                    <div class="activity-item">
                        <div class="activity-avatar" style="background: var(--highlight-yellow); color: var(--text-primary);">FPC</div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>Firearms Parts & Components</strong> - 1 pc</div>
                            <div class="activity-time">NAIA Terminal 3 • Flight CEB456 to Dubai • Gate International • Reported by OTS Chua</div>
                        </div>
                        <button class="action-btn view-btn" style="margin-left: auto;">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                    </div>

                    <div class="activity-item">
                        <div class="activity-avatar" style="background: var(--primary-blue);">SE</div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>Suspected Empty Shell</strong> - 5 pcs</div>
                            <div class="activity-time">Iloilo Airport • Flight PR267 to General Santos • Departure Lounge • Reported by OTS Rivera</div>
                        </div>
                        <button class="action-btn view-btn" style="margin-left: auto;">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                    </div>

                    <div class="activity-item">
                        <div class="activity-avatar" style="background: var(--accent-dark-red);">F</div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>Firearms</strong> - 1 pc</div>
                            <div class="activity-time">Bohol Airport • Flight PR803 to Manila • Gate 4 • Reported by OC Santos</div>
                        </div>
                        <button class="action-btn view-btn" style="margin-left: auto;">
                            <i class="fas fa-eye"></i> View Details
                        </button>
                    </div>

                    <div class="activity-footer">
                        <div class="activity-footer-text">Live feed updates every 30 seconds. Click "View Details" for complete interception reports.</div>
                    </div>
                </section>
            </div>

            <!-- List of Airports Content -->
            
<div id="airportsContent" class="page-content">
    <!-- Airport Cards View (Read-Only) -->
    <div id="airportCardsView">
        <section class="reports-header-section">
            <div class="reports-title-bar">
                <div class="reports-icon">
                    <i class="fas fa-building"></i>
                </div>
                <div>
                    <h2 class="reports-title">Dashboard</h2>
                    <div class="reports-subtitle">Manage user accounts by terminal</div>
                </div>
            </div>

            <div class="activity-controls">
                <input type="text" id="dashboardTerminalSearch" class="search-input" placeholder="Search terminals..." style="max-width: 400px;">
            </div>
        </section>

        <!-- User Role Statistics Cards -->
        <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px; margin-bottom: 24px;">
            <div class="stat-card" style="background: white; padding: 24px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                <div class="stat-label" style="color: var(--text-secondary); font-size: 14px; margin-bottom: 8px;">IT Admin</div>
                <div class="stat-value" id="itAdminCount" style="font-size: 32px; font-weight: 700; color: var(--primary-blue);">0</div>
            </div>
            <div class="stat-card" style="background: white; padding: 24px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                <div class="stat-label" style="color: var(--text-secondary); font-size: 14px; margin-bottom: 8px;">Executive User</div>
                <div class="stat-value" id="executiveCount" style="font-size: 32px; font-weight: 700; color: var(--primary-blue);">0</div>
            </div>
            <div class="stat-card" style="background: white; padding: 24px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                <div class="stat-label" style="color: var(--text-secondary); font-size: 14px; margin-bottom: 8px;">Airport Admin</div>
                <div class="stat-value" id="airportAdminCount" style="font-size: 32px; font-weight: 700; color: var(--primary-blue);">0</div>
            </div>
            <div class="stat-card" style="background: white; padding: 24px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                <div class="stat-label" style="color: var(--text-secondary); font-size: 14px; margin-bottom: 8px;">Airport User</div>
                <div class="stat-value" id="airportUserCount" style="font-size: 32px; font-weight: 700; color: var(--primary-blue);">0</div>
            </div>
        </div>

        <div id="terminalCardsContainer" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 20px;">
            <!-- Executive and IT Admin Card - Always shown -->
            <div class="category-card airport-card" data-airport="executive_itadmin" style="background: white; padding: 24px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); transition: transform 0.2s;">
                <div style="text-align: center; margin-bottom: 16px;">
                    <i class="fas fa-user-tie" style="font-size: 48px; color: var(--success-green);"></i>
                </div>
                <h4 class="category-title" style="text-align: center; margin-bottom: 16px; font-size: 18px; font-weight: 600;">Executive and IT Admin</h4>
                <ul class="category-list" style="list-style: none; padding: 0; margin: 0 0 16px 0;">
                    <li style="padding: 8px 0;">0 Total Users</li>
                    <li style="padding: 8px 0;">0 Executives</li>
                    <li style="padding: 8px 0;">0 IT Admins</li>
                </ul>
                <div style="text-align: center; margin-top: 16px;">
                    <button class="action-btn view-btn" style="background: var(--primary-blue); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; display: inline-flex; align-items: center; gap: 8px;">
                        <i class="fas fa-eye"></i> View Users
                    </button>
                </div>
            </div>
            
            <!-- Terminal cards will be loaded dynamically here -->
        </div>
    </div>

    <!-- User Table View (Read-Only) -->
    <div id="userTableView" class="user-table-view" style="display: none;">
        <section class="reports-header-section">
            <div class="reports-title-bar">
                <div class="reports-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div>
                    <h2 class="reports-title">Dashboard - <span id="selectedTerminal"></span></h2>
                    <div class="reports-subtitle">User accounts for selected terminal</div>
                </div>
                <button class="action-btn edit-btn" id="backToAirports" style="background: var(--primary-blue); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-size: 14px;">
                    <i class="fas fa-arrow-left"></i> Back to Terminals
                </button>
            </div>

            <div class="activity-controls">
                <input type="text" class="search-input" id="userSearch" placeholder="Search by name, role, or ID...">
                <select class="filter-select" id="roleFilter">
                    <option value="">All Roles</option>
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                    <option value="executive">Executive</option>
                    <option value="it_admin">IT Admin</option>
                </select>
            </div>
        </section>

        <div class="table-container" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
            <table class="data-table" style="width: 100%; border-collapse: collapse;">
                <thead style="background: var(--light-bg);">
                    <tr>
                        <th style="padding: 16px; text-align: left; font-weight: 600; color: var(--text-secondary); font-size: 14px;">User</th>
                        <th style="padding: 16px; text-align: left; font-weight: 600; color: var(--text-secondary); font-size: 14px;">Role</th>
                        <th style="padding: 16px; text-align: left; font-weight: 600; color: var(--text-secondary); font-size: 14px;">Complete Name</th>
                        <th style="padding: 16px; text-align: left; font-weight: 600; color: var(--text-secondary); font-size: 14px;">Date Created</th>
                    </tr>
                </thead>
                <tbody id="usersTableBody">
                    <tr>
                        <td colspan="4" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                            <i class="fas fa-spinner fa-spin" style="font-size: 24px; margin-bottom: 8px;"></i>
                            <div>Loading users...</div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

            <!-- Reports Management Content -->
            <div id="reportsManagementContent" class="page-content">
                <section class="reports-header-section">
                    <div class="reports-title-bar">
                        <div class="reports-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div>
                            <h2 class="reports-title">System-wide Reports Management</h2>
                        </div>
                    </div>

                    <div class="activity-controls">
                        <div style="display: flex; align-items: center; gap: 8px;">
                            <input type="date" id="reportDate" class="date-input" value="2025-08-21">
                        </div>
                        <select class="filter-select" id="executiveTypeFilter">
                            <option value="">All Reports</option>
                            <option value="daily">Daily Report</option>
                            <option value="interception">Interception Report</option>
                        </select>
                        <select class="filter-select" id="executiveUserFilter">
                            <option value="">All Submitters</option>
                        </select>
                        <select class="filter-select" id="executiveStationFilter">
                            <option value="">All Stations</option>
                            <option value="naia1">NAIA Terminal 1</option>
                            <option value="naia2">NAIA Terminal 2</option>
                            <option value="naia3">NAIA Terminal 3</option>
                            <option value="clark">Clark International Airport</option>
                            <option value="cebu">Cebu Mactan</option>
                            <option value="davao">Davao International</option>
                        </select>
                        <input type="text" class="search-input" id="executiveSearchInput" placeholder="Search reports..." style="flex: 1;">
                    </div>

                    <div class="reports-showing" id="executiveReportsShowing">Loading reports...</div>
                </section>

                <section class="reports-table-container">
                    <table class="reports-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Submitted By</th>
                                <th>Passenger Name</th>
                                <th>Date & Time</th>
                                <th>Terminal</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="executiveReportsTableBody">
                        </tbody>
                    </table>
                </section>
            </div>
        </div>
    </main>

    <script>
        // Load all reports for executive
        function loadAllReportsForExecutive() {
            Promise.all([
                fetch('../BACKEND/get_all_daily_reports.php').then(r => r.json()),
                fetch('../BACKEND/get_all_interception_reports.php').then(r => r.json())
            ])
            .then(([dailyData, interceptionData]) => {
                const allReports = [];
                
                if (dailyData.success) {
                    dailyData.reports.forEach(report => {
                        report.type = 'daily';
                        allReports.push(report);
                    });
                }
                
                if (interceptionData.success) {
                    interceptionData.reports.forEach(report => {
                        report.type = 'interception';
                        allReports.push(report);
                    });
                }
                
                allReports.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                
                displayAllReportsExecutive(allReports);
            })
            .catch(error => console.error('Error loading reports:', error));
        }

        function displayAllReportsExecutive(reports) {
            const tbody = document.getElementById('executiveReportsTableBody');
            if (!tbody) return;
            
            tbody.innerHTML = '';
            
            if (reports.length === 0) {
                tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 30px; color: var(--text-secondary);">No reports found</td></tr>';
                document.getElementById('executiveReportsShowing').textContent = 'Showing 0 reports';
                return;
            }
            
            reports.forEach(report => {
    const reportDate = new Date(report.report_date).toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: '2-digit' 
    });
    const createdAt = new Date(report.created_at);
    const timeStr = createdAt.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    const dateTimeStr = `${reportDate}<br><small style="color: var(--text-secondary);">${timeStr}</small>`;
    
    const row = document.createElement('tr');
    row.setAttribute('data-type', report.type);
    row.setAttribute('data-user', report.username);
    row.setAttribute('data-date', report.report_date);
    
    let reportTypeName = '';
    let passengerName = '';
    
    if (report.type === 'daily') {
        reportTypeName = 'Daily Report';
        passengerName = '<span style="color: var(--text-secondary); font-style: italic;">N/A</span>';
    } else {
        reportTypeName = 'Interception Report';
        passengerName = report.passenger_name || '<span style="color: var(--text-secondary);">Unknown</span>';
    }
    
    // Get terminal name or default
    const terminalName = report.terminal_assignment || 'Unknown';
    
    row.innerHTML = `
        <td>
            <span style="display: flex; align-items: center; gap: 6px;">
                <i class="fas ${report.type === 'daily' ? 'fa-file-alt' : 'fa-shield-alt'}" style="color: ${report.type === 'daily' ? 'var(--primary-blue)' : 'var(--accent-red)'};"></i>
                ${reportTypeName}
            </span>
        </td>
        <td class="report-submitter">
            ${report.username}<br>
            <small style="color: var(--text-secondary);">User</small>
        </td>
        <td>${passengerName}</td>
        <td class="report-time">${dateTimeStr}</td>
        <td>${terminalName}</td>
        <td>
            <div class="report-actions">
                <button class="action-btn view-btn" onclick="viewExecutiveReport(${report.id}, '${report.type}')">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="action-btn" style="background: var(--notif-green); color: white;" onclick="downloadReportPDF(${report.id}, '${report.type}')">
                    <i class="fas fa-download"></i>
                </button>
            </div>
        </td>
    `;
    
    tbody.appendChild(row);
});
            
            const showingElement = document.getElementById('executiveReportsShowing');
            if (showingElement) {
                showingElement.textContent = `Showing ${reports.length} reports`;
            }
        }

        // Download report as PDF
        function downloadReportPDF(reportId, reportType) {
            window.open(
                `../BACKEND/generate_report_pdf.php?report_id=${reportId}&report_type=${reportType}`,
                '_blank'
            );
        }

        // View report details
        function viewExecutiveReport(reportId, reportType) {
            fetch(`../BACKEND/get_report_details.php?report_id=${reportId}&report_type=${reportType}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showReportModal(data.report, reportType);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network error: ' + error.message);
                });
        }

        // Show report modal
        function showReportModal(report, reportType) {
            const modalHTML = `
                <div class="report-modal" id="reportModal">
                    <div class="report-modal-content">
                        <div class="report-modal-header">
                            <h3>${reportType === 'daily' ? 'Daily Report' : 'Interception Report'} Details</h3>
                            <button class="close-modal" onclick="closeReportModal()">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="report-modal-body">
                            ${reportType === 'daily' ? generateDailyReportHTML(report) : generateInterceptionReportHTML(report)}
                        </div>
                        <div class="report-modal-footer">
                            <button class="btn-close" onclick="closeReportModal()">
                                <i class="fas fa-times"></i> Close
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            document.getElementById('reportModal').style.display = 'flex';
        }

        function closeReportModal() {
            const modal = document.getElementById('reportModal');
            if (modal) {
                modal.remove();
            }
        }

        function generateDailyReportHTML(report) {
            return `
                <div class="report-info">
                    <div class="info-row"><strong>Submitted By:</strong> ${report.username || 'Unknown'}</div>
                    <div class="info-row"><strong>Date:</strong> ${report.report_date}</div>
                    <div class="info-row"><strong>Shift:</strong> ${report.shift}</div>
                    <div class="info-row"><strong>Team:</strong> ${report.team}</div>
                    <div class="info-row"><strong>Status:</strong> ${report.status}</div>
                </div>
                
                <h4>Personnel Data</h4>
                <div class="report-info">
                    <div class="info-row"><strong>On Duty:</strong> ${report.screeners_on_duty}</div>
                    <div class="info-row"><strong>Off Duty:</strong> ${report.screeners_off || 0}</div>
                    <div class="info-row"><strong>On Leave:</strong> ${report.screeners_on_leave || 0}</div>
                    <div class="info-row"><strong>Absent:</strong> ${report.screeners_absent || 0}</div>
                </div>
                
                <h4>Flight Summary</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Domestic Flights:</strong> ${report.domestic_departing_flights} (${report.domestic_passengers} passengers)</div>
                    <div class="info-row"><strong>International Flights:</strong> ${report.international_departing_flights} (${report.international_passengers} passengers)</div>
                </div>
                
                <h4>Prohibited Items</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Blunt Instruments:</strong> ${report.blunt_instruments}</div>
                    <div class="info-row"><strong>Sharp Objects:</strong> ${report.sharp_objects}</div>
                    <div class="info-row"><strong>Liquids/Gels:</strong> ${report.liquid_aerosols_gels}</div>
                </div>
                
                ${report.additional_notes ? `
                    <h4>Additional Notes</h4>
                    <div class="report-info">
                        <p>${report.additional_notes}</p>
                    </div>
                ` : ''}
            `;
        }

        function generateInterceptionReportHTML(report) {
            return `
                <div class="report-info">
                    <div class="info-row"><strong>Submitted By:</strong> ${report.username || 'Unknown'}</div>
                    <div class="info-row"><strong>Date:</strong> ${report.report_date}</div>
                    <div class="info-row"><strong>Shift:</strong> ${report.shift}</div>
                    <div class="info-row"><strong>Team:</strong> ${report.team}</div>
                </div>
                
                <h4>Passenger Information</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Name:</strong> ${report.passenger_name}</div>
                    <div class="info-row"><strong>Occupation:</strong> ${report.occupation}</div>
                </div>
                
                <h4>Flight Details</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Flight Number:</strong> ${report.flight_number}</div>
                    <div class="info-row"><strong>Destination:</strong> ${report.destination || 'N/A'}</div>
                </div>
                
                <h4>Intercepted Item</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Item:</strong> ${report.intercepted_item}</div>
                    <div class="info-row"><strong>Quantity:</strong> ${report.quantity}</div>
                </div>
                
                ${report.xray_operator || report.baggage_pusher ? `
                    <h4>Intercepted By</h4>
                    <div class="report-info">
                        ${report.xray_operator ? `<div class="info-row"><strong>X-ray Operator:</strong> ${report.xray_operator}</div>` : ''}
                        ${report.baggage_pusher ? `<div class="info-row"><strong>Baggage Inspector:</strong> ${report.baggage_pusher}</div>` : ''}
                    </div>
                ` : ''}
                
                ${report.remarks ? `
                    <h4>Remarks</h4>
                    <div class="report-info">
                        <p>${report.remarks}</p>
                    </div>
                ` : ''}
            `;
        }

        // Personnel Modal Functions
        function showPersonnelModal(airportName, chief, totalPersonnel, totalSSOs, admins, shiftCharges, supervisors, maleSSOs, femaleSSOs) {
            const modal = document.getElementById('personnelModal');
            document.getElementById('modalTitle').textContent = `Personnel Information - ${airportName}`;
            document.getElementById('modalSubtitle').textContent = `Detailed personnel breakdown for this airport`;
            document.getElementById('modalChief').textContent = chief;
            document.getElementById('modalTotalPersonnel').textContent = totalPersonnel;
            document.getElementById('modalAdmins').textContent = admins;
            document.getElementById('modalShiftCharges').textContent = shiftCharges;
            document.getElementById('modalSupervisors').textContent = supervisors;
            document.getElementById('modalTotalSSOs').textContent = totalSSOs;
            document.getElementById('modalMaleSSOs').textContent = maleSSOs;
            document.getElementById('modalFemaleSSOs').textContent = femaleSSOs;
            
            modal.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeModal() {
            const modal = document.getElementById('personnelModal');
            modal.classList.remove('active');
            document.body.style.overflow = '';
        }

        document.getElementById('personnelModal').addEventListener('click', (e) => {
            if (e.target === e.currentTarget) {
                closeModal();
            }
        });

        // Auto-refresh reports every 30 seconds
        let autoRefreshInterval;

        function startAutoRefresh() {
    autoRefreshInterval = setInterval(() => {
        const activeContent = document.querySelector('.page-content.active');
        
        if (activeContent && activeContent.id === 'reportsManagementContent') {
            loadAllReportsForExecutive();
        }
    }, 30000);
}

        function stopAutoRefresh() {
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
            }
        }

        // Mobile menu toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const sidebarClose = document.getElementById('sidebarClose');

        function openSidebar() {
            sidebar.classList.add('active');
            mobileMenuToggle.classList.add('active');
            sidebarOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeSidebar() {
            sidebar.classList.remove('active');
            mobileMenuToggle.classList.remove('active');
            sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        mobileMenuToggle.addEventListener('click', () => {
            if (sidebar.classList.contains('active')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });

        sidebarClose.addEventListener('click', closeSidebar);
        sidebarOverlay.addEventListener('click', closeSidebar);

        const settingsBtn = document.querySelector('.settings-btn');
        settingsBtn.addEventListener('click', () => {
            alert('Settings panel - This would open settings configuration');
        });

        const userAvatar = document.querySelector('.user-avatar');
        userAvatar.addEventListener('click', () => {
            alert('Profile menu - This would show user profile options');
        });

        const navItems = document.querySelectorAll('.nav-item');
        const pageContents = document.querySelectorAll('.page-content');

        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                
                const targetPage = item.getAttribute('data-page');
                
                if (targetPage === 'logout') {
                    if (confirm('Are you sure you want to logout?')) {
                        window.location.href = '../BACKEND/logout.php';
                    }
                    return;
                }
                
                navItems.forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');
                
                pageContents.forEach(page => page.classList.remove('active'));
                
                if (targetPage === 'dashboard') {
                    document.getElementById('dashboardContent').classList.add('active');
                    stopAutoRefresh();
                } else if (targetPage === 'airports') {
                    document.getElementById('airportsContent').classList.add('active');
                    stopAutoRefresh();
                } else if (targetPage === 'reportsManagement') {
                    document.getElementById('reportsManagementContent').classList.add('active');
                    loadAllReportsForExecutive();
                    startAutoRefresh();
                } else {
                    alert(`${item.querySelector('span').textContent} page coming soon!`);
                    document.querySelector('.nav-item[data-page="dashboard"]').classList.add('active');
                    document.getElementById('dashboardContent').classList.add('active');
                    stopAutoRefresh();
                }
                
                if (window.innerWidth <= 1024) {
                    closeSidebar();
                }
            });
        });

        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                if (window.innerWidth > 1024) {
                    closeSidebar();
                }
            }, 250);
        });

        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 1024) {
                if (!sidebar.contains(e.target) && 
                    !mobileMenuToggle.contains(e.target) && 
                    sidebar.classList.contains('active')) {
                    closeSidebar();
                }
            }
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeModal();
                closeReportModal();
            }
        });

        document.addEventListener('DOMContentLoaded', () => {
            loadAllReportsForExecutive();
        });


        // ===================================
// AIRPORTS PAGE (READ-ONLY DASHBOARD)
// ===================================

let allUsers = [];
let currentTerminal = '';

// Load terminals on page load
async function loadTerminalsForExecutive() {
    try {
        const response = await fetch('../BACKEND/get_terminals.php');
        const data = await response.json();
        
        if (data.success && data.terminals) {
            const container = document.getElementById('terminalCardsContainer');
            
            // CRITICAL FIX: Remove all existing terminal cards (except Executive and IT Admin card)
            // Get all airport cards that are NOT the executive_itadmin card
            const existingTerminalCards = container.querySelectorAll('.airport-card:not([data-airport="executive_itadmin"])');
            existingTerminalCards.forEach(card => card.remove());
            
            // Now add terminal cards from the database
            data.terminals.forEach(terminal => {
                const card = document.createElement('div');
                card.className = 'category-card airport-card';
                card.setAttribute('data-airport', terminal.terminal_code);
                card.style.cssText = 'background: white; padding: 24px; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); transition: transform 0.2s; cursor: pointer;';
                
                card.innerHTML = `
    <div style="text-align: center; margin-bottom: 16px;">
        <i class="fas fa-building" style="font-size: 48px; color: var(--primary-blue);"></i>
    </div>
    <h4 class="category-title" style="text-align: center; margin-bottom: 16px; font-size: 18px; font-weight: 600;">${terminal.terminal_name}</h4>
    <ul class="category-list" style="list-style: none; padding: 0; margin: 0 0 16px 0;">
        <li style="padding: 8px 0;">0 Total Users</li>
        <li style="padding: 8px 0;">0 Users</li>
        <li style="padding: 8px 0;">0 Admins</li>
    </ul>
    <div style="text-align: center; margin-top: 16px;">
        <button class="action-btn view-btn" style="background: var(--primary-blue); color: white; border: none; padding: 10px 20px; border-radius: 8px; cursor: pointer; font-size: 14px; display: inline-flex; align-items: center; gap: 8px;">
            <i class="fas fa-eye"></i> View Users
        </button>
    </div>
`;
                
                // Add click handler for View button
                card.querySelector('.action-btn').addEventListener('click', (e) => {
                    e.stopPropagation();
                    currentTerminal = terminal.terminal_code;
                    document.getElementById('selectedTerminal').textContent = terminal.terminal_name;
                    document.getElementById('airportCardsView').style.display = 'none';
                    document.getElementById('userTableView').style.display = 'block';
                    loadUsersForExecutive(terminal.terminal_code);
                });
                
                container.appendChild(card);
            });
            
            // Load statistics after cards are created
            loadTerminalStatsForExecutive();
        }
    } catch (error) {
        console.error('Error loading terminals:', error);
    }
}

// Load terminal statistics
async function loadTerminalStatsForExecutive() {
    try {
        const response = await fetch('../BACKEND/get_terminal_stats.php');
        const data = await response.json();
        
        if (data.success) {
            updateTerminalCardsForExecutive(data.stats);
        }
    } catch (error) {
        console.error('Error loading terminal stats:', error);
    }
}

// Load user role statistics
async function loadUserRoleStatsForExecutive() {
    try {
        const response = await fetch('../BACKEND/get_user_role_stats.php');
        const data = await response.json();
        
        if (data.success) {
            document.getElementById('itAdminCount').textContent = data.stats.it_admin;
            document.getElementById('executiveCount').textContent = data.stats.executive;
            document.getElementById('airportAdminCount').textContent = data.stats.airport_admin;
            document.getElementById('airportUserCount').textContent = data.stats.airport_user;
        }
    } catch (error) {
        console.error('Error loading user role stats:', error);
    }
}

function updateTerminalCardsForExecutive(stats) {
    // Update Executive and IT Admin card
    const execCard = document.querySelector('.airport-card[data-airport="executive_itadmin"]');
    if (execCard && stats['executive_itadmin']) {
        const stat = stats['executive_itadmin'];
        const list = execCard.querySelector('.category-list');
        list.innerHTML = `
            <li style="padding: 8px 0;">${stat.total_users} Total Users</li>
            <li style="padding: 8px 0;">${stat.executives} Executives</li>
            <li style="padding: 8px 0;">${stat.it_admins} IT Admins</li>
        `;
    }
    
    // Update ALL terminal cards dynamically
    for (const terminalCode in stats) {
        if (terminalCode === 'executive_itadmin') continue;
        
        const card = document.querySelector(`.airport-card[data-airport="${terminalCode}"]`);
        if (card && stats[terminalCode]) {
            const stat = stats[terminalCode];
            const list = card.querySelector('.category-list');
            list.innerHTML = `
                <li style="padding: 8px 0;">${stat.total_users} Total Users</li>
                <li style="padding: 8px 0;">${stat.users} Users</li>
                <li style="padding: 8px 0;">${stat.admins} Admins</li>
            `;
        }
    }
}

// Search functionality for Dashboard terminals
document.getElementById('dashboardTerminalSearch')?.addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase().trim();
    const terminalCards = document.querySelectorAll('.airport-card');
    
    terminalCards.forEach(card => {
        const terminalTitle = card.querySelector('.category-title');
        if (terminalTitle) {
            const titleText = terminalTitle.textContent.toLowerCase();
            card.style.display = titleText.includes(searchTerm) ? 'block' : 'none';
        }
    });
});

// Back to terminals button
document.getElementById('backToAirports')?.addEventListener('click', () => {
    document.getElementById('airportCardsView').style.display = 'block';
    document.getElementById('userTableView').style.display = 'none';
    currentTerminal = '';
});

// Load users for terminal (READ-ONLY)
async function loadUsersForExecutive(terminal) {
    try {
        const response = await fetch(`../BACKEND/get_users.php?terminal=${terminal}`);
        const data = await response.json();
        
        if (data.success) {
            allUsers = data.users;
            renderUserTableForExecutive(allUsers);
        }
    } catch (error) {
        console.error('Error loading users:', error);
    }
}

// Render user table (READ-ONLY)
function renderUserTableForExecutive(users) {
    const tbody = document.getElementById('usersTableBody');
    tbody.innerHTML = '';
    
    if (users.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 20px;">No users found</td></tr>';
        return;
    }
    
    users.forEach(user => {
        const row = document.createElement('tr');
        row.style.cssText = 'border-bottom: 1px solid var(--border-color); transition: background 0.2s;';
        row.onmouseover = function() { this.style.background = 'var(--light-bg)'; };
        row.onmouseout = function() { this.style.background = 'white'; };
        
        const dateCreated = user.created_at ? new Date(user.created_at).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'short', 
            day: '2-digit' 
        }) : 'N/A';
        
        row.innerHTML = `
            <td style="padding: 16px;">
                <div style="font-weight: 500;">${user.username}</div>
                <div style="font-size: 12px; color: #888;">${user.username}</div>
            </td>
            <td style="padding: 16px;">
                <span class="role-badge role-${user.role}" style="display: inline-block; padding: 4px 12px; border-radius: 12px; font-size: 12px; font-weight: 500; ${getRoleBadgeStyle(user.role)}">
                    ${getRoleDisplayName(user.role)}
                </span>
            </td>
            <td style="padding: 16px;">${user.full_name || 'N/A'}</td>
            <td style="padding: 16px;">${dateCreated}</td>
        `;
        
        tbody.appendChild(row);
    });
}

// Get role display name (matching IT Admin)
function getRoleDisplayName(role) {
    const roleNames = {
        'user': 'User',
        'admin': 'Admin',
        'executive': 'Executive',
        'it_admin': 'IT Admin'
    };
    return roleNames[role] || role;
}

// Get role badge styling (matching IT Admin)
function getRoleBadgeStyle(role) {
    const roleStyles = {
        'it_admin': 'background: #e3f2fd; color: #1976d2;',
        'executive': 'background: #f3e5f5; color: #7b1fa2;',
        'admin': 'background: #fff3e0; color: #ef6c00;',
        'user': 'background: #e8f5e9; color: #388e3c;'
    };
    return roleStyles[role] || roleStyles['user'];
}

// User search functionality
document.getElementById('userSearch')?.addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const roleFilter = document.getElementById('roleFilter').value;
    
    const filteredUsers = allUsers.filter(user => {
        const matchesSearch = 
            user.username.toLowerCase().includes(searchTerm) ||
            (user.full_name && user.full_name.toLowerCase().includes(searchTerm)) ||
            user.id.toString().includes(searchTerm);
        
        const matchesRole = !roleFilter || user.role === roleFilter;
        
        return matchesSearch && matchesRole;
    });
    
    renderUserTableForExecutive(filteredUsers);
});

// Role filter functionality
document.getElementById('roleFilter')?.addEventListener('change', function() {
    const searchTerm = document.getElementById('userSearch').value.toLowerCase();
    const roleFilter = this.value;
    
    const filteredUsers = allUsers.filter(user => {
        const matchesSearch = 
            user.username.toLowerCase().includes(searchTerm) ||
            (user.full_name && user.full_name.toLowerCase().includes(searchTerm)) ||
            user.id.toString().includes(searchTerm);
        
        const matchesRole = !roleFilter || user.role === roleFilter;
        
        return matchesSearch && matchesRole;
    });
    
    renderUserTableForExecutive(filteredUsers);
});

// Initialize when airports page is shown
document.querySelector('.nav-item[data-page="airports"]')?.addEventListener('click', function() {
    // Small delay to ensure DOM is ready
    setTimeout(() => {
        loadTerminalsForExecutive();
        loadUserRoleStatsForExecutive();
    }, 100);
});

// Auto-refresh every 30 seconds when on airports page
let airportsRefreshInterval;

function startAirportsRefresh() {
    stopAirportsRefresh();
    airportsRefreshInterval = setInterval(() => {
        const airportsContent = document.getElementById('airportsContent');
        if (airportsContent && airportsContent.classList.contains('active')) {
            loadTerminalStatsForExecutive();
            loadUserRoleStatsForExecutive();
        }
    }, 30000); // 30 seconds
}

function stopAirportsRefresh() {
    if (airportsRefreshInterval) {
        clearInterval(airportsRefreshInterval);
        airportsRefreshInterval = null;
    }
}

// Start refresh when airports page is active
document.querySelector('.nav-item[data-page="airports"]')?.addEventListener('click', startAirportsRefresh);


    </script>
</body>
</html>