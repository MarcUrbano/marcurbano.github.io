<?php
// Require authentication with 'admin' role
require_once 'auth_check.php';
requireAuth('it_admin');
checkSessionTimeout();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SRS - NAIA Terminal 1 Dashboard</title>
    <link rel="icon" type="images/png" href="../Logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../ACCOUNTS/style.css">
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="../Logo.png" alt="Logo">
            </div>
            <div class="sidebar-title">SRS - NAIA<br>TERMINAL 1</div>
            <button class="sidebar-close" id="sidebarClose">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <nav class="nav-section">
            <a href="#" class="nav-item active" data-page="dashboard">
                <div class="nav-icon">
                    <i class="fas fa-users"></i>
                </div>
                <span>Dashboard</span>
            </a>
            <a href="#" class="nav-item" data-page="allReports">
                <div class="nav-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <span>All Reports</span>
            </a>
            <a href="#" class="nav-item" data-page="actionLogs">
                <div class="nav-icon">
                    <i class="fas fa-history"></i>
                </div>
                <span>Action Logs</span>
            </a>
            
            <div class="nav-divider"></div>
            
            <a href="#" class="nav-item" data-page="settings">
                <div class="nav-icon">
                    <i class="fas fa-cogs"></i>
                </div>
                <span>System Settings</span>
            </a>
            <a href="#" class="nav-item" data-page="notifications">
                <div class="nav-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <span>Notifications</span>
            </a>
            
            <a href="../BACKEND/logout.php" class="nav-item" data-page="logout">
                <div class="nav-icon">
                    <i class="fas fa-sign-out-alt"></i>
                </div>
                <span>Logout</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <div class="hamburger"></div>
                </button>
                <?php
                $displayName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : $_SESSION['username'];
                $firstName = explode(' ', $displayName)[0];
                ?>
                <h1 class="welcome-text">Welcome, <?php echo htmlspecialchars($displayName); ?></h1>
                <h1 class="mobile-welcome">Welcome, <?php echo htmlspecialchars($firstName); ?></h1>
            </div>
            <div class="header-actions">
                <button class="settings-btn" title="Settings">
                    <i class="fas fa-cog"></i>
                </button>
                <?php
                // Generate initials from full name
                $nameParts = explode(' ', $displayName);
                $initials = '';
                foreach ($nameParts as $part) {
                    if (!empty($part)) {
                        $initials .= strtoupper(substr($part, 0, 1));
                    }
                }
                // Limit to 2 characters
                $initials = substr($initials, 0, 2);
                ?>
                <div class="user-avatar" title="Profile"><?php echo htmlspecialchars($initials); ?></div>
            </div>
        </header>

        <!-- Content Area -->
        <div class="content">

            <!-- User Management Content -->
            <div id="dashboardContent" class="page-content active">
                <div id="airportCardsView">
                    <section class="reports-header-section">
                    <div class="reports-title-bar">
                        <div class="reports-icon">
                            <i class="fas fa-user"></i>
                        </div>
                        <div>
                            <h2 class="reports-title">Dashboard</h2>
                            <div class="reports-subtitle">Manage user accounts by terminal</div>
                        </div>
                    </div>
    
                    <!-- Search Bar in the middle -->
                    <div class="activity-controls" style="justify-content: center; margin: 20px 0;">
                        <input type="text" class="search-input" id="dashboardTerminalSearch" placeholder="Search terminals..." style="max-width: 400px;">
    
                    <!-- Buttons -->
                    
                        <button class="action-btn edit-btn" onclick="showAddTerminalModal()">
                            <i class="fas fa-building"></i> Add Airport
                        </button>
                        <button class="action-btn edit-btn" onclick="showAddUserModal()">
                            <i class="fas fa-user-plus"></i> Add User
                        </button>
                    </div>
                </section>


<!-- User Role Statistics Cards -->
<div class="stats-grid" style="margin-bottom: 24px;">
    <div class="stat-card">
        <div class="stat-label">IT Admin</div>
        <div class="stat-value" id="itAdminCount">0</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Executive User</div>
        <div class="stat-value" id="executiveCount">0</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Airport Admin</div>
        <div class="stat-value" id="airportAdminCount">0</div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Airport User</div>
        <div class="stat-value" id="airportUserCount">0</div>
    </div>
</div>

                    <div id="terminalCardsContainer" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(350px, 1fr)); gap: 20px;">

                    <!-- Executive and IT Admin Card - Always shown -->
                        <div class="category-card airport-card" data-airport="executive_itadmin">
                            <div style="text-align: center; margin-bottom: 16px;">
                                <i class="fas fa-user-tie" style="font-size: 48px; color: var(--success-green);"></i>
                            </div>
                            <h4 class="category-title" style="text-align: center;">Executive and IT Admin</h4>
                            <ul class="category-list">
                                <li>0 Total Users</li>
                                <li>0 Executives</li>
                                <li>0 IT Admins</li>
                            </ul>
                            <div style="text-align: center; margin-top: 16px;">
                                <button class="action-btn view-btn">
                                    <i class="fas fa-users"></i> Manage Users
                                </button>
                            </div>
                        </div>
                        
                        <!-- Terminal cards will be loaded dynamically here -->
                    </div>
                </div>

                <!-- User Table View -->
                <div id="userTableView" class="user-table-view" style="display: none;">
                    <section class="reports-header-section">
                        <div class="reports-title-bar">
                            <div class="reports-icon">
                                <i class="fas fa-users"></i>
                            </div>
                            <div>
                                <h2 class="reports-title">Dashboard - <span id="selectedTerminal"></span></h2>
                                <div class="reports-subtitle">User management for selected terminal</div>
                            </div>
                            <button class="action-btn edit-btn" id="backToAirports">
                                <i class="fas fa-arrow-left"></i> Back to Terminals
                            </button>
                        </div>

                        <div class="activity-controls">
                            <input type="text" class="search-input" placeholder="Search by name, role, or ID...">
                            <select class="filter-select" id="roleFilter">
                                <option value="">All Roles</option>
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                                <option value="executive">Executive</option>
                                <option value="it_admin">IT Admin</option>
                            </select>
                            <select class="filter-select">
                                <option value="">All Status</option>
                                <option value="active">Active</option>
                                <option value="inactive">Inactive</option>
                                <option value="suspended">Suspended</option>
                            </select>
                        </div>
                    </section>

                    <section class="reports-table-container">
                        <table class="reports-table">
                            <thead>
                                <tr>
                                    <th>User</th>
                                    <th>Role</th>
                                    <th>Complete Name</th>
                                    <th>Date Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody id="usersTableBody">
                                <!-- Users will be loaded here -->
                            </tbody>
                        </table>
                    </section>
                </div>
            </div>

            <!-- All Reports Content -->
            <div id="allReportsContent" class="page-content">
                <section class="reports-header-section">
                    <div class="reports-title-bar">
                        <div class="reports-icon" style="background: var(--primary-blue);">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div>
                            <h2 class="reports-title">All Reports</h2>
                            <div class="reports-subtitle" id="superAdminReportsShowing">All system reports</div>
                        </div>
                    </div>
                    
                    <div class="activity-controls">
    <input type="text" class="search-input" id="superAdminSearch" placeholder="Search by Passenger Name or User Name">
    <input type="date" class="filter-select" id="superAdminDateFilter">
    <select class="filter-select" id="superAdminTerminalFilter">
        <option value="">All Terminals</option>
        <!-- Terminals will be loaded dynamically -->
    </select>
    <select class="filter-select" id="superAdminTypeFilter">
        <option value="">Type of Report</option>
        <option value="daily">Daily Report</option>
        <option value="interception">Interception Report</option>
    </select>
</div>
                </section>

                <section class="reports-table-container">
                    <table class="reports-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Passenger Name</th>
                                <th>Submitted By</th>
                                <th>Date & Time</th>
                                <th>Terminal</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="superAdminReportsTableBody">
                            <!-- Reports will be loaded here -->
                        </tbody>
                    </table>
                </section>
            </div>

            <!-- Action Logs Content -->
                <div id="actionLogsContent" class="page-content">
                    <section class="reports-header-section">
                        <div class="reports-title-bar">
                            <div class="reports-icon" style="background: var(--notif-green);">
                                <i class="fas fa-history"></i>
                            </div>
                            <div>
                                <h2 class="reports-title">Action Logs</h2>
                            </div>
                        </div>
                        
                        <div class="reports-showing" id="itAdminActionLogsShowing">
                            Action logs are automatically recorded for all system activities and administrative actions.
                        </div>
                    </section>

                    <section class="reports-table-container">
                        <table class="reports-table">
                            <thead>
                                <tr>
                                    <th>Activity</th>
                                    <th>Description</th>
                                    <th>Date & Time</th>
                                </tr>
                            </thead>
                            <tbody id="itAdminActionLogsTableBody">
                                <!-- Logs will be loaded here -->
                            </tbody>
                        </table>
                    </section>
                </div>
        </div>
    </main>

    <script>
        let currentTerminal = '';
        let allUsers = [];
        
        // Load terminal cards and statistics on page load
        loadTerminalCards();
        loadUserRoleStats();
        
        // Load terminals dynamically from database
        async function loadTerminalCards() {
            try {
                const response = await fetch('../BACKEND/get_terminals.php');
                const data = await response.json();
                
                if (data.success) {
                    const container = document.getElementById('terminalCardsContainer');
                    
                    // Add terminal cards dynamically
                    data.terminals.forEach(terminal => {
                        const card = document.createElement('div');
                        card.className = 'category-card airport-card';
                        card.setAttribute('data-airport', terminal.terminal_code);
                        
                        card.innerHTML = `
    <div style="text-align: center; margin-bottom: 16px;">
        <i class="fas fa-building" style="font-size: 48px; color: var(--primary-blue);"></i>
    </div>
    <h4 class="category-title" style="text-align: center;">${terminal.terminal_name}</h4>
    <ul class="category-list">
        <li>0 Total Users</li>
        <li>0 Users</li>
        <li>0 Admins</li>
    </ul>
    <div style="text-align: center; margin-top: 16px; display: flex; gap: 8px; justify-content: center; flex-wrap: wrap;">
        <button class="action-btn view-btn" data-action="manage">
            <i class="fas fa-users"></i> Manage
        </button>
        <button class="action-btn edit-btn" data-action="edit">
            <i class="fas fa-edit"></i> Edit
        </button>
        <button class="action-btn delete-btn" data-action="delete">
            <i class="fas fa-trash"></i> Delete
        </button>
    </div>
`;

// Add click handlers for all buttons
const manageBtn = card.querySelector('[data-action="manage"]');
const editBtn = card.querySelector('[data-action="edit"]');
const deleteBtn = card.querySelector('[data-action="delete"]');

manageBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    currentTerminal = terminal.terminal_code;
    document.getElementById('selectedTerminal').textContent = terminal.terminal_name;
    document.getElementById('airportCardsView').style.display = 'none';
    document.getElementById('userTableView').style.display = 'block';
    loadUsers(terminal.terminal_code);
});

editBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    showEditTerminalModal(terminal);
});

deleteBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    deleteTerminal(terminal.id, terminal.terminal_name);
});
                        
                        // Add click handler for the button
                        card.querySelector('.action-btn').addEventListener('click', (e) => {
                            e.stopPropagation();
                            currentTerminal = terminal.terminal_code;
                            document.getElementById('selectedTerminal').textContent = terminal.terminal_name;
                            document.getElementById('airportCardsView').style.display = 'none';
                            document.getElementById('userTableView').style.display = 'block';
                            loadUsers(terminal.terminal_code);
                        });
                        
                        container.appendChild(card);
                    });
                    
                    // Load statistics after cards are created
                    loadTerminalStats();
                }
            } catch (error) {
                console.error('Error loading terminals:', error);
            }
        }
        
        // Load terminal statistics
        async function loadTerminalStats() {
            try {
                const response = await fetch('../BACKEND/get_terminal_stats.php');
                const data = await response.json();
                
                if (data.success) {
                    updateTerminalCards(data.stats);
                }
            } catch (error) {
                console.error('Error loading terminal stats:', error);
            }
        }

        // Load user role statistics
async function loadUserRoleStats() {
    try {
        const response = await fetch('../BACKEND/get_user_role_stats.php');
        const data = await response.json();
        
        if (data.success) {
            // Add animation class
            const statCards = document.querySelectorAll('.stats-grid .stat-card');
            statCards.forEach(card => card.classList.add('updating'));
            
            // Update values
            document.getElementById('itAdminCount').textContent = data.stats.it_admin;
            document.getElementById('executiveCount').textContent = data.stats.executive;
            document.getElementById('airportAdminCount').textContent = data.stats.airport_admin;
            document.getElementById('airportUserCount').textContent = data.stats.airport_user;
            
            // Remove animation class after a short delay
            setTimeout(() => {
                statCards.forEach(card => card.classList.remove('updating'));
            }, 300);
        }
    } catch (error) {
        console.error('Error loading user role stats:', error);
    }
}

        // Search functionality for Dashboard terminals
document.getElementById('dashboardTerminalSearch').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase().trim();
    const terminalCards = document.querySelectorAll('.airport-card');
    
    terminalCards.forEach(card => {
        const terminalTitle = card.querySelector('.category-title');
        if (terminalTitle) {
            const titleText = terminalTitle.textContent.toLowerCase();
            
            // Show card if search term matches terminal title, hide if not
            if (titleText.includes(searchTerm)) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        }
    });
    
    // Show message if no results found
    const visibleCards = document.querySelectorAll('.airport-card[style*="display: block"], .airport-card:not([style*="display: none"])');
    const container = document.getElementById('terminalCardsContainer');
    
    // Remove any existing "no results" message
    const existingMessage = document.getElementById('noTerminalsMessage');
    if (existingMessage) {
        existingMessage.remove();
    }
    
    // If no visible cards and search term exists, show "no results" message
    if (visibleCards.length === 0 && searchTerm !== '') {
        const noResultsMsg = document.createElement('div');
        noResultsMsg.id = 'noTerminalsMessage';
        noResultsMsg.style.cssText = 'grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-secondary);';
        noResultsMsg.innerHTML = '<i class="fas fa-search" style="font-size: 48px; margin-bottom: 16px; opacity: 0.5;"></i><p>No terminals found matching "' + searchTerm + '"</p>';
        container.appendChild(noResultsMsg);
    }
});
        
        // Update terminal cards with live data
function updateTerminalCards(stats) {
    // Update Executive and IT Admin card
    const execCard = document.querySelector('.airport-card[data-airport="executive_itadmin"]');
    if (execCard && stats['executive_itadmin']) {
        const stat = stats['executive_itadmin'];
        const list = execCard.querySelector('.category-list');
        list.innerHTML = `
            <li>${stat.total_users} Total Users</li>
            <li>${stat.executives} Executives</li>
            <li>${stat.it_admins} IT Admins</li>
        `;
    }
    
    // Update ALL terminal cards dynamically (not just hardcoded ones)
    for (const terminalCode in stats) {
        // Skip the executive_itadmin card as it's already handled above
        if (terminalCode === 'executive_itadmin') continue;
        
        const card = document.querySelector(`.airport-card[data-airport="${terminalCode}"]`);
        if (card && stats[terminalCode]) {
            const stat = stats[terminalCode];
            const list = card.querySelector('.category-list');
            list.innerHTML = `
                <li>${stat.total_users} Total Users</li>
                <li>${stat.users} Users</li>
                <li>${stat.admins} Admins</li>
            `;
        }
    }
}
        
        // Terminal card click handlers
        document.querySelectorAll('.airport-card').forEach(card => {
            card.querySelector('.action-btn').addEventListener('click', (e) => {
                e.stopPropagation();
                const terminal = card.getAttribute('data-airport');
                const terminalName = card.querySelector('.category-title').textContent;
                
                currentTerminal = terminal;
                document.getElementById('selectedTerminal').textContent = terminalName;
                document.getElementById('airportCardsView').style.display = 'none';
                document.getElementById('userTableView').style.display = 'block';
                loadUsers(terminal);
            });
        });
        
        // Back to terminals button
        document.getElementById('backToAirports').addEventListener('click', () => {
            document.getElementById('airportCardsView').style.display = 'block';
            document.getElementById('userTableView').style.display = 'none';
            currentTerminal = '';
        });
        
        // Load users for terminal
        async function loadUsers(terminal) {
            try {
                const response = await fetch(`../BACKEND/get_users.php?terminal=${terminal}`);
                const data = await response.json();
                
                if (data.success) {
                    allUsers = data.users;
                    renderUserTable(allUsers);
                } else {
                    showNotification(data.message, 'error');
                }
            } catch (error) {
                console.error('Error loading users:', error);
                showNotification('Failed to load users', 'error');
            }
        }
        
        // Render user table
        function renderUserTable(users) {
            const tbody = document.getElementById('usersTableBody');
            tbody.innerHTML = '';
            
            if (users.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 20px;">No users found</td></tr>';
                return;
            }
            
            users.forEach(user => {
                const row = document.createElement('tr');
                
                // Format date created
const dateCreated = user.created_at ? 
    new Date(user.created_at).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: '2-digit'
    }) : 'N/A';

row.innerHTML = `
    <td>
        <div style="font-weight: 500;">${user.username}</div>
        <div style="font-size: 12px; color: #888;">${user.username}</div>
    </td>
    <td><span class="role-badge role-${user.role}">${getRoleDisplayName(user.role)}</span></td>
    <td>${user.full_name || 'N/A'}</td>
    <td>${dateCreated}</td>
    <td class="action-buttons">
        <button class="action-btn view-btn" onclick="viewUser(${user.id})">
            <i class="fas fa-eye"></i> View
        </button>
        <button class="action-btn edit-btn" onclick="editUser(${user.id})">
            <i class="fas fa-edit"></i> Edit
        </button>
        <button class="action-btn delete-btn" onclick="deleteUser(${user.id})">
            <i class="fas fa-trash"></i> Delete
        </button>
    </td>
`;
                
                tbody.appendChild(row);
            });
        }
        
        // Get role display name
        function getRoleDisplayName(role) {
            const roleNames = {
                'user': 'User',
                'admin': 'Admin',
                'executive': 'Executive',
                'it_admin': 'IT Admin'
            };
            return roleNames[role] || role;
        }

        

        // Add Terminal Modal
function showAddTerminalModal() {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-container">
                    <div class="modal-header">
                        <h3>Add New Terminal</h3>
                        <button class="modal-close" onclick="closeModal(this)">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form id="addTerminalForm">
                            <div class="form-group">
                                <label>Terminal Name *</label>
                                <input type="text" name="terminal_name" required class="form-input" placeholder="NAIA Terminal 5">
                            </div>
                            <div class="form-group">
                                <label>Terminal Code *</label>
                                <input type="text" name="terminal_code" required class="form-input" placeholder="terminal5" pattern="[a-z0-9_]+" title="Use lowercase letters, numbers, and underscores only">
                                <small style="color: var(--text-secondary); font-size: 12px;">Use lowercase letters, numbers, and underscores (e.g., terminal5)</small>
                            </div>
                            <div class="form-group">
                                <label>Description</label>
                                <textarea name="description" class="form-input" rows="3" placeholder="Optional description"></textarea>
                            </div>
                            <div class="modal-actions">
                                <button type="button" class="action-btn delete-btn" onclick="closeModal(this)">Cancel</button>
                                <button type="submit" class="action-btn view-btn">Create Terminal</button>
                            </div>
                        </form>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Form submit handler
            modal.querySelector('#addTerminalForm').addEventListener('submit', async (e) => {
                e.preventDefault();
                
                const formData = new FormData(e.target);
                const terminalData = Object.fromEntries(formData.entries());
                
                try {
                    const response = await fetch('../BACKEND/create_terminal.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify(terminalData)
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        showNotification('Terminal created successfully! Please refresh the page to see the new terminal.', 'success');
                        closeModal(modal.querySelector('.modal-close'));
                        // Optionally reload the page after a delay
                        setTimeout(() => {
                            location.reload();
                        }, 2000);
                    } else {
                        showNotification(data.message, 'error');
                    }
                } catch (error) {
                    showNotification('Error creating terminal', 'error');
                    console.error('Error:', error);
                }
            });
        }
        
        // Show Add User Modal (unified for both header and category cards)
async function showAddUserModal(terminalCode = '') {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-container">
            <div class="modal-header">
                <h3>Add New User</h3>
                <button class="modal-close" onclick="closeModal(this)">&times;</button>
            </div>
            <div class="modal-body">
                <form id="addUserForm">
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="username" required class="form-input" placeholder="user@example.com">
                    </div>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" class="form-input" placeholder="Juan Dela Cruz">
                    </div>
                    <div class="form-group">
                        <label>Password *</label>
                        <input type="password" name="password" required class="form-input" minlength="6">
                    </div>
                    <div class="form-group">
                        <label>Role *</label>
                        <select name="role" required class="form-input">
                            <option value="">Select Role</option>
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                            <option value="executive">Executive</option>
                            <option value="it_admin">IT Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Terminal Assignment *</label>
                        <select name="terminal_assignment" required class="form-input" id="terminalAssignmentSelect">
                            <option value="">Loading terminals...</option>
                        </select>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="action-btn delete-btn" onclick="closeModal(this)">Cancel</button>
                        <button type="submit" class="action-btn view-btn">Create User</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Load terminals dynamically
    try {
        const response = await fetch('../BACKEND/get_terminals.php');
        const data = await response.json();
        
        const terminalSelect = modal.querySelector('#terminalAssignmentSelect');
        terminalSelect.innerHTML = '<option value="">Select Terminal</option>';
        
        // Add "Executive and IT Admin" option first
        const execOption = document.createElement('option');
        execOption.value = 'executive_itadmin';
        execOption.textContent = 'Executive and IT Admin';
        terminalSelect.appendChild(execOption);
        
        // Add all terminals from database
        if (data.success && data.terminals) {
            data.terminals.forEach(terminal => {
                const option = document.createElement('option');
                option.value = terminal.terminal_code;
                option.textContent = terminal.terminal_name;
                terminalSelect.appendChild(option);
            });
        }
        
        // Set terminal if provided (from category card)
        if (terminalCode) {
            terminalSelect.value = terminalCode;
        }
    } catch (error) {
        console.error('Error loading terminals:', error);
        showNotification('Failed to load terminals', 'error');
    }
    
    // Form submit handler
    modal.querySelector('#addUserForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const userData = Object.fromEntries(formData.entries());
        
        try {
            const response = await fetch('../BACKEND/create_user.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotification('User created successfully', 'success');
                closeModal(modal.querySelector('.modal-close'));
                
                // Refresh terminal stats AND role stats
                loadTerminalStats();
                loadUserRoleStats();
                
                // If we're in the user table view, reload users
                if (currentTerminal) {
                    loadUsers(currentTerminal);
                }
            } else {
                showNotification(data.message, 'error');
            }
        } catch (error) {
            console.error('Error creating user:', error);
            showNotification('Failed to create user', 'error');
        }
    });
}
        
        // View User
        function viewUser(userId) {
            const user = allUsers.find(u => u.id === userId);
            if (!user) return;
            
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>User Details</h3>
                        <button class="modal-close" onclick="closeModal(this)">&times;</button>
                    </div>
                    <div class="modal-body">
                        <div class="user-details">
                            <div class="detail-row">
                                <strong>Full Name:</strong>
                                <span>${user.full_name || 'N/A'}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Email:</strong>
                                <span>${user.username}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Role:</strong>
                                <span>${getRoleDisplayName(user.role)}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Terminal:</strong>
                                <span>${user.terminal_assignment.replace('terminal', 'NAIA Terminal ')}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Total Reports:</strong>
                                <span>${user.total_reports}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Last Activity:</strong>
                                <span>${user.last_activity ? new Date(user.last_activity).toLocaleString() : 'Never'}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Created:</strong>
                                <span>${new Date(user.created_at).toLocaleString()}</span>
                            </div>
                        </div>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="action-btn view-btn" onclick="closeModal(this)">Close</button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
        }
        
        // Edit User
        async function editUser(userId) {
    const user = allUsers.find(u => u.id === userId);
    if (!user) return;
    
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-container">
            <div class="modal-header">
                <h3>Edit User</h3>
                <button class="modal-close" onclick="closeModal(this)">&times;</button>
            </div>
            <div class="modal-body">
                <form id="editUserForm">
                    <input type="hidden" name="user_id" value="${user.id}">
                    <div class="form-group">
                        <label>Email *</label>
                        <input type="email" name="username" required class="form-input" value="${user.username}">
                    </div>
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" name="full_name" class="form-input" value="${user.full_name || ''}">
                    </div>
                    <div class="form-group">
                        <label>Password</label>
                        <input type="password" name="password" class="form-input" placeholder="Leave blank to keep current password">
                    </div>
                    <div class="form-group">
                        <label>Role *</label>
                        <select name="role" required class="form-input">
                            <option value="user" ${user.role === 'user' ? 'selected' : ''}>User</option>
                            <option value="admin" ${user.role === 'admin' ? 'selected' : ''}>Admin</option>
                            <option value="executive" ${user.role === 'executive' ? 'selected' : ''}>Executive</option>
                            <option value="it_admin" ${user.role === 'it_admin' ? 'selected' : ''}>IT Admin</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Terminal Assignment *</label>
                        <select name="terminal_assignment" required class="form-input" id="editTerminalAssignmentSelect">
                            <option value="">Loading terminals...</option>
                        </select>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="action-btn delete-btn" onclick="closeModal(this)">Cancel</button>
                        <button type="submit" class="action-btn edit-btn">Update User</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Load terminals dynamically
    try {
        const response = await fetch('../BACKEND/get_terminals.php');
        const data = await response.json();
        
        const terminalSelect = modal.querySelector('#editTerminalAssignmentSelect');
        terminalSelect.innerHTML = '';
        
        // Add "Executive and IT Admin" option first
        const execOption = document.createElement('option');
        execOption.value = 'executive_itadmin';
        execOption.textContent = 'Executive and IT Admin';
        if (user.terminal_assignment === 'executive_itadmin') {
            execOption.selected = true;
        }
        terminalSelect.appendChild(execOption);
        
        // Add all terminals from database
        if (data.success && data.terminals) {
            data.terminals.forEach(terminal => {
                const option = document.createElement('option');
                option.value = terminal.terminal_code;
                option.textContent = terminal.terminal_name;
                if (user.terminal_assignment === terminal.terminal_code) {
                    option.selected = true;
                }
                terminalSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error loading terminals:', error);
        showNotification('Failed to load terminals', 'error');
    }
    
    // Form submit handler
    modal.querySelector('#editUserForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const userData = Object.fromEntries(formData.entries());
        
        // Remove password if empty
        if (!userData.password) {
            delete userData.password;
        }
        
        try {
            const response = await fetch('../BACKEND/update_user.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(userData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotification('User updated successfully', 'success');
                closeModal(modal.querySelector('.modal-close'));
                loadUsers(currentTerminal);
                loadTerminalStats();
            } else {
                showNotification(data.message, 'error');
            }
        } catch (error) {
            console.error('Error updating user:', error);
            showNotification('Failed to update user', 'error');
        }
    });
}
        
        // Delete User
        function deleteUser(userId) {
            const user = allUsers.find(u => u.id === userId);
            if (!user) return;
            
            const modal = document.createElement('div');
            modal.className = 'modal-overlay';
            modal.innerHTML = `
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Delete User</h3>
                        <button class="modal-close" onclick="closeModal(this)">&times;</button>
                    </div>
                    <div class="modal-body">
                        <p>Are you sure you want to delete this user?</p>
                        <div class="user-details" style="margin-top: 15px;">
                            <div class="detail-row">
                                <strong>Name:</strong>
                                <span>${user.full_name || user.username}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Email:</strong>
                                <span>${user.username}</span>
                            </div>
                            <div class="detail-row">
                                <strong>Role:</strong>
                                <span>${getRoleDisplayName(user.role)}</span>
                            </div>
                        </div>
                        <p style="margin-top: 15px; color: #dc3545;">This action cannot be undone.</p>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="action-btn view-btn" onclick="closeModal(this)">Cancel</button>
                        <button type="button" class="action-btn delete-btn" onclick="confirmDelete(${user.id}, this)">Delete</button>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
        }
        
        // Confirm Delete
        async function confirmDelete(userId, button) {
            try {
                const response = await fetch('../BACKEND/delete_user.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: userId })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showNotification('User deleted successfully', 'success');
                    closeModal(button);
                    loadUsers(currentTerminal);
                    loadTerminalStats();
                } else {
                    showNotification(data.message, 'error');
                }
            } catch (error) {
                console.error('Error deleting user:', error);
                showNotification('Failed to delete user', 'error');
            }
        }
        
        // Close modal helper
        function closeModal(element) {
            const modal = element.closest('.modal-overlay');
            if (modal) {
                modal.remove();
            }
        }
        
        // Notification system
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.textContent = message;
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#28a745' : type === 'error' ? '#dc3545' : '#17a2b8'};
                color: white;
                padding: 15px 20px;
                border-radius: 5px;
                z-index: 10000;
                box-shadow: 0 2px 5px rgba(0,0,0,0.2);
                animation: slideIn 0.3s ease;
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.animation = 'slideOut 0.3s ease';
                setTimeout(() => notification.remove(), 300);
            }, 3000);
        }
        
        // Search and filter functionality
        const searchInput = document.querySelector('.activity-controls .search-input');
        const roleFilter = document.querySelectorAll('.activity-controls .filter-select')[0];
        
        searchInput.addEventListener('input', filterUsers);
        roleFilter.addEventListener('change', filterUsers);
        
        function filterUsers() {
            const searchTerm = searchInput.value.toLowerCase();
            const selectedRole = roleFilter.value;
            
            const filtered = allUsers.filter(user => {
                const matchesSearch = !searchTerm || 
                    user.full_name?.toLowerCase().includes(searchTerm) ||
                    user.username.toLowerCase().includes(searchTerm);
                
                const matchesRole = !selectedRole || user.role === selectedRole;
                
                return matchesSearch && matchesRole;
            });
            
            renderUserTable(filtered);
        }

        // Load reports for IT Admin "All Reports" section
async function loadAllReportsForITAdmin() {
    try {
        // Fetch both daily and interception reports
        const [dailyResponse, interceptionResponse] = await Promise.all([
            fetch('../BACKEND/get_all_daily_reports.php'),
            fetch('../BACKEND/get_all_interception_reports.php')
        ]);
        
        const dailyData = await dailyResponse.json();
        const interceptionData = await interceptionResponse.json();
        
        const allReports = [];
        
        // Add daily reports with type
        if (dailyData.success) {
            dailyData.reports.forEach(report => {
                allReports.push({...report, type: 'daily'});
            });
        }
        
        // Add interception reports with type
        if (interceptionData.success) {
            interceptionData.reports.forEach(report => {
                allReports.push({...report, type: 'interception'});
            });
        }
        
        // Sort by created_at descending
        allReports.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        
        // Store all reports globally for filtering
        allReportsData = allReports;
        
        // Initialize filters
        initializeAllReportsFilters();
        
        // Display all reports initially
        displayAllReportsForITAdmin(allReports);
    } catch (error) {
        console.error('Error loading all reports:', error);
    }
}

        // Store all reports globally for filtering
        let allReportsData = [];

        // Initialize filters for All Reports section
        function initializeAllReportsFilters() {
            const searchInput = document.getElementById('superAdminSearch');
            const dateFilter = document.getElementById('superAdminDateFilter');
            const terminalFilter = document.getElementById('superAdminTerminalFilter');
            const typeFilter = document.getElementById('superAdminTypeFilter');
            
            // Set current date to date filter
            if (dateFilter) {
                const today = new Date().toISOString().split('T')[0];
                dateFilter.value = today;
            }
            
            // Load terminals dynamically
            loadTerminalsToFilter();
            
            // Add event listeners for filtering
            if (searchInput) searchInput.addEventListener('input', filterAllReports);
            if (dateFilter) dateFilter.addEventListener('change', filterAllReports);
            if (terminalFilter) terminalFilter.addEventListener('change', filterAllReports);
            if (typeFilter) typeFilter.addEventListener('change', filterAllReports);
        }

        // Load terminals dynamically to the terminal filter
        async function loadTerminalsToFilter() {
            try {
                const response = await fetch('../BACKEND/get_terminals.php');
                const data = await response.json();
                
                const terminalFilter = document.getElementById('superAdminTerminalFilter');
                if (!terminalFilter) return;
                
                // Clear existing options except the first one
                terminalFilter.innerHTML = '<option value="">All Terminals</option>';
                
                if (data.success && data.terminals) {
                    data.terminals.forEach(terminal => {
                        const option = document.createElement('option');
                        option.value = terminal.terminal_code;
                        option.textContent = terminal.terminal_name;
                        terminalFilter.appendChild(option);
                    });
                }
            } catch (error) {
                console.error('Error loading terminals:', error);
            }
        }

        // Filter all reports based on search and filter criteria
        function filterAllReports() {
            const searchTerm = document.getElementById('superAdminSearch')?.value.toLowerCase() || '';
            const selectedDate = document.getElementById('superAdminDateFilter')?.value || '';
            const selectedTerminal = document.getElementById('superAdminTerminalFilter')?.value || '';
            const selectedType = document.getElementById('superAdminTypeFilter')?.value || '';
            
            const filtered = allReportsData.filter(report => {
                // Search by passenger name or username
                const passengerName = (report.passenger_name || '').toLowerCase();
                const username = (report.username || '').toLowerCase();
                const matchesSearch = !searchTerm || 
                    passengerName.includes(searchTerm) || 
                    username.includes(searchTerm);
                
                // Filter by date
                const reportDate = report.report_date || report.created_at?.split(' ')[0] || '';
                const matchesDate = !selectedDate || reportDate === selectedDate;
                
                // Filter by terminal
                const matchesTerminal = !selectedTerminal || report.terminal_assignment === selectedTerminal;
                
                // Filter by type
                const matchesType = !selectedType || report.type === selectedType;
                
                return matchesSearch && matchesDate && matchesTerminal && matchesType;
            });
            
            displayAllReportsForITAdmin(filtered);
        }

        function displayAllReportsForITAdmin(reports) {
            const tbody = document.getElementById('superAdminReportsTableBody');
            if (!tbody) return;
            
            tbody.innerHTML = '';
            
            if (reports.length === 0) {
                tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; padding: 30px; color: var(--text-secondary);">No reports found</td></tr>';
                document.getElementById('superAdminReportsShowing').textContent = 'Showing 0 reports';
                return;
            }
            
            reports.forEach(report => {
                const createdAt = new Date(report.created_at);
                const dateTimeStr = createdAt.toLocaleDateString('en-US', { 
                    year: 'numeric', 
                    month: 'short', 
                    day: 'numeric' 
                }) + ' at ' + createdAt.toLocaleTimeString('en-US', { 
                    hour: '2-digit', 
                    minute: '2-digit' 
                });
                
                const passengerName = report.type === 'interception' ? (report.passenger_name || 'N/A') : 'N/A';
                const reportTypeName = report.type === 'daily' ? 'Daily Report' : 'Interception Report';
                
                // Get terminal name
                const terminalMap = {
                    'terminal1': 'NAIA Terminal 1',
                    'terminal2': 'NAIA Terminal 2',
                    'terminal3': 'NAIA Terminal 3',
                    'terminal4': 'NAIA Terminal 4'
                };
                const terminalName = terminalMap[report.terminal_assignment] || report.terminal_assignment || 'Unknown';
                
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="report-type">${reportTypeName}</td>
                    <td class="report-submitter">${passengerName}</td>
                    <td class="report-submitter">${report.username}</td>
                    <td class="report-time">${dateTimeStr}</td>
                    <td>${terminalName}</td>
                    <td>
                        <div class="report-actions">
                            <button class="action-btn view-btn" onclick="viewITAdminReport(${report.id}, '${report.type}')">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn" style="background: var(--notif-green); color: white;" onclick="downloadReportPDF(${report.id}, '${report.type}')">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
            
            document.getElementById('superAdminReportsShowing').textContent = `Showing ${reports.length} reports`;
        }

        // View report function for IT Admin
        function viewITAdminReport(reportId, reportType) {
            fetch(`../BACKEND/get_report_details.php?report_id=${reportId}&report_type=${reportType}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showReportModal(data.report, reportType);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network error: ' + error.message);
                });
        }

        function showReportModal(report, reportType) {
            // Create modal implementation here
            alert('Report details would be shown here');
        }

        function downloadReportPDF(reportId, reportType) {
            window.open(`../BACKEND/generate_report_pdf.php?report_id=${reportId}&report_type=${reportType}`, '_blank');
        }
        
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const page = item.getAttribute('data-page');

                if (page === 'allReports') {
                    loadAllReportsForITAdmin();
                }
                
                if (page === 'actionLogs') {
                    loadITAdminLogs();
                }
                
                // Handle logout
                if (page === 'logout') {
                    if (confirm('Are you sure you want to logout?')) {
                        window.location.href = '../BACKEND/logout.php';
                    }
                    return;
                }
                
                // Update active nav item
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');
                
                // Show corresponding content
                document.querySelectorAll('.page-content').forEach(content => {
                    content.classList.remove('active');
                    content.style.display = 'none';
                });
                
                const targetContent = document.getElementById(page + 'Content');
                if (targetContent) {
                    targetContent.classList.add('active');
                    targetContent.style.display = 'block';
                }
            });
        });
            
        // Sidebar toggle
        document.getElementById('sidebarClose')?.addEventListener('click', () => {
            document.getElementById('sidebar').classList.remove('active');
            document.getElementById('sidebarOverlay').classList.remove('active');
        });
        
        document.getElementById('sidebarOverlay')?.addEventListener('click', () => {
            document.getElementById('sidebar').classList.remove('active');
            document.getElementById('sidebarOverlay').classList.remove('active');
        });

        // Edit Terminal Modal
function showEditTerminalModal(terminal) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>Edit Terminal</h3>
                <button class="modal-close" onclick="closeModal(this)">&times;</button>
            </div>
            <div class="modal-body">
                <form id="editTerminalForm">
                    <input type="hidden" name="terminal_id" value="${terminal.id}">
                    <div class="form-group">
                        <label>Terminal Name *</label>
                        <input type="text" name="terminal_name" required class="form-input" 
                               placeholder="e.g., NAIA Terminal 1" value="${terminal.terminal_name}">
                    </div>
                    <div class="form-group">
                        <label>Terminal Code *</label>
                        <input type="text" name="terminal_code" required class="form-input" 
                               placeholder="e.g., terminal1" value="${terminal.terminal_code}"
                               pattern="[a-z0-9_]+" title="Use lowercase letters, numbers, and underscores only">
                        <small style="color: #666; font-size: 12px;">Lowercase letters, numbers, and underscores only</small>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="description" class="form-input" rows="3" 
                                  placeholder="Optional description">${terminal.description || ''}</textarea>
                    </div>
                    <div class="modal-actions">
                        <button type="button" class="action-btn delete-btn" onclick="closeModal(this)">Cancel</button>
                        <button type="submit" class="action-btn edit-btn">Update Terminal</button>
                    </div>
                </form>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Form submit handler
    modal.querySelector('#editTerminalForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const terminalData = Object.fromEntries(formData.entries());
        
        try {
            const response = await fetch('../BACKEND/update_terminal.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(terminalData)
            });
            
            const data = await response.json();
            
            if (data.success) {
                showNotification('Terminal updated successfully! Refreshing...', 'success');
                closeModal(modal.querySelector('.modal-close'));
                // Reload terminal cards to show updated data
                setTimeout(() => {
                    location.reload();
                }, 1000);
            } else {
                showNotification(data.message, 'error');
            }
        } catch (error) {
            console.error('Error updating terminal:', error);
            showNotification('Failed to update terminal', 'error');
        }
    });
}

// Delete Terminal
function deleteTerminal(terminalId, terminalName) {
    const modal = document.createElement('div');
    modal.className = 'modal-overlay';
    modal.innerHTML = `
        <div class="modal-content" style="max-width: 500px;">
            <div class="modal-header">
                <h3>Delete Terminal</h3>
                <button class="modal-close" onclick="closeModal(this)">&times;</button>
            </div>
            <div class="modal-body">
                <p style="margin: 20px 0; font-size: 16px;">
                    Are you sure you want to delete <strong>${terminalName}</strong>?
                </p>
                <p style="color: #dc3545; margin: 10px 0;">
                    <i class="fas fa-exclamation-triangle"></i> 
                    This action cannot be undone. Make sure no users are assigned to this terminal.
                </p>
                <div class="modal-actions" style="margin-top: 24px;">
                    <button type="button" class="action-btn view-btn" onclick="closeModal(this)">Cancel</button>
                    <button type="button" class="action-btn delete-btn" onclick="confirmDeleteTerminal(${terminalId}, this)">
                        <i class="fas fa-trash"></i> Delete Terminal
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
}

// Confirm Delete Terminal
async function confirmDeleteTerminal(terminalId, button) {
    try {
        const response = await fetch('../BACKEND/delete_terminal.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ terminal_id: terminalId })
        });
        
        const data = await response.json();
        
        if (data.success) {
            showNotification('Terminal deleted successfully! Refreshing...', 'success');
            closeModal(button);
            // Reload the page to refresh terminal cards
            setTimeout(() => {
                location.reload();
            }, 1000);
        } else {
            showNotification(data.message, 'error');
        }
    } catch (error) {
        console.error('Error deleting terminal:', error);
        showNotification('Failed to delete terminal', 'error');
    }
}


// Load IT Admin logs
        function loadITAdminLogs() {
            fetch('../BACKEND/get_it_admin_logs.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        displayITAdminLogs(data.logs);
                    } else {
                        console.error('Error loading IT admin logs:', data.message);
                    }
                })
                .catch(error => {
                    console.error('Network error:', error);
                });
        }

        function displayITAdminLogs(logs) {
            const tbody = document.getElementById('itAdminActionLogsTableBody');
            tbody.innerHTML = '';
            
            if (logs.length === 0) {
                tbody.innerHTML = '<tr><td colspan="3" style="text-align: center; padding: 40px; color: var(--text-secondary);">No action logs found</td></tr>';
                return;
            }
            
            logs.forEach(log => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td class="report-type">${log.activity}</td>
                    <td class="admin-description">${log.description}</td>
                    <td class="report-time">${formatDateTime(log.created_at)}</td>
                `;
                tbody.appendChild(row);
            });
            
            // Update showing text
            const showingElement = document.getElementById('itAdminActionLogsShowing');
            if (showingElement) {
                showingElement.textContent = `Showing ${logs.length} action log${logs.length !== 1 ? 's' : ''}`;
            }
        }

        function formatDateTime(dateTimeStr) {
            const date = new Date(dateTimeStr);
            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');
            const hours = String(date.getHours()).padStart(2, '0');
            const minutes = String(date.getMinutes()).padStart(2, '0');
            const seconds = String(date.getSeconds()).padStart(2, '0');
            return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
        }


    </script>
</body>
</html>