<?php
// Require authentication with 'admin' role
require_once 'auth_check.php';
requireAuth('admin');
checkSessionTimeout();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SRS - NAIA Terminal 1 Dashboard</title>
    <link rel="icon" type="images/png" href="../Logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!-- Sidebar Overlay -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <div class="logo">
                <img src="../Logo.png" alt="Logo">
            </div>
            <div class="sidebar-title">SRS - NAIA<br>TERMINAL 1</div>
            <button class="sidebar-close" id="sidebarClose">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <nav class="nav-section">
            <a href="#" class="nav-item active" data-page="overview">
                <div class="nav-icon">
                    <i class="fa-solid fa-address-book"></i>
                </div>
                <span>Overview</span>
            </a>
            <a href="#" class="nav-item" data-page="reportsManagement">
                <div class="nav-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <span>Reports Management</span>
            </a>
            <a href="#" class="nav-item" data-page="adminLogs">
                <div class="nav-icon">
                    <i class="fa-solid fa-clipboard"></i>
                </div>
                <span>Admin Logs</span>
            </a>

            <div class="nav-divider"></div>
            
            <a href="#" class="nav-item" data-page="help">
                <div class="nav-icon">
                    <i class="fas fa-headset"></i>
                </div>
                <span>Help Center</span>
            </a>
            <a href="#" class="nav-item" data-page="notifications">
                <div class="nav-icon">
                    <i class="fas fa-bell"></i>
                </div>
                <span>Notifications</span>
            </a>
            <a href="../BACKEND/logout.php" class="nav-item" data-page="logout">
                <div class="nav-icon">
                    <i class="fas fa-sign-out-alt"></i>
                </div>
                <span>Logout</span>
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="mobile-menu-toggle" id="mobileMenuToggle">
                    <div class="hamburger"></div>
                </button>
                <?php
                $displayName = isset($_SESSION['full_name']) ? $_SESSION['full_name'] : $_SESSION['username'];
                $firstName = explode(' ', $displayName)[0];
                ?>
                <h1 class="welcome-text">Welcome, <?php echo htmlspecialchars($displayName); ?></h1>
                <h1 class="mobile-welcome">Welcome, <?php echo htmlspecialchars($firstName); ?></h1>
            </div>
            <div class="header-actions">
                <button class="settings-btn" title="Settings">
                    <i class="fas fa-cog"></i>
                </button>
                <?php
                $nameParts = explode(' ', $displayName);
                $initials = '';
                foreach ($nameParts as $part) {
                    if (!empty($part)) {
                        $initials .= strtoupper(substr($part, 0, 1));
                    }
                }
                $initials = substr($initials, 0, 2);
                ?>
                <div class="user-avatar" title="Profile"><?php echo htmlspecialchars($initials); ?></div>
            </div>
        </header>

        <!-- Content Area -->
        <div class="content">
            <!-- Dashboard Content -->
            <div id="overviewContent" class="page-content active">

                <!-- Personnel Data Section -->
                <section class="report-section">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fas fa-user-tie" style="color: var(--primary-blue); font-size: 18px;"></i>
                        </div>
                        <div>
                            <div class="section-title">Personnel Overview</div>
                            <div class="section-subtitle">Current personnel assignment for NAIA Terminal 1</div>
                        </div>
                        <button class="edit-btn" id="editPersonnelBtn">
                            <i class="fas fa-edit"></i> Edit
                        </button>
                        <button class="edit-btn save-btn" id="savePersonnelBtn" style="display: none;">
                            <i class="fas fa-save"></i> Save
                        </button>
                        <button class="edit-btn cancel-btn" id="cancelPersonnelBtn" style="display: none;">
                            <i class="fas fa-times"></i> Cancel
                        </button>
                    </div>
                    
                    <div class="form-grid-2" id="personnelForm">
                        <div class="form-group">
                            <label>Terminal Chief</label>
                            <input type="text" class="form-input" id="terminalChief" readonly>
                        </div>
                        <div class="form-group">
                            <label>Total Personnel</label>
                            <input type="number" class="form-input" id="totalPersonnel" readonly min="0">
                        </div>
                        <div class="form-group">
                            <label>Total Number of SSO</label>
                            <input type="number" class="form-input" id="totalSSO" readonly min="0">
                        </div>
                        <div class="form-group">
                            <label>Airport Clerk</label>
                            <input type="number" class="form-input" id="admins" readonly min="0">
                        </div>
                        <div class="form-group">
                            <label>Shift-in-Charges</label>
                            <input type="number" class="form-input" id="shiftInCharges" readonly min="0">
                        </div>
                        <div class="form-group">
                            <label>Checkpoint Supervisors</label>
                            <input type="number" class="form-input" id="checkpointSupervisors" readonly min="0">
                        </div>
                        <div class="form-group">
                            <label>Male SSO</label>
                            <input type="number" class="form-input" id="ssoMale" readonly min="0">
                        </div>
                        <div class="form-group">
                            <label>Female SSO</label>
                            <input type="number" class="form-input" id="ssoFemale" readonly min="0">
                        </div>
                    </div>
                    
                    <div class="form-actions" style="margin-top: 16px;">
                        <div class="info-note" id="editInfo" style="display: none;">
                            <i class="fas fa-info-circle"></i>
                            <span>Changes will be automatically reflected in the user dashboard and overview statistics.</span>
                        </div>
                        <div class="success-note" id="saveSuccess" style="display: none; background: rgba(40, 167, 69, 0.1); border-left-color: var(--notif-green);">
                            <i class="fas fa-check-circle" style="color: var(--notif-green);"></i>
                            <span>Personnel data updated successfully!</span>
                        </div>
                    </div>
                </section>

                <!-- Daily Operational Breakdown Section -->
                <section class="report-section">
                    <div class="section-header">
                        <div class="section-icon">
                            <i class="fa-solid fa-chart-simple" style="color: var(--primary-blue); font-size: 18px;"></i>
                        </div>
                        <div>
                            <div class="section-title">Daily Operational Breakdown</div>
                        </div>
                        <input type="date" id="dailyBreakdownDate" class="date-input" value="<?php echo date('Y-m-d'); ?>">
                    </div>
                    
                    <div class="summary-cards" id="dailyBreakdownContent">
    <div class="form-grid-2">
        <div class="summary-card" data-category="personnel" data-status="operational">
            <div class="summary-label">Personnel Status</div>
            <div class="form-grid-2">
                <div class="form-group">
                    <label>On Duty</label>
                    <input type="number" class="form-input" id="breakdownOnDuty" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>Off Duty</label>
                    <input type="number" class="form-input" id="breakdownOff" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>On Leave</label>
                    <input type="number" class="form-input" id="breakdownOnLeave" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>Absent</label>
                    <input type="number" class="form-input" id="breakdownAbsent" value="0" min="0" readonly>
                </div>
            </div>
        </div>

        <div class="summary-card" data-category="interception" data-status="operational">
            <div class="summary-label">Interception Reports</div>
            <div class="form-grid-2">
                <div class="form-group">
                    <label>Suspected Ammo</label>
                    <input type="number" class="form-input" id="breakdownSuspectedAmmo" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>Suspected Empty Shell</label>
                    <input type="number" class="form-input" id="breakdownSuspectedShell" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>Suspected Firearms</label>
                    <input type="number" class="form-input" id="breakdownSuspectedFirearms" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>Suspected Firearms Parts & Components</label>
                    <input type="number" class="form-input" id="breakdownSuspectedParts" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>Object with Sharp Points & Edges</label>
                    <input type="number" class="form-input" id="breakdownSharpObjects" value="0" min="0" readonly>
                </div>
                <div class="form-group">
                    <label>Other Prohibited Items</label>
                    <input type="number" class="form-input" id="breakdownOtherProhibited" value="0" min="0" readonly>
                </div>
            </div>
        </div>

        <div class="summary-card" data-category="international" data-status="operational">
                                <div class="summary-label">Flight Operations - International Flights</div>
                                <div class="form-grid-2">
                                    <div class="form-group">
                                        <label>Departing Flights</label>
                                        <input type="number" class="form-input" id="breakdownIntFlights" value="0" min="0" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Departing Passengers</label>
                                        <input type="number" class="form-input" id="breakdownIntPassengers" value="0" min="0" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Cancelled Flights</label>
                                        <input type="number" class="form-input" id="breakdownIntCancelled" value="0" min="0" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Affected Passengers</label>
                                        <input type="number" class="form-input" id="breakdownIntAffected" value="0" min="0" readonly>
                                    </div>
                                </div>
                            </div>

                            <div class="summary-card" data-category="domestic" data-status="operational">
                                <div class="summary-label">Flight Operations - Domestic Flights</div>
                                <div class="form-grid-2">
                                    <div class="form-group">
                                        <label>Departing Flights</label>
                                        <input type="number" class="form-input" id="breakdownDomFlights" value="0" min="0" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Departing Passengers</label>
                                        <input type="number" class="form-input" id="breakdownDomPassengers" value="0" min="0" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Cancelled Flights</label>
                                        <input type="number" class="form-input" id="breakdownDomCancelled" value="0" min="0" readonly>
                                    </div>
                                    <div class="form-group">
                                        <label>Affected Passengers</label>
                                        <input type="number" class="form-input" id="breakdownDomAffected" value="0" min="0" readonly>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>

            <!-- Reports Management Content -->
            <div id="reportsMangementContent" class="page-content">
                <section class="reports-header-section">
                    <div class="reports-title-bar">
                        <div class="reports-icon">
                            <i class="fas fa-file-alt"></i>
                        </div>
                        <div>
                            <h2 class="reports-title">Reports Management</h2>
                        </div>
                    </div>
                    <div class="activity-controls" id="reportsControls">
                        <input type="date" id="reportDate" class="date-input">
                        <input type="text" id="reportsSearch" class="search-input" placeholder="Search reports...">
                        <select id="reportsTypeFilter" class="filter-select">
                            <option value="">All Types</option>
                            <option value="daily">Daily Report</option>
                            <option value="interception">Interception Report</option>
                        </select>
                    </div>
                    
                    <div class="reports-showing" id="reportsShowing">
                        Loading reports...
                    </div>
                </section>

                <section class="reports-table-container">
                    <table class="reports-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Passenger Name</th>
                                <th>Submitted By</th>
                                <th>Date & Time</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="reportsTableBody">
                        </tbody>
                    </table>
                </section>
            </div>

            <!-- Admin Logs Content -->
            <div id="adminLogsContent" class="page-content">
                <section class="reports-header-section">
                    <div class="reports-title-bar">
                        <div class="reports-icon" style="background: var(--accent-red);">
                            <i class="fa-regular fa-clipboard"></i>
                        </div>
                        <div>
                            <h2 class="reports-title">Admin Logs</h2>
                        </div>
                    </div>
                    
                    <div class="reports-showing" id="adminLogsShowing">
                        Admin logs are automatically recorded for all system activities and administrative actions.
                    </div>
                </section>

                <section class="reports-table-container">
                    <table class="reports-table">
                        <thead>
                            <tr>
                                <th>Type</th>
                                <th>Activity</th>
                                <th>Description</th>
                                <th>Date & Time</th>
                            </tr>
                        </thead>
                        <tbody id="adminLogsTableBody">
                            <!-- Admin logs will be loaded here dynamically -->
                        </tbody>
                    </table>
                </section>

                <div class="activity-footer">
                    <div class="activity-footer-text">Admin logs are automatically recorded for all system activities and administrative actions.</div>
                </div>
            </div>
        </div>
    </main>

    <script>
       // PersonnelDataManager Class
        class PersonnelDataManager {
            constructor() {
                this.defaultData = {
                    terminalChief: 'Captain Chris',
                    totalPersonnel: 100,
                    totalSSO: 42,
                    admins: 2,
                    shiftInCharges: 4,
                    checkpointSupervisors: 6,
                    ssoMale: 24,
                    ssoFemale: 6
                };
                this.currentData = null;
                this.isInitialized = false;
                this.initPromise = null;
                // Clear any old localStorage data completely
                localStorage.removeItem('srs_personnel_data');
            }

            async ensureInitialized() {
                if (!this.initPromise) {
                    this.initPromise = this.loadData();
                }
                await this.initPromise;
                this.isInitialized = true;
                return this.currentData;
            }

    async loadData() {
        try {
            const response = await fetch('../BACKEND/get_personnel_overview.php');
            const result = await response.json();
            
            if (result.success) {
                this.currentData = result.data;
                return result.data;
            } else {
                console.error('Failed to load personnel data:', result.message);
                this.currentData = this.defaultData;
                return this.defaultData;
            }
        } catch (error) {
            console.error('Error loading personnel data:', error);
            this.currentData = this.defaultData;
            return this.defaultData;
        }
    }

    getData() {
        return this.currentData || this.defaultData;
    }

    async saveData(data) {
        try {
            const response = await fetch('../BACKEND/save_personnel_overview.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(data)
            });
            
            const result = await response.json();
            
            if (result.success) {
                this.currentData = data;
                return true;
            } else {
                console.error('Failed to save personnel data:', result.message);
                return false;
            }
        } catch (error) {
            console.error('Error saving personnel data:', error);
            return false;
        }
    }

    async updateFields(updates) {
        const currentData = this.getData();
        const updatedData = Object.assign({}, currentData, updates);
        return await this.saveData(updatedData);
    }

    // Force refresh from database
    async refreshFromDatabase() {
        return await this.loadData();
    }



            broadcastUpdate(data) {
                window.dispatchEvent(new CustomEvent('personnelDataUpdated', { 
                    detail: data 
                }));
                
                window.dispatchEvent(new StorageEvent('storage', {
                    key: this.storageKey,
                    newValue: JSON.stringify(data),
                    storageArea: localStorage
                }));
            }

            onDataChange(callback) {
                window.addEventListener('personnelDataUpdated', (event) => {
                    callback(event.detail);
                });

                window.addEventListener('storage', (event) => {
                    if (event.key === this.storageKey && event.newValue) {
                        try {
                            const data = JSON.parse(event.newValue);
                            callback(data);
                        } catch (error) {
                            console.error('Error parsing storage event data:', error);
                        }
                    }
                });
            }
        }

        const personnelManager = new PersonnelDataManager();

        // Load all reports for admin
        function loadAllReportsForAdmin() {
            Promise.all([
                fetch('../BACKEND/get_all_daily_reports.php').then(r => r.json()),
                fetch('../BACKEND/get_all_interception_reports.php').then(r => r.json())
            ])
            .then(([dailyData, interceptionData]) => {
                const allReports = [];
                
                if (dailyData.success) {
                    dailyData.reports.forEach(report => {
                        report.type = 'daily';
                        allReports.push(report);
                    });
                }
                
                if (interceptionData.success) {
                    interceptionData.reports.forEach(report => {
                        report.type = 'interception';
                        allReports.push(report);
                    });
                }
                
                allReports.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                
                displayAllReportsAdmin(allReports);
            })
            .catch(error => console.error('Error loading reports:', error));
        }

        function displayAllReportsAdmin(reports) {
            const tbody = document.getElementById('reportsTableBody');
            if (!tbody) return;
            
            tbody.innerHTML = '';
            
            if (reports.length === 0) {
                tbody.innerHTML = '<tr><td colspan="5" style="text-align: center; padding: 30px; color: var(--text-secondary);">No reports found</td></tr>';
                document.getElementById('reportsShowing').textContent = 'Showing 0 reports';
                return;
            }
            
            reports.forEach(report => {
            const reportDate = new Date(report.report_date).toLocaleDateString();
            const createdAt = new Date(report.created_at);
            const dateTimeStr = createdAt.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            }) + ' at ' + createdAt.toLocaleTimeString('en-US', { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
            
            const passengerName = report.type === 'interception' ? (report.passenger_name || 'N/A') : '';
            
            const row = document.createElement('tr');
            row.setAttribute('data-type', report.type);
            row.setAttribute('data-user', report.username);
            row.setAttribute('data-date', report.report_date);
            row.setAttribute('data-passenger', passengerName);
            row.setAttribute('data-datetime', dateTimeStr);
            
            let reportTypeName = report.type === 'daily' ? 'Daily Report' : 'Interception Report';
                
                let statusBadge = '';
                if (report.status === 'submitted') {
                    statusBadge = '<span class="report-status status-submitted">Submitted</span>';
                } else if (report.status === 'approved') {
                    statusBadge = '<span class="report-status" style="background: rgba(40, 167, 69, 0.1); color: var(--notif-green);">Approved</span>';
                } else if (report.status === 'under-review') {
                    statusBadge = '<span class="report-status status-under-review">Under Review</span>';
                }
                
                row.innerHTML = `
                    <td class="report-type">${reportTypeName}</td>
                    <td class="report-submitter">${passengerName}</td>
                    <td class="report-submitter">${report.username}</td>
                    <td class="report-time">${dateTimeStr}</td>
                    <td>
                        <div class="report-actions">
                            <button class="action-btn view-btn" onclick="viewAdminReport(${report.id}, '${report.type}')">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="action-btn" style="background: var(--notif-green); color: white;" onclick="downloadReportPDF(${report.id}, '${report.type}')">
                                <i class="fas fa-download"></i>
                            </button>
                            <button class="action-btn edit-btn" onclick="editAdminReport(${report.id}, '${report.type}')">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="action-btn delete-btn" onclick="deleteAdminReport(${report.id}, '${report.type}')">
                                <i class="fas fa-trash"></i>
                            </button>
                        </div>
                    </td>
                `;
                
                tbody.appendChild(row);
            });
            
            const showingElement = document.getElementById('reportsShowing');
            if (showingElement) {
                const dateInput = document.getElementById('reportDate');
                const dateText = dateInput ? formatDateToWords(dateInput.value) : 'All Dates';
                showingElement.textContent = `Showing ${reports.length} reports for ${dateText}`;
            }
        }

        // Download report as PDF
        function downloadReportPDF(reportId, reportType) {
            window.open(
                `../BACKEND/generate_report_pdf.php?report_id=${reportId}&report_type=${reportType}`,
                '_blank'
            );
        }

        // View report details
        function viewAdminReport(reportId, reportType) {
            fetch(`../BACKEND/get_report_details.php?report_id=${reportId}&report_type=${reportType}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showReportModal(data.report, reportType);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network error: ' + error.message);
                });
        }

        // Edit report function for admin
        function editAdminReport(reportId, reportType) {
            fetch(`../BACKEND/get_report_details.php?report_id=${reportId}&report_type=${reportType}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        if (!data.report.can_edit) {
                            alert('This report can no longer be edited (24-hour window expired)');
                            return;
                        }
                        showAdminEditModal(data.report, reportType);
                    } else {
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    alert('Network error: ' + error.message);
                });
        }

        // Show edit modal for admin
        function showAdminEditModal(report, reportType) {
    const hoursLeft = Math.floor(report.hours_remaining);
    const minutesLeft = Math.floor((report.hours_remaining - hoursLeft) * 60);
    
    const modalHTML = `
        <div class="report-modal" id="editModal">
            <div class="report-modal-content" style="max-width: 800px; max-height: 90vh; display: flex; flex-direction: column;">
                <div class="report-modal-header">
                    <h3>Edit ${reportType === 'daily' ? 'Daily Report' : 'Interception Report'}</h3>
                    <button class="close-modal" onclick="closeEditModal()">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="report-modal-body" style="flex: 1; overflow-y: auto; padding: 24px;">
                    <div class="info-note" style="margin-bottom: 20px;">
                        <i class="fas fa-clock"></i>
                        <span>Time remaining to edit: ${hoursLeft}h ${minutesLeft}m</span>
                    </div>
                    ${reportType === 'daily' ? generateDailyEditForm(report) : generateInterceptionEditForm(report)}
                </div>
                <div class="report-modal-footer" style="flex-shrink: 0;">
                    <button class="btn-close" onclick="closeEditModal()">
                        <i class="fas fa-times"></i> Cancel
                    </button>
                    <button class="btn-edit" onclick="saveAdminReportEdits(${report.id}, '${reportType}')">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    document.getElementById('editModal').style.display = 'flex';
}

        function generateDailyEditForm(report) {
            return `
                <form id="adminEditForm">
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 20px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Date</label>
                            <input type="date" name="report_date" class="form-input" value="${report.report_date}" required>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Shift</label>
                            <select name="shift" class="form-select" required>
                                <option value="1st Shift" ${report.shift === '1st Shift' ? 'selected' : ''}>1st Shift</option>
                                <option value="2nd Shift" ${report.shift === '2nd Shift' ? 'selected' : ''}>2nd Shift</option>
                                <option value="3rd Shift" ${report.shift === '3rd Shift' ? 'selected' : ''}>3rd Shift</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Team</label>
                            <select name="team" class="form-select" required>
                                <option value="Alpha" ${report.team === 'Alpha' ? 'selected' : ''}>Team Alpha</option>
                                <option value="Bravo" ${report.team === 'Bravo' ? 'selected' : ''}>Team Bravo</option>
                                <option value="Charlie" ${report.team === 'Charlie' ? 'selected' : ''}>Team Charlie</option>
                                <option value="Delta" ${report.team === 'Delta' ? 'selected' : ''}>Team Delta</option>
                            </select>
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Personnel Data</h4>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Screeners On Duty</label>
                            <input type="number" name="screeners_on_duty" class="form-input" value="${report.screeners_on_duty}" min="0" required>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Screeners Off *</label>
                            <input type="number" name="screeners_off" class="form-input" value="${report.screeners_off}" min="0" required>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Screeners On Leave *</label>
                            <input type="number" name="screeners_on_leave" class="form-input" value="${report.screeners_on_leave}" min="0" required>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Screeners Absent *</label>
                            <input type="number" name="screeners_absent" class="form-input" value="${report.screeners_absent}" min="0" required>
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Flight Summary</h4>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Domestic Departing Flights</label>
                            <input type="number" name="domestic_departing_flights" class="form-input" value="${report.domestic_departing_flights}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Domestic Passengers</label>
                            <input type="number" name="domestic_passengers" class="form-input" value="${report.domestic_passengers}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">International Departing Flights</label>
                            <input type="number" name="international_departing_flights" class="form-input" value="${report.international_departing_flights}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">International Passengers</label>
                            <input type="number" name="international_passengers" class="form-input" value="${report.international_passengers}" min="0">
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Prohibited Items</h4>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Blunt Instruments</label>
                            <input type="number" name="blunt_instruments" class="form-input" value="${report.blunt_instruments}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Sharp Objects</label>
                            <input type="number" name="sharp_objects" class="form-input" value="${report.sharp_objects}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Liquids/Aerosols/Gels</label>
                            <input type="number" name="liquid_aerosols_gels" class="form-input" value="${report.liquid_aerosols_gels}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Workers Tools</label>
                            <input type="number" name="workers_tools" class="form-input" value="${report.workers_tools}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Explosives/Incendiary</label>
                            <input type="number" name="explosives_incendiary" class="form-input" value="${report.explosives_incendiary}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Stunning Devices</label>
                            <input type="number" name="stunning_devices" class="form-input" value="${report.stunning_devices}" min="0">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Chemical/Toxic</label>
                            <input type="number" name="chemical_toxic" class="form-input" value="${report.chemical_toxic}" min="0">
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Additional Notes</h4>
                    <div class="form-group">
                        <textarea name="additional_notes" class="form-textarea" rows="4">${report.additional_notes || ''}</textarea>
                    </div>
                </form>
            `;
        }

        function generateInterceptionEditForm(report) {
            return `
                <form id="adminEditForm">
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; margin-bottom: 20px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Date</label>
                            <input type="date" name="report_date" class="form-input" value="${report.report_date}" required>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Shift</label>
                            <select name="shift" class="form-select" required>
                                <option value="1st Shift" ${report.shift === '1st Shift' ? 'selected' : ''}>1st Shift</option>
                                <option value="2nd Shift" ${report.shift === '2nd Shift' ? 'selected' : ''}>2nd Shift</option>
                                <option value="3rd Shift" ${report.shift === '3rd Shift' ? 'selected' : ''}>3rd Shift</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Team</label>
                            <select name="team" class="form-select" required>
                                <option value="Alpha" ${report.team === 'Alpha' ? 'selected' : ''}>Team Alpha</option>
                                <option value="Bravo" ${report.team === 'Bravo' ? 'selected' : ''}>Team Bravo</option>
                                <option value="Charlie" ${report.team === 'Charlie' ? 'selected' : ''}>Team Charlie</option>
                                <option value="Delta" ${report.team === 'Delta' ? 'selected' : ''}>Team Delta</option>
                            </select>
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Passenger Information</h4>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Passenger Name</label>
                            <input type="text" name="passenger_name" class="form-input" value="${report.passenger_name}" required>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Occupation</label>
                            <input type="text" name="occupation" class="form-input" value="${report.occupation}" required>
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Flight Details</h4>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Flight Number</label>
                            <input type="text" name="flight_number" class="form-input" value="${report.flight_number}" required>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Destination</label>
                            <input type="text" name="destination" class="form-input" value="${report.destination || ''}">
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Intercepted Item Details</h4>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Intercepted Item</label>
                            <select name="intercepted_item" class="form-select" required>
                                <option value="">Select intercepted item</option>
                                <option value="Suspected Ammo" ${report.intercepted_item === 'Suspected Ammo' ? 'selected' : ''}>Suspected Ammo</option>
                                <option value="Suspected Empty Shell" ${report.intercepted_item === 'Suspected Empty Shell' ? 'selected' : ''}>Suspected Empty Shell</option>
                                <option value="Suspected Firearms" ${report.intercepted_item === 'Suspected Firearms' ? 'selected' : ''}>Suspected Firearms</option>
                                <option value="Suspected Firearms Parts" ${report.intercepted_item === 'Suspected Firearms Parts' ? 'selected' : ''}>Suspected Firearms Parts</option>
                                <option value="Components" ${report.intercepted_item === 'Components' ? 'selected' : ''}>Components</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Quantity</label>
                            <input type="number" name="quantity" class="form-input" value="${report.quantity}" min="1" required>
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Intercepted By</h4>
                    <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 15px;">
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">X-ray Operator</label>
                            <input type="text" name="xray_operator" class="form-input" value="${report.xray_operator || ''}">
                        </div>
                        <div class="form-group">
                            <label style="font-weight: 600; display: block; margin-bottom: 5px;">Baggage Inspector</label>
                            <input type="text" name="baggage_pusher" class="form-input" value="${report.baggage_pusher || ''}">
                        </div>
                    </div>

                    <h4 style="margin: 20px 0 10px; color: var(--text-primary);">Remarks</h4>
                    <div class="form-group">
                        <textarea name="remarks" class="form-textarea" rows="4">${report.remarks || ''}</textarea>
                    </div>
                </form>
            `;
        }

        function saveAdminReportEdits(reportId, reportType) {
    const form = document.getElementById('adminEditForm');
    const formData = new FormData(form);
    formData.append('report_id', reportId);
    
    const endpoint = reportType === 'daily' ?
        '../BACKEND/update_daily_report.php' : 
        '../BACKEND/update_interception_report.php';
    
    console.log('Sending update to:', endpoint);
    console.log('Report ID:', reportId);
    
    fetch(endpoint, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        console.log('Response status:', response.status);
        
        // Get response as text first to see what's being returned
        return response.text().then(text => {
            console.log('Raw response text:', text);
            
            // Try to parse as JSON
            try {
                const data = JSON.parse(text);
                return { status: response.status, data: data, text: text };
            } catch (e) {
                console.error('JSON parse failed:', e);
                console.error('Response was:', text);
                return { status: response.status, data: null, text: text };
            }
        });
    })
    .then(result => {
        console.log('Processed result:', result);
        
        if (result.data && result.data.success) {
            alert('Report updated successfully!');
            closeEditModal();
            loadAllReportsForAdmin();
        } else if (result.data && result.data.message) {
            alert('Error: ' + result.data.message);
        } else {
            // Show the raw response if JSON parsing failed
            console.error('Server returned invalid response');
            alert('Server error. Response status: ' + result.status + '\n\nCheck browser console (F12) for details.');
        }
    })
    .catch(error => {
        console.error('Fetch error:', error);
        alert('Network error: ' + error.message);
    });
}

        function closeEditModal() {
            const modal = document.getElementById('editModal');
            if (modal) {
                modal.remove();
            }
        }

        function deleteAdminReport(reportId, reportType) {
            if (!confirm('Are you sure you want to delete this report? This action cannot be undone.')) {
                return;
            }
            
            const formData = new FormData();
            formData.append('report_id', reportId);
            
            const endpoint = reportType === 'daily' ? 
                '../BACKEND/delete_report.php' : 
                '../BACKEND/delete_interception_report.php';
            
            fetch(endpoint, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Report deleted successfully');
                    loadAllReportsForAdmin();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                alert('Network error: ' + error.message);
            });
        }

        function showReportModal(report, reportType) {
            const modalHTML = `
                <div class="report-modal" id="reportModal">
                    <div class="report-modal-content">
                        <div class="report-modal-header">
                            <h3>${reportType === 'daily' ? 'Daily Report' : 'Interception Report'} Details</h3>
                            <button class="close-modal" onclick="closeReportModal()">
                                <i class="fas fa-times"></i>
                            </button>
                        </div>
                        <div class="report-modal-body">
                            ${reportType === 'daily' ? generateDailyReportHTML(report) : generateInterceptionReportHTML(report)}
                        </div>
                        <div class="report-modal-footer">
                            <button class="btn-close" onclick="closeReportModal()">
                                <i class="fas fa-times"></i> Close
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            document.getElementById('reportModal').style.display = 'flex';
        }

        function closeReportModal() {
            const modal = document.getElementById('reportModal');
            if (modal) {
                modal.remove();
            }
        }

        function generateDailyReportHTML(report) {
            return `
                <div class="report-info">
                    <div class="info-row"><strong>Submitted By:</strong> ${report.username || 'Unknown'}</div>
                    <div class="info-row"><strong>Date:</strong> ${report.report_date}</div>
                    <div class="info-row"><strong>Shift:</strong> ${report.shift}</div>
                    <div class="info-row"><strong>Team:</strong> ${report.team}</div>
                    <div class="info-row"><strong>Status:</strong> ${report.status}</div>
                </div>
                
                <h4>Personnel Data</h4>
                <div class="report-info">
                    <div class="info-row"><strong>On Duty:</strong> ${report.screeners_on_duty}</div>
                    <div class="info-row"><strong>Off Duty:</strong> ${report.screeners_off || 0}</div>
                    <div class="info-row"><strong>On Leave:</strong> ${report.screeners_on_leave || 0}</div>
                    <div class="info-row"><strong>Absent:</strong> ${report.screeners_absent || 0}</div>
                </div>
                
                <h4>Flight Summary</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Domestic Flights:</strong> ${report.domestic_departing_flights} (${report.domestic_passengers} passengers)</div>
                    <div class="info-row"><strong>International Flights:</strong> ${report.international_departing_flights} (${report.international_passengers} passengers)</div>
                </div>
                
                <h4>Prohibited Items</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Blunt Instruments:</strong> ${report.blunt_instruments}</div>
                    <div class="info-row"><strong>Sharp Objects:</strong> ${report.sharp_objects}</div>
                    <div class="info-row"><strong>Liquids/Gels:</strong> ${report.liquid_aerosols_gels}</div>
                </div>
                
                ${report.additional_notes ? `
                    <h4>Additional Notes</h4>
                    <div class="report-info">
                        <p>${report.additional_notes}</p>
                    </div>
                ` : ''}
            `;
        }

        function generateInterceptionReportHTML(report) {
            return `
                <div class="report-info">
                    <div class="info-row"><strong>Submitted By:</strong> ${report.username || 'Unknown'}</div>
                    <div class="info-row"><strong>Date:</strong> ${report.report_date}</div>
                    <div class="info-row"><strong>Shift:</strong> ${report.shift}</div>
                    <div class="info-row"><strong>Team:</strong> ${report.team}</div>
                </div>
                
                <h4>Passenger Information</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Name:</strong> ${report.passenger_name}</div>
                    <div class="info-row"><strong>Occupation:</strong> ${report.occupation}</div>
                </div>
                
                <h4>Flight Details</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Flight Number:</strong> ${report.flight_number}</div>
                    <div class="info-row"><strong>Destination:</strong> ${report.destination || 'N/A'}</div>
                </div>
                
                <h4>Intercepted Item</h4>
                <div class="report-info">
                    <div class="info-row"><strong>Item:</strong> ${report.intercepted_item}</div>
                    <div class="info-row"><strong>Quantity:</strong> ${report.quantity}</div>
                </div>
                
                ${report.xray_operator || report.baggage_pusher ? `
                    <h4>Intercepted By</h4>
                    <div class="report-info">
                        ${report.xray_operator ? `<div class="info-row"><strong>X-ray Operator:</strong> ${report.xray_operator}</div>` : ''}
                        ${report.baggage_pusher ? `<div class="info-row"><strong>Baggage Inspector:</strong> ${report.baggage_pusher}</div>` : ''}
                    </div>
                ` : ''}
                
                ${report.remarks ? `
                    <h4>Remarks</h4>
                    <div class="report-info">
                        <p>${report.remarks}</p>
                    </div>
                ` : ''}
            `;
        }

        // Admin Personnel Management Functions
        async function initializeAdminPersonnel() {
        const editBtn = document.getElementById('editPersonnelBtn');
        const saveBtn = document.getElementById('savePersonnelBtn');
        const cancelBtn = document.getElementById('cancelPersonnelBtn');
        const editInfo = document.getElementById('editInfo');
        const saveSuccess = document.getElementById('saveSuccess');
        
        let originalData = {};
        let isEditing = false;

        // Load fresh data on page load - WAIT for it to complete
        await loadPersonnelData();

// Set up periodic refresh to sync with any changes
setInterval(async () => {
    if (!isEditing) { // Only refresh if not currently editing
        await loadPersonnelData();
    }
}, 60000); // Check every minute

            editBtn.addEventListener('click', async () => {
                await startEditing();
            });

            saveBtn.addEventListener('click', () => {
                savePersonnelData();
            });

            cancelBtn.addEventListener('click', () => {
                cancelEditing();
            });

            async function startEditing() {
            isEditing = true;
            // Ensure we have the latest data before editing
            await personnelManager.ensureInitialized();
            originalData = personnelManager.getData();
                
                const inputs = document.querySelectorAll('#personnelForm .form-input');
                inputs.forEach(input => {
                    input.readOnly = false;
                    input.style.backgroundColor = '#fff';
                    input.style.borderColor = 'var(--primary-blue)';
                });

                editBtn.style.display = 'none';
                saveBtn.style.display = 'inline-flex';
                cancelBtn.style.display = 'inline-flex';
                editInfo.style.display = 'flex';
                saveSuccess.style.display = 'none';
            }

            async function savePersonnelData() {
    const updatedData = {
        terminalChief: document.getElementById('terminalChief').value.trim(),
        totalPersonnel: parseInt(document.getElementById('totalPersonnel').value) || 0,
        totalSSO: parseInt(document.getElementById('totalSSO').value) || 0,
        admins: parseInt(document.getElementById('admins').value) || 0,
        shiftInCharges: parseInt(document.getElementById('shiftInCharges').value) || 0,
        checkpointSupervisors: parseInt(document.getElementById('checkpointSupervisors').value) || 0,
        ssoMale: parseInt(document.getElementById('ssoMale').value) || 0,
        ssoFemale: parseInt(document.getElementById('ssoFemale').value) || 0
    };

    if (!updatedData.terminalChief) {
        alert('Terminal Chief name is required');
        return;
    }

    const success = await personnelManager.updateFields(updatedData);
    if (success) {
        endEditing();
        showSuccessMessage();
        // Remove the problematic updateDashboardStats call
    } else {
        alert('Error saving data. Please try again.');
    }
}

            function cancelEditing() {
                loadPersonnelData(originalData);
                endEditing();
            }

            function endEditing() {
                isEditing = false;
                
                const inputs = document.querySelectorAll('#personnelForm .form-input');
                inputs.forEach(input => {
                    input.readOnly = true;
                    input.style.backgroundColor = '';
                    input.style.borderColor = '';
                });

                editBtn.style.display = 'inline-flex';
                saveBtn.style.display = 'none';
                cancelBtn.style.display = 'none';
                editInfo.style.display = 'none';
            }

            async function loadPersonnelData(data = null) {
            // Always ensure personnelManager is initialized first
            let personnelData;
            if (data) {
                personnelData = data;
            } else {
                // Force fresh load from database and wait for initialization
                await personnelManager.ensureInitialized();
                personnelData = await personnelManager.loadData();
            }
            
            if (personnelData) {
                document.getElementById('terminalChief').value = personnelData.terminalChief || '';
                document.getElementById('totalPersonnel').value = personnelData.totalPersonnel || 0;
                document.getElementById('totalSSO').value = personnelData.totalSSO || 0;
                document.getElementById('admins').value = personnelData.admins || 0;
                document.getElementById('shiftInCharges').value = personnelData.shiftInCharges || 0;
                document.getElementById('checkpointSupervisors').value = personnelData.checkpointSupervisors || 0;
                document.getElementById('ssoMale').value = personnelData.ssoMale || 0;
                document.getElementById('ssoFemale').value = personnelData.ssoFemale || 0;
            }
        }

            function showSuccessMessage() {
                saveSuccess.style.display = 'flex';
                setTimeout(() => {
                    saveSuccess.style.display = 'none';
                }, 3000);
            }

            personnelManager.onDataChange((data) => {
                if (!isEditing) {
                    loadPersonnelData(data);
                }
            });
        }

        // Enhanced Search and Filter Functions
        function initializeSearchFilters() {
            initializeReportsFilters();
            initializeDailyBreakdownFilters();
        }

        function initializeReportsFilters() {
            const dateInput = document.getElementById('reportDate');
            const searchInput = document.getElementById('reportsSearch');
            const typeFilter = document.getElementById('reportsTypeFilter');
            const showingElement = document.getElementById('reportsShowing');
            
            if (dateInput) dateInput.addEventListener('change', filterReports);
            if (searchInput) searchInput.addEventListener('input', filterReports);
            if (typeFilter) typeFilter.addEventListener('change', filterReports);

            function filterReports() {
                const selectedDate = dateInput?.value || '';
                const searchTerm = searchInput?.value.toLowerCase() || '';
                const selectedType = typeFilter?.value || '';
                
                const rows = document.querySelectorAll('#reportsTableBody tr');
                let visibleCount = 0;
                
                rows.forEach(row => {
                    const rowDate = row.getAttribute('data-date') || '';
                    const rowType = row.getAttribute('data-type') || '';
    
                    const typeText = row.querySelector('.report-type')?.textContent.toLowerCase() || '';
                    const submitterText = row.querySelector('.report-submitter')?.textContent.toLowerCase() || '';
                    
                    const matchesDate = !selectedDate || rowDate === selectedDate;
                    const passengerText = row.getAttribute('data-passenger')?.toLowerCase() || '';
                    const matchesSearch = !searchTerm || 
                        submitterText.includes(searchTerm) ||
                        passengerText.includes(searchTerm);
                    const matchesType = !selectedType || rowType === selectedType;
                    
                    
                    if (matchesDate && matchesSearch && matchesType) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });
                
                const dateText = selectedDate ? formatDateToWords(selectedDate) : formatDateToWords(dateInput?.value || '2025-08-22');
                if (showingElement) {
                    showingElement.textContent = `Showing ${visibleCount} reports for ${dateText}`;
                }
            }
        }

        function initializeDailyBreakdownFilters() {
            const dateInput = document.getElementById('dailyBreakdownDate');
            
            if (dateInput) {
                // Load data for current date on page load
                loadDailyBreakdown(dateInput.value);
                
                // Add event listener for date changes
                dateInput.addEventListener('change', function() {
                    loadDailyBreakdown(this.value);
                });
            }
        }

        function formatDateToWords(dateStr) {
            const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
            const date = new Date(dateStr);
            return date.toLocaleDateString('en-US', options);
        }

        // Auto-refresh reports every 30 seconds
        let autoRefreshInterval;

        function startAutoRefresh() {
            autoRefreshInterval = setInterval(() => {
                const activeContent = document.querySelector('.page-content.active');
                
                if (activeContent && activeContent.id === 'reportsMangementContent') {
                    Promise.all([
                        fetch('../BACKEND/get_all_daily_reports.php').then(r => r.json()),
                        fetch('../BACKEND/get_all_interception_reports.php').then(r => r.json())
                    ])
                    .then(([dailyData, interceptionData]) => {
                        const allReports = [];
                        
                        if (dailyData.success) {
                            dailyData.reports.forEach(report => {
                                report.type = 'daily';
                                allReports.push(report);
                            });
                        }
                        
                        if (interceptionData.success) {
                            interceptionData.reports.forEach(report => {
                                report.type = 'interception';
                                allReports.push(report);
                            });
                        }
                        
                        allReports.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
                        displayAllReportsAdmin(allReports);
                    })
                    .catch(error => console.error('Auto-refresh error:', error));
                }
            }, 30000);
        }

        function stopAutoRefresh() {
            if (autoRefreshInterval) {
                clearInterval(autoRefreshInterval);
            }
        }

        // Mobile menu toggle
        const mobileMenuToggle = document.getElementById('mobileMenuToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');
        const sidebarClose = document.getElementById('sidebarClose');

        function openSidebar() {
            sidebar.classList.add('active');
            mobileMenuToggle.classList.add('active');
            sidebarOverlay.classList.add('active');
            document.body.style.overflow = 'hidden';
        }

        function closeSidebar() {
            sidebar.classList.remove('active');
            mobileMenuToggle.classList.remove('active');
            sidebarOverlay.classList.remove('active');
            document.body.style.overflow = '';
        }

        mobileMenuToggle.addEventListener('click', () => {
            if (sidebar.classList.contains('active')) {
                closeSidebar();
            } else {
                openSidebar();
            }
        });

        sidebarClose.addEventListener('click', closeSidebar);
        sidebarOverlay.addEventListener('click', closeSidebar);

        document.addEventListener('click', (e) => {
            if (window.innerWidth <= 1024) {
                if (!sidebar.contains(e.target) && 
                    !mobileMenuToggle.contains(e.target) && 
                    sidebar.classList.contains('active')) {
                    closeSidebar();
                }
            }
        });

        const settingsBtn = document.querySelector('.settings-btn');
        settingsBtn.addEventListener('click', () => {
            alert('Settings panel - This would open settings configuration');
        });

        const userAvatar = document.querySelector('.user-avatar');
        userAvatar.addEventListener('click', () => {
            alert('Profile menu - This would show user profile options');
        });

        const navItems = document.querySelectorAll('.nav-item');
        const pageContents = document.querySelectorAll('.page-content');

        navItems.forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                
                const targetPage = item.getAttribute('data-page');
                
                if (targetPage === 'logout') {
                    if (confirm('Are you sure you want to logout?')) {
                        window.location.href = '../BACKEND/logout.php';
                    }
                    return;
                }
                
                navItems.forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');
                
                pageContents.forEach(page => page.classList.remove('active'));
                
                if (targetPage === 'overview') {
                    document.getElementById('overviewContent').classList.add('active');
                    stopAutoRefresh();
                    initializeAdminPersonnel();
                } else if (targetPage === 'reportsManagement') {
                    document.getElementById('reportsMangementContent').classList.add('active');
                    initializeReportsFilters();
                    loadAllReportsForAdmin();
                    startAutoRefresh();

                } else if (targetPage === 'adminLogs') {
                    document.getElementById('adminLogsContent').classList.add('active');
                    stopAutoRefresh();
                    loadAdminLogs();

                } else {
                    alert(`${item.querySelector('span').textContent} page coming soon!`);
                    document.querySelector('.nav-item[data-page="overview"]').classList.add('active');
                    document.getElementById('overviewContent').classList.add('active');
                    stopAutoRefresh();
                }
                
                if (window.innerWidth <= 1024) {
                    closeSidebar();
                }
            });
        });

        document.addEventListener('DOMContentLoaded', () => {
    // Clear all localStorage data that might interfere
    localStorage.removeItem('srs_personnel_data');
    Object.keys(localStorage).forEach(key => {
        if (key.includes('personnel') || key.includes('srs_')) {
            localStorage.removeItem(key);
        }
    });
    
    initializeAdminPersonnel();
    initializeSearchFilters();
    loadAllReportsForAdmin();
    loadDailyBreakdown();
    
    // Set report date to current date
    const reportDateInput = document.getElementById('reportDate');
    if (reportDateInput) {
        const today = new Date().toISOString().split('T')[0];
        reportDateInput.value = today;
    }
});

        let resizeTimer;
        window.addEventListener('resize', () => {
            clearTimeout(resizeTimer);
            resizeTimer = setTimeout(() => {
                if (window.innerWidth > 1024) {
                    closeSidebar();
                }
            }, 250);
        });

        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeReportModal();
                closeEditModal();
            }
        });


function loadDailyBreakdown(selectedDate = null) {
    const dateInput = document.getElementById('dailyBreakdownDate');
    const date = selectedDate || dateInput?.value || '2025-08-22';
    
    // Load general breakdown data
    fetch(`../BACKEND/get_daily_breakdown.php?date=${date}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const breakdown = data.breakdown;
                
                // Update Personnel Status
                document.getElementById('breakdownOnDuty').value = breakdown.total_on_duty || 0;
                document.getElementById('breakdownOff').value = breakdown.total_off || 0;
                document.getElementById('breakdownOnLeave').value = breakdown.total_on_leave || 0;
                document.getElementById('breakdownAbsent').value = breakdown.total_absent || 0;
                
                // Update International Flights
                document.getElementById('breakdownIntFlights').value = breakdown.total_international_flights || 0;
                document.getElementById('breakdownIntPassengers').value = breakdown.total_international_passengers || 0;
                document.getElementById('breakdownIntCancelled').value = breakdown.total_international_cancelled || 0;
                document.getElementById('breakdownIntAffected').value = breakdown.total_international_affected || 0;
                
                // Update Domestic Flights
                document.getElementById('breakdownDomFlights').value = breakdown.total_domestic_flights || 0;
                document.getElementById('breakdownDomPassengers').value = breakdown.total_domestic_passengers || 0;
                document.getElementById('breakdownDomCancelled').value = breakdown.total_domestic_cancelled || 0;
                document.getElementById('breakdownDomAffected').value = breakdown.total_domestic_affected || 0;
            }
        })
        .catch(error => {
            console.error('Error loading breakdown:', error);
        });
    
    // Load interception breakdown data
    fetch(`../BACKEND/get_interception_breakdown.php?date=${date}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const breakdown = data.breakdown;
                
                // Update Interception Reports
                document.getElementById('breakdownSuspectedAmmo').value = breakdown.suspected_ammo || 0;
                document.getElementById('breakdownSuspectedShell').value = breakdown.suspected_empty_shell || 0;
                document.getElementById('breakdownSuspectedFirearms').value = breakdown.suspected_firearms || 0;
                document.getElementById('breakdownSuspectedParts').value = breakdown.suspected_firearms_parts || 0;
                document.getElementById('breakdownSharpObjects').value = breakdown.sharp_objects || 0;
                document.getElementById('breakdownOtherProhibited').value = breakdown.other_prohibited || 0;
            }
        })
        .catch(error => {
            console.error('Error loading interception breakdown:', error);
        });
}

    // Load admin logs
function loadAdminLogs() {
    fetch('../BACKEND/get_admin_logs.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                displayAdminLogs(data.logs);
            } else {
                console.error('Error loading admin logs:', data.message);
            }
        })
        .catch(error => {
            console.error('Network error:', error);
        });
}

function displayAdminLogs(logs) {
    const tbody = document.getElementById('adminLogsTableBody');
    tbody.innerHTML = '';
    
    if (logs.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4" style="text-align: center; padding: 40px; color: var(--text-secondary);">No admin logs found</td></tr>';
        return;
    }
    
    logs.forEach(log => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="report-type">${log.report_type}</td>
            <td class="report-submitter">${log.activity}</td>
            <td class="admin-description">${log.description}</td>
            <td class="report-time">${formatDateTime(log.created_at)}</td>
        `;
        tbody.appendChild(row);
    });
    
    // Update showing text
    const showingElement = document.getElementById('adminLogsShowing');
    if (showingElement) {
        showingElement.textContent = `Showing ${logs.length} admin log${logs.length !== 1 ? 's' : ''}`;
    }
}

function formatDateTime(dateTimeStr) {
    const date = new Date(dateTimeStr);
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}


    </script>
</body>
</html>