<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin
if ($_SESSION['role'] !== 'it_admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';
require_once 'log_it_admin_action.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

$terminal_id = (int)($input['terminal_id'] ?? 0);
$terminal_name = trim($input['terminal_name'] ?? '');
$terminal_code = trim($input['terminal_code'] ?? '');
$description = trim($input['description'] ?? '');

// Validate inputs
if ($terminal_id <= 0 || empty($terminal_name) || empty($terminal_code)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

// Validate terminal code format (lowercase, numbers, underscores only)
if (!preg_match('/^[a-z0-9_]+$/', $terminal_code)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid terminal code format. Use lowercase letters, numbers, and underscores only.']);
    exit();
}

// Check if terminal code is already used by another terminal
$checkStmt = $mysqli->prepare("SELECT id FROM terminals WHERE terminal_code = ? AND id != ?");
$checkStmt->bind_param("si", $terminal_code, $terminal_id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Terminal code already exists']);
    $checkStmt->close();
    $mysqli->close();
    exit();
}
$checkStmt->close();

// Update terminal
$stmt = $mysqli->prepare("
    UPDATE terminals 
    SET terminal_name = ?, terminal_code = ?, description = ?
    WHERE id = ?
");

$stmt->bind_param("sssi", $terminal_name, $terminal_code, $description, $terminal_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Log IT admin action
        $it_admin_id = $_SESSION['user_id'];
        $it_admin_name = $_SESSION['username'] ?? 'Unknown IT Admin';
        $description = "Updated terminal: {$terminal_name} (Code: {$terminal_code})";
        logITAdminAction($mysqli, $it_admin_id, $it_admin_name, 'Edit Terminal', $description);
        
        echo json_encode(['success' => true, 'message' => 'Terminal updated successfully']);
    } else {
        echo json_encode(['success' => true, 'message' => 'No changes made']);
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to update terminal']);
}

$stmt->close();
$mysqli->close();
?>