<?php
// delete_interception_report.php - Delete an interception report and its images (within 24 hours)

session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';
require_once 'log_admin_action.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $report_id = intval($_POST['report_id'] ?? 0);
    $user_id = $_SESSION['user_id'];
    
    if ($report_id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid report ID']);
        exit();
    }
    
    // Get report with images
    $user_role = $_SESSION['role'];
    $is_privileged = in_array($user_role, ['admin', 'executive', 'it_admin']);

    if ($is_privileged) {
        // Admin can delete any report
        $stmt = $mysqli->prepare("
            SELECT created_at, image1, image2, image3, image4
            FROM interception_reports 
            WHERE id = ?
        ");
        $stmt->bind_param("i", $report_id);
    } else {
        // Regular users can only delete their own reports
        $stmt = $mysqli->prepare("
            SELECT created_at, image1, image2, image3, image4
            FROM interception_reports 
            WHERE id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $report_id, $user_id);
    }
    
    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Report not found']);
            exit();
        }
        
        $report = $result->fetch_assoc();
        $created_time = strtotime($report['created_at']);
        $hours_elapsed = (time() - $created_time) / 3600;
        
        if ($hours_elapsed >= 24) {
            http_response_code(403);
            echo json_encode(['success' => false, 'message' => '24-hour edit window has expired']);
            exit();
        }
        
        $stmt->close();
        
        // Delete the report from database
if ($is_privileged) {
    $delete_stmt = $mysqli->prepare("DELETE FROM interception_reports WHERE id = ?");
    $delete_stmt->bind_param("i", $report_id);
} else {
    $delete_stmt = $mysqli->prepare("DELETE FROM interception_reports WHERE id = ? AND user_id = ?");
    $delete_stmt->bind_param("ii", $report_id, $user_id);
}
        
        
      if ($delete_stmt->execute()) {
    // Delete associated image files
    $upload_dir = '../uploads/interception_reports/';
    for ($i = 1; $i <= 4; $i++) {
        $image_field = 'image' . $i;
        if (!empty($report[$image_field])) {
            $image_path = $upload_dir . $report[$image_field];
            if (file_exists($image_path)) {
                unlink($image_path);
            }
        }
    }
    
    // Log admin action ONLY if user role is 'admin'
    if ($user_role === 'admin') {
        $admin_name = $_SESSION['username'] ?? 'Unknown Admin';
        $description = "Deleted Interception Report (ID: {$report_id})";
        logAdminAction($mysqli, $user_id, $admin_name, 'Interception Report', 'Delete', $description, $report_id);
    }
    
    echo json_encode(['success' => true, 'message' => 'Report and images deleted successfully']);
    
        } else {
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Error deleting report']);
        }
        
        $delete_stmt->close();
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

$mysqli->close();
?>