<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin
if ($_SESSION['role'] !== 'it_admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';
require_once 'log_it_admin_action.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

$terminal_name = trim($input['terminal_name'] ?? '');
$terminal_code = trim($input['terminal_code'] ?? '');
$description = trim($input['description'] ?? '');

// Validate inputs
if (empty($terminal_name) || empty($terminal_code)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Terminal name and code are required']);
    exit();
}

// Validate terminal code format (lowercase, numbers, underscores only)
if (!preg_match('/^[a-z0-9_]+$/', $terminal_code)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid terminal code format. Use lowercase letters, numbers, and underscores only.']);
    exit();
}

// Check if terminal code already exists
$checkStmt = $mysqli->prepare("SELECT id FROM terminals WHERE terminal_code = ?");
$checkStmt->bind_param("s", $terminal_code);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Terminal code already exists']);
    $checkStmt->close();
    $mysqli->close();
    exit();
}
$checkStmt->close();

// Insert new terminal
$stmt = $mysqli->prepare("
    INSERT INTO terminals (terminal_name, terminal_code, description, created_at)
    VALUES (?, ?, ?, NOW())
");

$stmt->bind_param("sss", $terminal_name, $terminal_code, $description);

if ($stmt->execute()) {
    $new_terminal_id = $mysqli->insert_id;
    
    // Log IT admin action
    $it_admin_id = $_SESSION['user_id'];
    $it_admin_name = $_SESSION['username'] ?? 'Unknown IT Admin';
    $description = "Created new terminal: {$terminal_name} (Code: {$terminal_code})";
    logITAdminAction($mysqli, $it_admin_id, $it_admin_name, 'Add Terminal', $description);
    
    echo json_encode([
        'success' => true,
        'message' => 'Terminal created successfully',
        'terminal_id' => $new_terminal_id
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to create terminal']);
}

$stmt->close();
$mysqli->close();
?>