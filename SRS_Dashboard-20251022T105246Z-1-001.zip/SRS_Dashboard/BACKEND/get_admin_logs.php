<?php
// get_admin_logs.php - Fetch admin logs

date_default_timezone_set('Asia/Manila');
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is admin
if ($_SESSION['role'] !== 'admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Get the logged-in admin's ID
$admin_id = $_SESSION['user_id'];

// Get only the logs created by this specific admin
$stmt = $mysqli->prepare("
    SELECT 
        id, admin_name, report_type, activity, description, created_at
    FROM admin_logs
    WHERE admin_id = ?
    ORDER BY created_at DESC
    LIMIT 100
");

if ($stmt) {
    $stmt->bind_param("i", $admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    
    echo json_encode(['success' => true, 'logs' => $logs]);
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>