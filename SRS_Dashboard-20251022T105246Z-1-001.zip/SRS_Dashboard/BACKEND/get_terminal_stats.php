<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin or Executive
if (!in_array($_SESSION['role'], ['it_admin', 'executive'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Get statistics for all terminals (only user and admin)
$stmt = $mysqli->prepare("
    SELECT 
        terminal_assignment,
        COUNT(*) as total_users,
        SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as users,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admins
    FROM users
    WHERE role IN ('user', 'admin')
    GROUP BY terminal_assignment
");

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $stats = [];
    
    while ($row = $result->fetch_assoc()) {
        $stats[$row['terminal_assignment']] = [
            'total_users' => (int)$row['total_users'],
            'users' => (int)$row['users'],
            'admins' => (int)$row['admins']
        ];
    }
    
    // Get statistics for executives and IT admins (across all terminals)
    $execStmt = $mysqli->prepare("
        SELECT 
            COUNT(*) as total_users,
            SUM(CASE WHEN role = 'executive' THEN 1 ELSE 0 END) as executives,
            SUM(CASE WHEN role = 'it_admin' THEN 1 ELSE 0 END) as it_admins
        FROM users
        WHERE role IN ('executive', 'it_admin')
    ");
    
    if ($execStmt->execute()) {
        $execResult = $execStmt->get_result();
        $execRow = $execResult->fetch_assoc();
        $stats['executive_itadmin'] = [
            'total_users' => (int)$execRow['total_users'],
            'executives' => (int)$execRow['executives'],
            'it_admins' => (int)$execRow['it_admins']
        ];
    }
    $execStmt->close();
    
    echo json_encode(['success' => true, 'stats' => $stats]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$stmt->close();
$mysqli->close();
?>