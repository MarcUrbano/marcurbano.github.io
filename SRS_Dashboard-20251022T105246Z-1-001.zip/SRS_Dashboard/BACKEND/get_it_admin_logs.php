<?php
// get_it_admin_logs.php - Fetch IT admin logs

date_default_timezone_set('Asia/Manila');
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin
if ($_SESSION['role'] !== 'it_admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Get the logged-in IT admin's ID
$it_admin_id = $_SESSION['user_id'];

// Get only the logs created by this specific IT admin
$stmt = $mysqli->prepare("
    SELECT 
        id, it_admin_name, activity, description, created_at
    FROM it_admin_logs
    WHERE it_admin_id = ?
    ORDER BY created_at DESC
    LIMIT 100
");

if ($stmt) {
    $stmt->bind_param("i", $it_admin_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    
    echo json_encode(['success' => true, 'logs' => $logs]);
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>