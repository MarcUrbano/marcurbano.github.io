<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin
if ($_SESSION['role'] !== 'it_admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';
require_once 'log_it_admin_action.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

$user_id = (int)($input['user_id'] ?? 0);
$username = trim($input['username'] ?? '');
$full_name = trim($input['full_name'] ?? '');
$role = $input['role'] ?? '';
$terminal_assignment = $input['terminal_assignment'] ?? '';
$password = $input['password'] ?? ''; // Optional

// Validate inputs
if ($user_id <= 0 || empty($username) || empty($role) || empty($terminal_assignment)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid input']);
    exit();
}

// Validate email format
if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit();
}

// Validate role
$allowed_roles = ['user', 'admin', 'executive', 'it_admin'];
if (!in_array($role, $allowed_roles)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid role']);
    exit();
}

// Check if email is already used by another user
$checkStmt = $mysqli->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
$checkStmt->bind_param("si", $username, $user_id);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email already exists']);
    $checkStmt->close();
    $mysqli->close();
    exit();
}
$checkStmt->close();

// Update user
if (!empty($password)) {
    // Update with new password
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $mysqli->prepare("
        UPDATE users 
        SET username = ?, password_hash = ?, role = ?, terminal_assignment = ?, full_name = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->bind_param("sssssi", $username, $password_hash, $role, $terminal_assignment, $full_name, $user_id);
} else {
    // Update without changing password
    $stmt = $mysqli->prepare("
        UPDATE users 
        SET username = ?, role = ?, terminal_assignment = ?, full_name = ?, updated_at = NOW()
        WHERE id = ?
    ");
    $stmt->bind_param("ssssi", $username, $role, $terminal_assignment, $full_name, $user_id);
}

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Log IT admin action
        $it_admin_id = $_SESSION['user_id'];
        $it_admin_name = $_SESSION['username'] ?? 'Unknown IT Admin';
        $description = "Updated user: {$username} (Role: {$role}, Full Name: {$full_name})";
        logITAdminAction($mysqli, $it_admin_id, $it_admin_name, 'Edit User', $description);
        
        echo json_encode(['success' => true, 'message' => 'User updated successfully']);
    } else {
        echo json_encode(['success' => true, 'message' => 'No changes made']);
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to update user']);
}

$stmt->close();
$mysqli->close();
?>