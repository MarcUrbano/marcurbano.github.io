<?php
// get_interception_breakdown.php - Get aggregated interception reports breakdown from BOTH tables

date_default_timezone_set('Asia/Manila');
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user has admin, executive, or superAdmin role
$allowed_roles = ['admin', 'executive', 'it_admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Get date filter from request (default to today)
$filter_date = $_GET['date'] ?? date('Y-m-d');
// Determine terminal filter based on role
$user_role = $_SESSION['role'];
$user_terminal = $_SESSION['terminal_assignment'];

// Initialize all categories to 0
$breakdown = [
    'suspected_ammo' => 0,
    'suspected_empty_shell' => 0,
    'suspected_firearms' => 0,
    'suspected_firearms_parts' => 0,
    'sharp_objects' => 0,
    'other_prohibited' => 0
];

// ========================================
// PART 1: Get data from INTERCEPTION_REPORTS table
// ========================================
if ($user_role === 'admin') {
    // Admin can only see data from users in their same terminal
    $stmt1 = $mysqli->prepare("
        SELECT 
            ir.intercepted_item,
            SUM(ir.quantity) as total_quantity
        FROM interception_reports ir
        JOIN users u ON ir.user_id = u.id
        WHERE ir.report_date = ? AND ir.status = 'submitted' AND u.terminal_assignment = ?
        GROUP BY ir.intercepted_item
    ");
} else {
    // Executive and IT Admin can see all data
    $stmt1 = $mysqli->prepare("
        SELECT 
            intercepted_item,
            SUM(quantity) as total_quantity
        FROM interception_reports 
        WHERE report_date = ? AND status = 'submitted'
        GROUP BY intercepted_item
    ");
}

if ($stmt1) {
    if ($user_role === 'admin') {
        $stmt1->bind_param("ss", $filter_date, $user_terminal);
    } else {
        $stmt1->bind_param("s", $filter_date);
    }
    $stmt1->execute();
    $result1 = $stmt1->get_result();
    
    // Map interception reports data to breakdown categories
    while ($row = $result1->fetch_assoc()) {
        $item = $row['intercepted_item'];
        $quantity = intval($row['total_quantity']);
        
        switch ($item) {
            case 'Suspected Ammo':
                $breakdown['suspected_ammo'] += $quantity;
                break;
            case 'Suspected Empty Shell':
                $breakdown['suspected_empty_shell'] += $quantity;
                break;
            case 'Suspected Firearms':
                $breakdown['suspected_firearms'] += $quantity;
                break;
            case 'Suspected Firearms Parts':
            case 'Suspected Firearms Parts and Components':
                $breakdown['suspected_firearms_parts'] += $quantity;
                break;
            case 'Objects with Sharp Points & Edges':
            case 'Sharp Objects':
                $breakdown['sharp_objects'] += $quantity;
                break;
            default:
                $breakdown['other_prohibited'] += $quantity;
                break;
        }
    }
    
    $stmt1->close();
}

// ========================================
// PART 2: Get data from DAILY_REPORTS table
// ========================================
if ($user_role === 'admin') {
    // Admin can only see data from users in their same terminal
    $stmt2 = $mysqli->prepare("
        SELECT 
            SUM(dr.sharp_objects) as total_sharp_objects,
            SUM(dr.blunt_instruments) as total_blunt_instruments,
            SUM(dr.liquid_aerosols_gels) as total_liquid_aerosols_gels,
            SUM(dr.workers_tools) as total_workers_tools,
            SUM(dr.explosives_incendiary) as total_explosives_incendiary,
            SUM(dr.stunning_devices) as total_stunning_devices,
            SUM(dr.chemical_toxic) as total_chemical_toxic
        FROM daily_reports dr
        JOIN users u ON dr.user_id = u.id
        WHERE dr.report_date = ? AND dr.status = 'submitted' AND u.terminal_assignment = ?
    ");
} else {
    // Executive and IT Admin can see all data
    $stmt2 = $mysqli->prepare("
        SELECT 
            SUM(sharp_objects) as total_sharp_objects,
            SUM(blunt_instruments) as total_blunt_instruments,
            SUM(liquid_aerosols_gels) as total_liquid_aerosols_gels,
            SUM(workers_tools) as total_workers_tools,
            SUM(explosives_incendiary) as total_explosives_incendiary,
            SUM(stunning_devices) as total_stunning_devices,
            SUM(chemical_toxic) as total_chemical_toxic
        FROM daily_reports 
        WHERE report_date = ? AND status = 'submitted'
    ");
}

if ($stmt2) {
    if ($user_role === 'admin') {
        $stmt2->bind_param("ss", $filter_date, $user_terminal);
    } else {
        $stmt2->bind_param("s", $filter_date);
    }
    $stmt2->execute();
    $result2 = $stmt2->get_result();  // ADD THIS LINE - IT WAS MISSING!
    
    if ($row = $result2->fetch_assoc()) {
        // Add sharp_objects from daily reports
        $breakdown['sharp_objects'] += intval($row['total_sharp_objects'] ?? 0);
        
        // Add all other prohibited items from daily reports to "Other Prohibited Items"
        $breakdown['other_prohibited'] += intval($row['total_blunt_instruments'] ?? 0);
        $breakdown['other_prohibited'] += intval($row['total_liquid_aerosols_gels'] ?? 0);
        $breakdown['other_prohibited'] += intval($row['total_workers_tools'] ?? 0);
        $breakdown['other_prohibited'] += intval($row['total_explosives_incendiary'] ?? 0);
        $breakdown['other_prohibited'] += intval($row['total_stunning_devices'] ?? 0);
        $breakdown['other_prohibited'] += intval($row['total_chemical_toxic'] ?? 0);
    }
    
    $stmt2->close();
}

// Return combined results
echo json_encode([
    'success' => true,
    'date' => $filter_date,
    'breakdown' => $breakdown
]);

$mysqli->close();
?>