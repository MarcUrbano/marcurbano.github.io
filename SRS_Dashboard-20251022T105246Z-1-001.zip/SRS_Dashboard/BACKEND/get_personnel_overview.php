<?php
// get_personnel_overview.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

date_default_timezone_set('Asia/Manila');
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$allowed_roles = ['user', 'admin', 'executive', 'it_admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

try {
    $user_terminal = $_SESSION['terminal_assignment'];
    $terminal_code = $user_terminal;

    // Check if table exists
    $check_table = $mysqli->query("SHOW TABLES LIKE 'personnel_overview'");
    if ($check_table->num_rows == 0) {
        // Return default data if table doesn't exist
        echo json_encode([
            'success' => true,
            'terminal' => $terminal_code,
            'data' => [
                'terminalChief' => 'Captain Chris',
                'totalPersonnel' => 100,
                'totalSSO' => 42,
                'admins' => 2,
                'shiftInCharges' => 4,
                'checkpointSupervisors' => 6,
                'ssoMale' => 24,
                'ssoFemale' => 6
            ]
        ]);
        exit();
    }

    // Get personnel overview data for the terminal
    $stmt = $mysqli->prepare("
        SELECT terminal_chief, total_personnel, total_sso, airport_clerk, 
               shift_in_charges, checkpoint_supervisors, sso_male, sso_female
        FROM personnel_overview 
        WHERE terminal_code = ?
    ");

    if (!$stmt) {
        throw new Exception('Failed to prepare statement: ' . $mysqli->error);
    }

    $stmt->bind_param("s", $terminal_code);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            'success' => true,
            'terminal' => $terminal_code,
            'data' => [
                'terminalChief' => $row['terminal_chief'],
                'totalPersonnel' => (int)$row['total_personnel'],
                'totalSSO' => (int)$row['total_sso'],
                'admins' => (int)$row['airport_clerk'],
                'shiftInCharges' => (int)$row['shift_in_charges'],
                'checkpointSupervisors' => (int)$row['checkpoint_supervisors'],
                'ssoMale' => (int)$row['sso_male'],
                'ssoFemale' => (int)$row['sso_female']
            ]
        ]);
    } else {
        // Return default data if no record exists
        echo json_encode([
            'success' => true,
            'terminal' => $terminal_code,
            'data' => [
                'terminalChief' => 'Captain Chris',
                'totalPersonnel' => 100,
                'totalSSO' => 42,
                'admins' => 2,
                'shiftInCharges' => 4,
                'checkpointSupervisors' => 6,
                'ssoMale' => 24,
                'ssoFemale' => 6
            ]
        ]);
    }

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

$mysqli->close();
?>