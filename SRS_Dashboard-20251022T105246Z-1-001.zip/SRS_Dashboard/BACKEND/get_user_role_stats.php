<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin or Executive
if (!in_array($_SESSION['role'], ['it_admin', 'executive'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Get count for each role
$stmt = $mysqli->prepare("
    SELECT 
        SUM(CASE WHEN role = 'it_admin' THEN 1 ELSE 0 END) as it_admin_count,
        SUM(CASE WHEN role = 'executive' THEN 1 ELSE 0 END) as executive_count,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as airport_admin_count,
        SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as airport_user_count
    FROM users
");

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $stats = $result->fetch_assoc();
    
    echo json_encode([
        'success' => true,
        'stats' => [
            'it_admin' => (int)$stats['it_admin_count'],
            'executive' => (int)$stats['executive_count'],
            'airport_admin' => (int)$stats['airport_admin_count'],
            'airport_user' => (int)$stats['airport_user_count']
        ]
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$stmt->close();
$mysqli->close();
?>