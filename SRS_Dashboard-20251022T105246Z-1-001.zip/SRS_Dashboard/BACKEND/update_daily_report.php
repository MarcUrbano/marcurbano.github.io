<?php
// update_daily_report.php - Handle daily report updates (within 24 hours)

// Prevent any output before JSON
error_reporting(E_ALL);
ini_set('display_errors', 0); // Don't display errors directly
ini_set('log_errors', 1); // Log errors instead

// Start output buffering to catch any unwanted output
ob_start();

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    ob_end_clean();
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';
require_once 'log_admin_action.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $user_id = $_SESSION['user_id'];
    $report_id = intval($_POST['report_id'] ?? 0);
    
    if ($report_id <= 0) {
        ob_end_clean();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid report ID']);
        exit();
    }
    
    // Check if user is admin/executive/it_admin
    $user_role = $_SESSION['role'] ?? '';
    $is_privileged = in_array($user_role, ['admin', 'executive', 'it_admin']);

    // First, verify the report exists and GET ALL ORIGINAL DATA for comparison
    if ($is_privileged) {
        // Admin can edit any report - fetch ALL fields
        $check_stmt = $mysqli->prepare("
            SELECT * 
            FROM daily_reports 
            WHERE id = ?
        ");
        if (!$check_stmt) {
            ob_end_clean();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Database prepare error']);
            exit();
        }
        $check_stmt->bind_param("i", $report_id);
    } else {
        // Regular users can only edit their own reports - fetch ALL fields
        $check_stmt = $mysqli->prepare("
            SELECT * 
            FROM daily_reports 
            WHERE id = ? AND user_id = ?
        ");
        if (!$check_stmt) {
            ob_end_clean();
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Database prepare error']);
            exit();
        }
        $check_stmt->bind_param("ii", $report_id, $user_id);
    }
    
    $check_stmt->execute();
    $result = $check_stmt->get_result();
    
    if ($result->num_rows === 0) {
        ob_end_clean();
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Report not found or access denied']);
        exit();
    }
    
    $existing_report = $result->fetch_assoc();
    $original_data = $existing_report; // STORE ORIGINAL DATA FOR LOGGING COMPARISON
    
    // Check if within 24-hour edit window
    $created_time = strtotime($existing_report['created_at']);
    $hours_elapsed = (time() - $created_time) / 3600;
    
    if ($hours_elapsed >= 24) {
        ob_end_clean();
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => '24-hour edit window has expired']);
        exit();
    }
    
    $check_stmt->close();
    
    // Get form data
    $report_date = $_POST['report_date'] ?? '';
    $shift = $_POST['shift'] ?? '';
    $team = $_POST['team'] ?? '';
    
    // Personnel data
    $screeners_on_duty = intval($_POST['screeners_on_duty'] ?? 0);
    $screeners_off = intval($_POST['screeners_off'] ?? 0);
    $screeners_on_leave = intval($_POST['screeners_on_leave'] ?? 0);
    $screeners_absent = intval($_POST['screeners_absent'] ?? 0);
    
    // Domestic flights
    $domestic_departing_flights = intval($_POST['domestic_departing_flights'] ?? 0);
    $domestic_passengers = intval($_POST['domestic_passengers'] ?? 0);
    $domestic_cancelled_flights = intval($_POST['domestic_cancelled_flights'] ?? 0);
    $domestic_affected_passengers = intval($_POST['domestic_affected_passengers'] ?? 0);
    
    // International flights
    $international_departing_flights = intval($_POST['international_departing_flights'] ?? 0);
    $international_passengers = intval($_POST['international_passengers'] ?? 0);
    $international_cancelled_flights = intval($_POST['international_cancelled_flights'] ?? 0);
    $international_affected_passengers = intval($_POST['international_affected_passengers'] ?? 0);
    
    // Prohibited items
    $blunt_instruments = intval($_POST['blunt_instruments'] ?? 0);
    $liquid_aerosols_gels = intval($_POST['liquid_aerosols_gels'] ?? 0);
    $sharp_objects = intval($_POST['sharp_objects'] ?? 0);
    $workers_tools = intval($_POST['workers_tools'] ?? 0);
    $explosives_incendiary = intval($_POST['explosives_incendiary'] ?? 0);
    $stunning_devices = intval($_POST['stunning_devices'] ?? 0);
    $chemical_toxic = intval($_POST['chemical_toxic'] ?? 0);
    
    $additional_notes = trim($_POST['additional_notes'] ?? '');
    
    // Validate required fields
    if (empty($report_date) || empty($shift) || empty($team)) {
        ob_end_clean();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Date, shift, and team are required']);
        exit();
    }

    // Validate personnel data
    if ($screeners_on_duty < 0 || $screeners_off < 0 || $screeners_on_leave < 0 || $screeners_absent < 0) {
        ob_end_clean();
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'All personnel data fields must be 0 or greater']);
        exit();
    }
    
    // Handle new image uploads (optional for updates)
    $new_images = [];
    $upload_dir = '../uploads/daily_reports/';
    
    // Create directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        @mkdir($upload_dir, 0777, true);
    }
    
    // Process new images if any were uploaded
    for ($i = 1; $i <= 4; $i++) {
        $file_key = "report_image_" . $i;
        
        if (isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES[$file_key];
            
            // Validate file type
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowed_types)) {
                continue;
            }
            
            // Validate file size (max 5MB)
            if ($file['size'] > 5 * 1024 * 1024) {
                continue;
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'daily_' . $user_id . '_' . time() . '_' . $i . '.' . $extension;
            $filepath = $upload_dir . $filename;
            
            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $new_images[$i] = $filename;
                
                // Delete old image if exists
                $old_image_field = 'image' . $i;
                if (!empty($existing_report[$old_image_field])) {
                    $old_image_path = $upload_dir . $existing_report[$old_image_field];
                    if (file_exists($old_image_path)) {
                        @unlink($old_image_path);
                    }
                }
            }
        }
    }
    
    // Determine final image values (new images or keep existing)
    $image1 = $new_images[1] ?? $existing_report['image1'];
    $image2 = $new_images[2] ?? $existing_report['image2'];
    $image3 = $new_images[3] ?? $existing_report['image3'];
    $image4 = $new_images[4] ?? $existing_report['image4'];
    
    // Prepare the UPDATE statement
    $stmt = null;
    
    if ($is_privileged) {
        // Admin can update any report
        $stmt = $mysqli->prepare("
            UPDATE daily_reports SET
                report_date = ?,
                shift = ?,
                team = ?,
                screeners_on_duty = ?,
                screeners_off = ?,
                screeners_on_leave = ?,
                screeners_absent = ?,
                domestic_departing_flights = ?,
                domestic_passengers = ?,
                domestic_cancelled_flights = ?,
                domestic_affected_passengers = ?,
                international_departing_flights = ?,
                international_passengers = ?,
                international_cancelled_flights = ?,
                international_affected_passengers = ?,
                blunt_instruments = ?,
                liquid_aerosols_gels = ?,
                sharp_objects = ?,
                workers_tools = ?,
                explosives_incendiary = ?,
                stunning_devices = ?,
                chemical_toxic = ?,
                additional_notes = ?,
                image1 = ?,
                image2 = ?,
                image3 = ?,
                image4 = ?
            WHERE id = ?
        ");
        
        if ($stmt) {
            $stmt->bind_param(
                "sssiiiiiiiiiiiiiiiiiiiisssssi",
                $report_date, $shift, $team,
                $screeners_on_duty, $screeners_off, $screeners_on_leave, $screeners_absent,
                $domestic_departing_flights, $domestic_passengers, $domestic_cancelled_flights, $domestic_affected_passengers,
                $international_departing_flights, $international_passengers, $international_cancelled_flights, $international_affected_passengers,
                $blunt_instruments, $liquid_aerosols_gels, $sharp_objects, $workers_tools,
                $explosives_incendiary, $stunning_devices, $chemical_toxic,
                $additional_notes,
                $image1, $image2, $image3, $image4,
                $report_id
            );
        }
    } else {
        // Regular users can only update their own reports
        $stmt = $mysqli->prepare("
            UPDATE daily_reports SET
                report_date = ?,
                shift = ?,
                team = ?,
                screeners_on_duty = ?,
                screeners_off = ?,
                screeners_on_leave = ?,
                screeners_absent = ?,
                domestic_departing_flights = ?,
                domestic_passengers = ?,
                domestic_cancelled_flights = ?,
                domestic_affected_passengers = ?,
                international_departing_flights = ?,
                international_passengers = ?,
                international_cancelled_flights = ?,
                international_affected_passengers = ?,
                blunt_instruments = ?,
                liquid_aerosols_gels = ?,
                sharp_objects = ?,
                workers_tools = ?,
                explosives_incendiary = ?,
                stunning_devices = ?,
                chemical_toxic = ?,
                additional_notes = ?,
                image1 = ?,
                image2 = ?,
                image3 = ?,
                image4 = ?
            WHERE id = ? AND user_id = ?
        ");
        
        if ($stmt) {
            $stmt->bind_param(
                "sssiiiiiiiiiiiiiiiiiiiissssii",
                $report_date, $shift, $team,
                $screeners_on_duty, $screeners_off, $screeners_on_leave, $screeners_absent,
                $domestic_departing_flights, $domestic_passengers, $domestic_cancelled_flights, $domestic_affected_passengers,
                $international_departing_flights, $international_passengers, $international_cancelled_flights, $international_affected_passengers,
                $blunt_instruments, $liquid_aerosols_gels, $sharp_objects, $workers_tools,
                $explosives_incendiary, $stunning_devices, $chemical_toxic,
                $additional_notes,
                $image1, $image2, $image3, $image4,
                $report_id, $user_id
            );
        }
    }
    
    // Execute the statement
    if ($stmt && $stmt->execute()) {
        // Log admin action ONLY if user role is 'admin' (not executive or it_admin)
        if ($user_role === 'admin') {
            try {
                $admin_id = $_SESSION['user_id'];
                $admin_name = $_SESSION['username'] ?? 'Unknown Admin';
                
                // Build detailed change description using ORIGINAL data stored earlier
                $changes = [];
                
                // Compare each field with original data
                if ($original_data['report_date'] !== $report_date) {
                    $changes[] = "Report Date: {$original_data['report_date']} → {$report_date}";
                }
                if ($original_data['shift'] !== $shift) {
                    $changes[] = "Shift: {$original_data['shift']} → {$shift}";
                }
                if ($original_data['team'] !== $team) {
                    $changes[] = "Team: {$original_data['team']} → {$team}";
                }
                if ($original_data['screeners_on_duty'] != $screeners_on_duty) {
                    $changes[] = "Screeners On Duty: {$original_data['screeners_on_duty']} → {$screeners_on_duty}";
                }
                if ($original_data['screeners_off'] != $screeners_off) {
                    $changes[] = "Screeners Off: {$original_data['screeners_off']} → {$screeners_off}";
                }
                if ($original_data['screeners_on_leave'] != $screeners_on_leave) {
                    $changes[] = "Screeners On Leave: {$original_data['screeners_on_leave']} → {$screeners_on_leave}";
                }
                if ($original_data['screeners_absent'] != $screeners_absent) {
                    $changes[] = "Screeners Absent: {$original_data['screeners_absent']} → {$screeners_absent}";
                }
                if ($original_data['domestic_departing_flights'] != $domestic_departing_flights) {
                    $changes[] = "Domestic Departing Flights: {$original_data['domestic_departing_flights']} → {$domestic_departing_flights}";
                }
                if ($original_data['domestic_passengers'] != $domestic_passengers) {
                    $changes[] = "Domestic Passengers: {$original_data['domestic_passengers']} → {$domestic_passengers}";
                }
                if ($original_data['domestic_cancelled_flights'] != $domestic_cancelled_flights) {
                    $changes[] = "Domestic Cancelled Flights: {$original_data['domestic_cancelled_flights']} → {$domestic_cancelled_flights}";
                }
                if ($original_data['domestic_affected_passengers'] != $domestic_affected_passengers) {
                    $changes[] = "Domestic Affected Passengers: {$original_data['domestic_affected_passengers']} → {$domestic_affected_passengers}";
                }
                if ($original_data['international_departing_flights'] != $international_departing_flights) {
                    $changes[] = "International Departing Flights: {$original_data['international_departing_flights']} → {$international_departing_flights}";
                }
                if ($original_data['international_passengers'] != $international_passengers) {
                    $changes[] = "International Passengers: {$original_data['international_passengers']} → {$international_passengers}";
                }
                if ($original_data['international_cancelled_flights'] != $international_cancelled_flights) {
                    $changes[] = "International Cancelled Flights: {$original_data['international_cancelled_flights']} → {$international_cancelled_flights}";
                }
                if ($original_data['international_affected_passengers'] != $international_affected_passengers) {
                    $changes[] = "International Affected Passengers: {$original_data['international_affected_passengers']} → {$international_affected_passengers}";
                }
                if ($original_data['blunt_instruments'] != $blunt_instruments) {
                    $changes[] = "Blunt Instruments: {$original_data['blunt_instruments']} → {$blunt_instruments}";
                }
                if ($original_data['liquid_aerosols_gels'] != $liquid_aerosols_gels) {
                    $changes[] = "Liquid/Aerosols/Gels: {$original_data['liquid_aerosols_gels']} → {$liquid_aerosols_gels}";
                }
                if ($original_data['sharp_objects'] != $sharp_objects) {
                    $changes[] = "Sharp Objects: {$original_data['sharp_objects']} → {$sharp_objects}";
                }
                if ($original_data['workers_tools'] != $workers_tools) {
                    $changes[] = "Workers Tools: {$original_data['workers_tools']} → {$workers_tools}";
                }
                if ($original_data['explosives_incendiary'] != $explosives_incendiary) {
                    $changes[] = "Explosives/Incendiary: {$original_data['explosives_incendiary']} → {$explosives_incendiary}";
                }
                if ($original_data['stunning_devices'] != $stunning_devices) {
                    $changes[] = "Stunning Devices: {$original_data['stunning_devices']} → {$stunning_devices}";
                }
                if ($original_data['chemical_toxic'] != $chemical_toxic) {
                    $changes[] = "Chemical/Toxic: {$original_data['chemical_toxic']} → {$chemical_toxic}";
                }
                if ($original_data['additional_notes'] !== $additional_notes) {
                    $changes[] = "Additional Notes: Changed";
                }
                
                // Check for image changes
                for ($i = 1; $i <= 4; $i++) {
                    $img_field = 'image' . $i;
                    if ($original_data[$img_field] !== $$img_field) {
                        if (empty($original_data[$img_field]) && !empty($$img_field)) {
                            $changes[] = "Image {$i}: Added";
                        } elseif (!empty($original_data[$img_field]) && empty($$img_field)) {
                            $changes[] = "Image {$i}: Removed";
                        } elseif ($original_data[$img_field] !== $$img_field) {
                            $changes[] = "Image {$i}: Updated";
                        }
                    }
                }
                
                // Create description
                if (empty($changes)) {
                    $description = "Edited Daily Report (ID: {$report_id}) - No changes detected";
                } else {
                    $description = "Edited Daily Report (ID: {$report_id}) - Changes: " . implode("; ", $changes);
                }
                
                @logAdminAction($mysqli, $admin_id, $admin_name, 'Daily Report', 'Edit', $description, $report_id);
            } catch (Exception $e) {
                // Logging failed, but update succeeded - continue
            }
        }
                
        ob_end_clean();
        echo json_encode(['success' => true, 'message' => 'Report updated successfully']);
    } else {
        // Rollback: Delete new images if update fails
        foreach ($new_images as $img) {
            if (file_exists($upload_dir . $img)) {
                @unlink($upload_dir . $img);
            }
        }
        
        ob_end_clean();
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error updating report: ' . ($stmt ? $stmt->error : 'Statement preparation failed')]);
    }
    
    if ($stmt) {
        $stmt->close();
    }
} else {
    ob_end_clean();
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

$mysqli->close();
?>