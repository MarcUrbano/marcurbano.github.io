<?php
// get_interception_reports.php - Fetch user's interception reports

date_default_timezone_set('Asia/Manila'); // Set to your local time zone

session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';

$user_id = $_SESSION['user_id'];

// Get interception reports for the logged-in user
$stmt = $mysqli->prepare("
    SELECT 
        id, report_date, shift, team, status, created_at,
        passenger_name, flight_number, intercepted_item, quantity
    FROM interception_reports 
    WHERE user_id = ? 
    ORDER BY created_at DESC 
    LIMIT 50
");

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $reports = [];
    while ($row = $result->fetch_assoc()) {
        // Calculate if report is still editable (24 hours)
        $created_time = strtotime($row['created_at']);
        $current_time = time();
        $hours_elapsed = ($current_time - $created_time) / 3600;
        $row['can_edit'] = $hours_elapsed < 24;
        $row['hours_remaining'] = max(0, 24 - $hours_elapsed);
        
        $reports[] = $row;
    }
    
    echo json_encode(['success' => true, 'reports' => $reports]);
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>