<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin
if ($_SESSION['role'] !== 'it_admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';
require_once 'log_it_admin_action.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$terminal_id = (int)($input['terminal_id'] ?? 0);

if ($terminal_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid terminal ID']);
    exit();
}

// First, get the terminal_code for this terminal
$getTerminalStmt = $mysqli->prepare("SELECT terminal_code FROM terminals WHERE id = ?");
$getTerminalStmt->bind_param("i", $terminal_id);
$getTerminalStmt->execute();
$terminalResult = $getTerminalStmt->get_result();

if ($terminalResult->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Terminal not found']);
    $getTerminalStmt->close();
    $mysqli->close();
    exit();
}

$terminalRow = $terminalResult->fetch_assoc();
$terminal_code = $terminalRow['terminal_code'];
$getTerminalStmt->close();

// Now check if there are users assigned to this terminal
$checkStmt = $mysqli->prepare("SELECT COUNT(*) as user_count FROM users WHERE terminal_assignment = ?");
$checkStmt->bind_param("s", $terminal_code);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();
$checkRow = $checkResult->fetch_assoc();

if ($checkRow['user_count'] > 0) {
    http_response_code(400);
    echo json_encode([
        'success' => false, 
        'message' => 'Cannot delete terminal. There are ' . $checkRow['user_count'] . ' user(s) assigned to this terminal. Please reassign or delete users first.'
    ]);
    $checkStmt->close();
    $mysqli->close();
    exit();
}
$checkStmt->close();

// Delete terminal
// Get terminal name before deleting
$getNameStmt = $mysqli->prepare("SELECT terminal_name FROM terminals WHERE id = ?");
$getNameStmt->bind_param("i", $terminal_id);
$getNameStmt->execute();
$nameResult = $getNameStmt->get_result();
$terminal_name = '';
if ($nameRow = $nameResult->fetch_assoc()) {
    $terminal_name = $nameRow['terminal_name'];
}
$getNameStmt->close();

// Delete terminal
$stmt = $mysqli->prepare("DELETE FROM terminals WHERE id = ?");
$stmt->bind_param("i", $terminal_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Log IT admin action
        $it_admin_id = $_SESSION['user_id'];
        $it_admin_name = $_SESSION['username'] ?? 'Unknown IT Admin';
        $description = "Deleted terminal: {$terminal_name} (Code: {$terminal_code})";
        logITAdminAction($mysqli, $it_admin_id, $it_admin_name, 'Delete Terminal', $description);
        
        echo json_encode(['success' => true, 'message' => 'Terminal deleted successfully']);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Terminal not found']);
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to delete terminal: ' . $mysqli->error]);
}

$stmt->close();
$mysqli->close();
?>