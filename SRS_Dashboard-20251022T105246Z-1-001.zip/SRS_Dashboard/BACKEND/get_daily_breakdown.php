<?php
// get_daily_breakdown.php - Get aggregated daily operational breakdown

date_default_timezone_set('Asia/Manila');
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user has admin, executive, or superAdmin role
$allowed_roles = ['admin', 'executive', 'it_admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Get date filter from request (default to today)
$filter_date = $_GET['date'] ?? date('Y-m-d');

// Determine terminal filter based on role
$user_role = $_SESSION['role'];
$user_terminal = $_SESSION['terminal_assignment'];

// Get aggregated data for the selected date - filtered by terminal for admins
if ($user_role === 'admin') {
    // Admin can only see data from users in their same terminal
    $stmt = $mysqli->prepare("
        SELECT 
            SUM(dr.screeners_on_duty) as total_on_duty,
            SUM(dr.screeners_off) as total_off,
            SUM(dr.screeners_on_leave) as total_on_leave,
            SUM(dr.screeners_absent) as total_absent,
            SUM(dr.domestic_departing_flights) as total_domestic_flights,
            SUM(dr.domestic_passengers) as total_domestic_passengers,
            SUM(dr.domestic_cancelled_flights) as total_domestic_cancelled,
            SUM(dr.domestic_affected_passengers) as total_domestic_affected,
            SUM(dr.international_departing_flights) as total_international_flights,
            SUM(dr.international_passengers) as total_international_passengers,
            SUM(dr.international_cancelled_flights) as total_international_cancelled,
            SUM(dr.international_affected_passengers) as total_international_affected
        FROM daily_reports dr
        JOIN users u ON dr.user_id = u.id
        WHERE dr.report_date = ? AND dr.status = 'submitted' AND u.terminal_assignment = ?
    ");
} else {
    // Executive and IT Admin can see all data
    $stmt = $mysqli->prepare("
        SELECT 
            SUM(screeners_on_duty) as total_on_duty,
            SUM(screeners_off) as total_off,
            SUM(screeners_on_leave) as total_on_leave,
            SUM(screeners_absent) as total_absent,
            SUM(domestic_departing_flights) as total_domestic_flights,
            SUM(domestic_passengers) as total_domestic_passengers,
            SUM(domestic_cancelled_flights) as total_domestic_cancelled,
            SUM(domestic_affected_passengers) as total_domestic_affected,
            SUM(international_departing_flights) as total_international_flights,
            SUM(international_passengers) as total_international_passengers,
            SUM(international_cancelled_flights) as total_international_cancelled,
            SUM(international_affected_passengers) as total_international_affected
        FROM daily_reports
        WHERE report_date = ? AND status = 'submitted'
    ");
}

if ($stmt) {
    if ($user_role === 'admin') {
        $stmt->bind_param("ss", $filter_date, $user_terminal);
    } else {
        $stmt->bind_param("s", $filter_date);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            'success' => true,
            'date' => $filter_date,
            'breakdown' => $row
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'date' => $filter_date,
            'breakdown' => [
                'total_on_duty' => 0,
                'total_off' => 0,
                'total_on_leave' => 0,
                'total_absent' => 0,
                'total_domestic_flights' => 0,
                'total_domestic_passengers' => 0,
                'total_domestic_cancelled' => 0,
                'total_domestic_affected' => 0,
                'total_international_flights' => 0,
                'total_international_passengers' => 0,
                'total_international_cancelled' => 0,
                'total_international_affected' => 0
            ]
        ]);
    }
    
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>