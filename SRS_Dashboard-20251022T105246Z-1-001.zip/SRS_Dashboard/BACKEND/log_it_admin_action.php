<?php
// log_it_admin_action.php - Log IT admin actions for terminal and user management

function logITAdminAction($mysqli, $it_admin_id, $it_admin_name, $activity, $description) {
    $stmt = $mysqli->prepare("
        INSERT INTO it_admin_logs (it_admin_id, it_admin_name, activity, description, created_at)
        VALUES (?, ?, ?, ?, NOW())
    ");
    
    if ($stmt) {
        $stmt->bind_param("isss", $it_admin_id, $it_admin_name, $activity, $description);
        $stmt->execute();
        $stmt->close();
    }
}
?>