<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';

$stmt = $mysqli->prepare("SELECT id, terminal_name, terminal_code, description FROM terminals ORDER BY id ASC");

if ($stmt->execute()) {
    $result = $stmt->get_result();
    $terminals = [];
    
    while ($row = $result->fetch_assoc()) {
        $terminals[] = $row;
    }
    
    echo json_encode(['success' => true, 'terminals' => $terminals]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$stmt->close();
$mysqli->close();
?>