<?php
// get_all_interception_reports.php - Fetch all interception reports for admin/executive

date_default_timezone_set('Asia/Manila');

session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user has admin, executive, or superAdmin role
$allowed_roles = ['admin', 'executive', 'it_admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

require_once 'db.php';

// Determine which reports to show based on role
$user_role = $_SESSION['role'];
$user_terminal = $_SESSION['terminal_assignment'];

// Get interception reports with user information - filtered by terminal for regular admins
if ($user_role === 'admin') {
    // Admin can only see reports from users in their same terminal
    
    
    // Admin can only see reports from users in their same terminal
$stmt = $mysqli->prepare("
    SELECT 
        ir.id, ir.report_date, ir.shift, ir.team, ir.status, ir.created_at,
        ir.passenger_name, ir.flight_number, ir.intercepted_item, ir.quantity,
        u.username, u.id as user_id, u.terminal_assignment
    FROM interception_reports ir
    JOIN users u ON ir.user_id = u.id
    WHERE u.terminal_assignment = ?
    ORDER BY ir.created_at DESC 
    LIMIT 100
");


    $stmt->bind_param("s", $user_terminal);
} else {
    
    // Executive and IT Admin can see all reports
$stmt = $mysqli->prepare("
    SELECT 
        ir.id, ir.report_date, ir.shift, ir.team, ir.status, ir.created_at,
        ir.passenger_name, ir.flight_number, ir.intercepted_item, ir.quantity,
        u.username, u.id as user_id, u.terminal_assignment
    FROM interception_reports ir
    JOIN users u ON ir.user_id = u.id
    ORDER BY ir.created_at DESC 
    LIMIT 100
");

}

if ($stmt) {
    // Execute the query for all roles
    $stmt->execute();
    
    // Get results
    $result = $stmt->get_result();
    
    $reports = [];
    while ($row = $result->fetch_assoc()) {
        // Calculate if report is still editable (24 hours)
        $created_time = strtotime($row['created_at']);
        $current_time = time();
        $hours_elapsed = ($current_time - $created_time) / 3600;
        $row['can_edit'] = $hours_elapsed < 24;
        $row['hours_remaining'] = max(0, 24 - $hours_elapsed);
        
        $reports[] = $row;
    }
    
    echo json_encode(['success' => true, 'reports' => $reports]);
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>