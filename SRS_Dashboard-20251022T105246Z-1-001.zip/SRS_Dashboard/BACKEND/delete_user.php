<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin
if ($_SESSION['role'] !== 'it_admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';
require_once 'log_it_admin_action.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);
$user_id = (int)($input['user_id'] ?? 0);

if ($user_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid user ID']);
    exit();
}

// Prevent deleting own account
if ($user_id === $_SESSION['user_id']) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Cannot delete your own account']);
    exit();
}

// Delete user
// Get user info before deleting
$getUserStmt = $mysqli->prepare("SELECT username, full_name, role FROM users WHERE id = ?");
$getUserStmt->bind_param("i", $user_id);
$getUserStmt->execute();
$userResult = $getUserStmt->get_result();
$user_username = '';
$user_full_name = '';
$user_role = '';
if ($userRow = $userResult->fetch_assoc()) {
    $user_username = $userRow['username'];
    $user_full_name = $userRow['full_name'];
    $user_role = $userRow['role'];
}
$getUserStmt->close();

// Delete user
$stmt = $mysqli->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    if ($stmt->affected_rows > 0) {
        // Log IT admin action
        $it_admin_id = $_SESSION['user_id'];
        $it_admin_name = $_SESSION['username'] ?? 'Unknown IT Admin';
        $description = "Deleted user: {$user_username} (Role: {$user_role}, Full Name: {$user_full_name})";
        logITAdminAction($mysqli, $it_admin_id, $it_admin_name, 'Delete User', $description);
        
        echo json_encode(['success' => true, 'message' => 'User deleted successfully']);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to delete user']);
}

$stmt->close();
$mysqli->close();
?>