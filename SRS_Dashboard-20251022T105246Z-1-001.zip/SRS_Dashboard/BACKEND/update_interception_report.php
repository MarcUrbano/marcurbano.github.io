<?php
// update_interception_report.php - Handle interception report updates (within 24 hours)

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';
require_once 'log_admin_action.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $user_id = $_SESSION['user_id'];
    $report_id = intval($_POST['report_id'] ?? 0);
    
    if ($report_id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid report ID']);
        exit();
    }
    
    // First, verify the report exists
$user_role = $_SESSION['role'];
$is_privileged = in_array($user_role, ['admin', 'executive', 'it_admin']);

if ($is_privileged) {
    // Admin can edit any report - fetch ALL fields for comparison
    $check_stmt = $mysqli->prepare("
        SELECT * 
        FROM interception_reports 
        WHERE id = ?
    ");
    $check_stmt->bind_param("i", $report_id);
} else {
    // Regular users can only edit their own reports - fetch ALL fields for comparison
    $check_stmt = $mysqli->prepare("
        SELECT * 
        FROM interception_reports 
        WHERE id = ? AND user_id = ?
    ");
    $check_stmt->bind_param("ii", $report_id, $user_id);
}
    
if (!$check_stmt) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
    exit();
}

$check_stmt->execute();
$result = $check_stmt->get_result();
    
if ($result->num_rows === 0) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Report not found or access denied']);
    exit();
}

$existing_report = $result->fetch_assoc();
$original_data = $existing_report; // Store original data for logging changes

// Check if within 24-hour edit window
$created_time = strtotime($existing_report['created_at']);
$hours_elapsed = (time() - $created_time) / 3600;

if ($hours_elapsed >= 24) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => '24-hour edit window has expired']);
    exit();
}

$check_stmt->close();


    // Get form data
    $report_date = $_POST['report_date'] ?? '';
    $shift = $_POST['shift'] ?? '';
    $team = $_POST['team'] ?? '';
    
    // Personal data
    $passenger_name = trim($_POST['passenger_name'] ?? '');
    $occupation = trim($_POST['occupation'] ?? '');
    
    // Flight details
    $flight_number = trim($_POST['flight_number'] ?? '');
    $destination = trim($_POST['destination'] ?? '');
    
    // Intercepted item details
    $intercepted_item = trim($_POST['intercepted_item'] ?? '');
    $quantity = intval($_POST['quantity'] ?? 1);
    
    // Intercepted by
    $xray_operator = trim($_POST['xray_operator'] ?? '');
    $baggage_pusher = trim($_POST['baggage_pusher'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');
    
    // Validate required fields
    if (empty($report_date) || empty($shift) || empty($team)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Date, shift, and team are required']);
        exit();
    }
    
    if (empty($passenger_name) || empty($occupation)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Passenger name and occupation are required']);
        exit();
    }
    
    if (empty($flight_number) || empty($intercepted_item)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Flight number and intercepted item are required']);
        exit();
    }
    
    // Handle new image uploads (optional for updates)
    $new_images = [];
    $upload_dir = '../uploads/interception_reports/';
    
    // Create directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Process new images if any were uploaded
    for ($i = 1; $i <= 4; $i++) {
        $file_key = "interception_image_" . $i;
        
        if (isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES[$file_key];
            
            // Validate file type
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowed_types)) {
                continue;
            }
            
            // Validate file size (max 5MB)
            if ($file['size'] > 5 * 1024 * 1024) {
                continue;
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'interception_' . $user_id . '_' . time() . '_' . $i . '.' . $extension;
            $filepath = $upload_dir . $filename;
            
            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $new_images[$i] = $filename;
                
                // Delete old image if exists
                $old_image_field = 'image' . $i;
                if (!empty($existing_report[$old_image_field])) {
                    $old_image_path = $upload_dir . $existing_report[$old_image_field];
                    if (file_exists($old_image_path)) {
                        unlink($old_image_path);
                    }
                }
            }
        }
    }
    
    // Determine final image values (new images or keep existing)
    $image1 = $new_images[1] ?? $existing_report['image1'];
    $image2 = $new_images[2] ?? $existing_report['image2'];
    $image3 = $new_images[3] ?? $existing_report['image3'];
    $image4 = $new_images[4] ?? $existing_report['image4'];
    
if ($is_privileged) {
    // Admin can update any report
    $stmt = $mysqli->prepare("
        UPDATE interception_reports SET
            report_date = ?,
            shift = ?,
            team = ?,
            passenger_name = ?,
            occupation = ?,
            flight_number = ?,
            destination = ?,
            intercepted_item = ?,
            quantity = ?,
            xray_operator = ?,
            baggage_pusher = ?,
            remarks = ?,
            image1 = ?,
            image2 = ?,
            image3 = ?,
            image4 = ?
        WHERE id = ?
    ");
    
    $stmt->bind_param(
        "sssssssssissssssi",
        $report_date, $shift, $team,
        $passenger_name, $occupation,
        $flight_number, $destination,
        $intercepted_item, $quantity,
        $xray_operator, $baggage_pusher, $remarks,
        $image1, $image2, $image3, $image4,
        $report_id
    );
} else {
    // Regular users can only update their own reports
    $stmt = $mysqli->prepare("
        UPDATE interception_reports SET
            report_date = ?,
            shift = ?,
            team = ?,
            passenger_name = ?,
            occupation = ?,
            flight_number = ?,
            destination = ?,
            intercepted_item = ?,
            quantity = ?,
            xray_operator = ?,
            baggage_pusher = ?,
            remarks = ?,
            image1 = ?,
            image2 = ?,
            image3 = ?,
            image4 = ?
        WHERE id = ? AND user_id = ?
    ");
    
    $stmt->bind_param(
        "sssssssssissssssii",
        $report_date, $shift, $team,
        $passenger_name, $occupation,
        $flight_number, $destination,
        $intercepted_item, $quantity,
        $xray_operator, $baggage_pusher, $remarks,
        $image1, $image2, $image3, $image4,
        $report_id, $user_id
    );
}
    
    if ($stmt) {
        
        if ($stmt->execute()) {
    // Log admin action ONLY if user role is 'admin' (not executive or it_admin)
    if ($user_role === 'admin') {
        try {
            $admin_id = $_SESSION['user_id'];
            $admin_name = $_SESSION['username'] ?? 'Unknown Admin';
            
            // original_data was already fetched BEFORE the update
            // Build detailed change description
            $changes = [];
                
            // Compare each field
            if ($original_data['report_date'] !== $report_date) {
                $changes[] = "Report Date: {$original_data['report_date']} → {$report_date}";
            }
            if ($original_data['shift'] !== $shift) {
                $changes[] = "Shift: {$original_data['shift']} → {$shift}";
            }
            if ($original_data['team'] !== $team) {
                $changes[] = "Team: {$original_data['team']} → {$team}";
            }
            if ($original_data['passenger_name'] !== $passenger_name) {
                $changes[] = "Passenger Name: {$original_data['passenger_name']} → {$passenger_name}";
            }
            if ($original_data['occupation'] !== $occupation) {
                $changes[] = "Occupation: {$original_data['occupation']} → {$occupation}";
            }
            if ($original_data['flight_number'] !== $flight_number) {
                $changes[] = "Flight Number: {$original_data['flight_number']} → {$flight_number}";
            }
            if ($original_data['destination'] !== $destination) {
                $changes[] = "Destination: {$original_data['destination']} → {$destination}";
            }
            if ($original_data['intercepted_item'] !== $intercepted_item) {
                $changes[] = "Intercepted Item: {$original_data['intercepted_item']} → {$intercepted_item}";
            }
            if ($original_data['quantity'] != $quantity) {
                $changes[] = "Quantity: {$original_data['quantity']} → {$quantity}";
            }
            if ($original_data['xray_operator'] !== $xray_operator) {
                $changes[] = "X-ray Operator: {$original_data['xray_operator']} → {$xray_operator}";
            }
            if ($original_data['baggage_pusher'] !== $baggage_pusher) {
                $changes[] = "Baggage Pusher: {$original_data['baggage_pusher']} → {$baggage_pusher}";
            }
            if ($original_data['remarks'] !== $remarks) {
                $changes[] = "Remarks: Changed";
            }
            
            // Check for image changes
            for ($i = 1; $i <= 4; $i++) {
                $img_field = 'image' . $i;
                if ($original_data[$img_field] !== $$img_field) {
                    if (empty($original_data[$img_field]) && !empty($$img_field)) {
                        $changes[] = "Image {$i}: Added";
                    } elseif (!empty($original_data[$img_field]) && empty($$img_field)) {
                        $changes[] = "Image {$i}: Removed";
                    } elseif ($original_data[$img_field] !== $$img_field) {
                        $changes[] = "Image {$i}: Updated";
                    }
                }
            }
            
            // Create description
            if (empty($changes)) {
                $description = "Edited Interception Report (ID: {$report_id}) - No changes detected";
            } else {
                $description = "Edited Interception Report (ID: {$report_id}) - Changes: " . implode("; ", $changes);
            }
            
            @logAdminAction($mysqli, $admin_id, $admin_name, 'Interception Report', 'Edit', $description, $report_id);
        } catch (Exception $e) {
            // Logging failed, but update succeeded - continue
        }
    }
    
    echo json_encode(['success' => true, 'message' => 'Report updated successfully']);
    

        } else {
            // Rollback: Delete new images if update fails
            foreach ($new_images as $img) {
                if (file_exists($upload_dir . $img)) {
                    unlink($upload_dir . $img);
                }
            }
            
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Error updating report: ' . $stmt->error]);
        }
        
        $stmt->close();
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $mysqli->error]);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

$mysqli->close();
?>