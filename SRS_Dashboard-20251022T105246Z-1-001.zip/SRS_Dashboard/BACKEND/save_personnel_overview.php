<?php
// save_personnel_overview.php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

date_default_timezone_set('Asia/Manila');
session_start();

// Debug session data
error_log("Debug - Session data: " . print_r($_SESSION, true));

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user has admin role
$allowed_roles = ['admin', 'executive', 'it_admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Get JSON input
        $json = file_get_contents('php://input');
        $input = json_decode($json, true);
        
        if (!$input) {
            throw new Exception('Invalid JSON input');
        }
        
        // Handle terminal assignment - check multiple possible sources
        $terminal_code = null;
        
        if (isset($_SESSION['terminal_assignment']) && !empty($_SESSION['terminal_assignment'])) {
            $terminal_code = $_SESSION['terminal_assignment'];
        } else {
            // Fallback: try to get from user table
            $user_id = $_SESSION['user_id'];
            $stmt = $mysqli->prepare("SELECT terminal_assignment FROM users WHERE id = ?");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($row = $result->fetch_assoc()) {
                $terminal_code = $row['terminal_assignment'];
                // Update session with this value
                $_SESSION['terminal_assignment'] = $terminal_code;
            }
        }
        
        // If still no terminal code, use a default
        if (empty($terminal_code)) {
            $terminal_code = 'terminal1'; // Default fallback
            $_SESSION['terminal_assignment'] = $terminal_code;
        }
        
        error_log("Debug - Using terminal_code: " . $terminal_code);
        
        // Validate input data
        $terminal_chief = trim($input['terminalChief'] ?? '');
        $total_personnel = (int)($input['totalPersonnel'] ?? 0);
        $total_sso = (int)($input['totalSSO'] ?? 0);
        $airport_clerk = (int)($input['admins'] ?? 0);
        $shift_in_charges = (int)($input['shiftInCharges'] ?? 0);
        $checkpoint_supervisors = (int)($input['checkpointSupervisors'] ?? 0);
        $sso_male = (int)($input['ssoMale'] ?? 0);
        $sso_female = (int)($input['ssoFemale'] ?? 0);
        
        if (empty($terminal_chief)) {
            throw new Exception('Terminal Chief name is required');
        }
        
        // Insert or update personnel overview data
        $stmt = $mysqli->prepare("
            INSERT INTO personnel_overview 
            (terminal_code, terminal_chief, total_personnel, total_sso, airport_clerk, 
             shift_in_charges, checkpoint_supervisors, sso_male, sso_female)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
            terminal_chief = VALUES(terminal_chief),
            total_personnel = VALUES(total_personnel),
            total_sso = VALUES(total_sso),
            airport_clerk = VALUES(airport_clerk),
            shift_in_charges = VALUES(shift_in_charges),
            checkpoint_supervisors = VALUES(checkpoint_supervisors),
            sso_male = VALUES(sso_male),
            sso_female = VALUES(sso_female),
            updated_at = CURRENT_TIMESTAMP
        ");
        
        if (!$stmt) {
            throw new Exception('Failed to prepare statement: ' . $mysqli->error);
        }
        
        $stmt->bind_param("ssiiiiiii", 
            $terminal_code, 
            $terminal_chief, 
            $total_personnel, 
            $total_sso, 
            $airport_clerk,
            $shift_in_charges, 
            $checkpoint_supervisors, 
            $sso_male, 
            $sso_female
        );
        
        if (!$stmt->execute()) {
            throw new Exception('Failed to execute statement: ' . $stmt->error);
        }
        
        echo json_encode(['success' => true, 'message' => 'Personnel overview updated successfully']);
        
    } catch (Exception $e) {
        error_log("Error in save_personnel_overview.php: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

$mysqli->close();
?>