<?php
// submit_interception_report.php - Handle interception report submission with images

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $user_id = $_SESSION['user_id'];
    
    // Get form data
    $report_date = $_POST['report_date'] ?? '';
    $shift = $_POST['shift'] ?? '';
    $team = $_POST['team'] ?? '';
    
    // Personal data
    $passenger_name = trim($_POST['passenger_name'] ?? '');
    $occupation = trim($_POST['occupation'] ?? '');
    
    // Flight details
    $flight_number = trim($_POST['flight_number'] ?? '');
    $destination = trim($_POST['destination'] ?? '');
    
    // Intercepted item details
    $intercepted_item = trim($_POST['intercepted_item'] ?? '');
    $quantity = intval($_POST['quantity'] ?? 1);
    
    // Intercepted by
    $xray_operator = trim($_POST['xray_operator'] ?? '');
    $baggage_pusher = trim($_POST['baggage_pusher'] ?? '');
    $remarks = trim($_POST['remarks'] ?? '');
    
    // Validate required fields
    if (empty($report_date) || empty($shift) || empty($team)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Date, shift, and team are required']);
        exit();
    }
    
    if (empty($passenger_name) || empty($occupation)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Passenger name and occupation are required']);
        exit();
    }
    
    if (empty($flight_number) || empty($intercepted_item)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Flight number and intercepted item are required']);
        exit();
    }
    
    // Handle image uploads
    $uploaded_images = [];
    $upload_dir = '../uploads/interception_reports/';
    
    // Create directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Process up to 4 images
    for ($i = 1; $i <= 4; $i++) {
        $file_key = "interception_image_" . $i;
        
        if (isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES[$file_key];
            
            // Validate file type
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowed_types)) {
                continue; // Skip invalid file types
            }
            
            // Validate file size (max 5MB)
            if ($file['size'] > 5 * 1024 * 1024) {
                continue; // Skip files larger than 5MB
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'interception_' . $user_id . '_' . time() . '_' . $i . '.' . $extension;
            $filepath = $upload_dir . $filename;
            
            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $uploaded_images[$i] = $filename;
            }
        }
    }
    
    // Require at least 2 images
    if (count($uploaded_images) < 2) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'At least 2 evidence photos are required']);
        exit();
    }
    
    // Get image filenames (or null if not uploaded)
    $image1 = $uploaded_images[1] ?? null;
    $image2 = $uploaded_images[2] ?? null;
    $image3 = $uploaded_images[3] ?? null;
    $image4 = $uploaded_images[4] ?? null;
    
    // Prepare SQL with image fields
    $stmt = $mysqli->prepare("
        INSERT INTO interception_reports (
            user_id, report_date, shift, team,
            passenger_name, occupation,
            flight_number, destination,
            intercepted_item, quantity,
            xray_operator, baggage_pusher, remarks,
            image1, image2, image3, image4,
            status
        ) VALUES (
            ?, ?, ?, ?,
            ?, ?,
            ?, ?,
            ?, ?,
            ?, ?, ?,
            ?, ?, ?, ?,
            'submitted'
        )
    ");
    
    if ($stmt) {
        $stmt->bind_param(
            "issssssssisssssss",
            $user_id, $report_date, $shift, $team,
            $passenger_name, $occupation,
            $flight_number, $destination,
            $intercepted_item, $quantity,
            $xray_operator, $baggage_pusher, $remarks,
            $image1, $image2, $image3, $image4
        );
        
        if ($stmt->execute()) {
            $report_id = $stmt->insert_id;
            echo json_encode([
                'success' => true, 
                'message' => 'Interception report submitted successfully',
                'report_id' => $report_id,
                'images_uploaded' => count($uploaded_images)
            ]);
            
        } else {
            // Delete uploaded images if database insert fails
            foreach ($uploaded_images as $img) {
                if (file_exists($upload_dir . $img)) {
                    unlink($upload_dir . $img);
                }
            }
            
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Error saving report: ' . $stmt->error]);
        }
        
        $stmt->close();
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

$mysqli->close();
?>