<?php
// log_admin_action.php - Log admin actions for edit/delete reports

function logAdminAction($mysqli, $admin_id, $admin_name, $report_type, $activity, $description, $report_id) {
    $stmt = $mysqli->prepare("
        INSERT INTO admin_logs (admin_id, admin_name, report_type, activity, description, report_id, created_at)
        VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");
    
    if ($stmt) {
        $stmt->bind_param("issssi", $admin_id, $admin_name, $report_type, $activity, $description, $report_id);
        $stmt->execute();
        $stmt->close();
    }
}
?>