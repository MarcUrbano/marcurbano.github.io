<?php
// create_emergency_admin.php
// PLACE THIS FILE IN YOUR BACKEND FOLDER
// Access via: http://yoursite.com/BACKEND/create_emergency_admin.php
// DELETE THIS FILE AFTER USE FOR SECURITY!

require_once 'db.php';

// Configuration - Change these values
$new_username = 'itadmin1@example.com';
$new_password = 'Password123!';
$new_full_name = 'IT Admin Backup';
$new_role = 'it_admin';
$new_terminal = 'terminal1';  // Change if needed

echo "<!DOCTYPE html>";
echo "<html><head><title>Emergency IT Admin Creator</title>";
echo "<style>
    body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
    .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
    h1 { color: #313893; }
    .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 15px 0; border: 1px solid #c3e6cb; }
    .error { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px; margin: 15px 0; border: 1px solid #f5c6cb; }
    .warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 5px; margin: 15px 0; border: 1px solid #ffeaa7; }
    .info { background: #d1ecf1; color: #0c5460; padding: 15px; border-radius: 5px; margin: 15px 0; border: 1px solid #bee5eb; }
    code { background: #f4f4f4; padding: 2px 6px; border-radius: 3px; font-family: monospace; }
    .btn { background: #313893; color: white; padding: 12px 24px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; text-decoration: none; display: inline-block; margin-top: 10px; }
    .btn:hover { background: #252d6e; }
    .danger-btn { background: #dc3545; }
    .danger-btn:hover { background: #c82333; }
</style></head><body>";

echo "<div class='container'>";
echo "<h1>🚨 Emergency IT Admin Account Creator</h1>";

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_account'])) {
    
    echo "<h2>Creating Account...</h2>";
    
    // Validate email format
    if (!filter_var($new_username, FILTER_VALIDATE_EMAIL)) {
        echo "<div class='error'>❌ Invalid email format!</div>";
        exit();
    }
    
    // Check if user already exists
    $checkStmt = $mysqli->prepare("SELECT id FROM users WHERE username = ?");
    $checkStmt->bind_param("s", $new_username);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult->num_rows > 0) {
        echo "<div class='error'>❌ User with email <strong>$new_username</strong> already exists!</div>";
        echo "<p>You can either:</p>";
        echo "<ul>";
        echo "<li>Change the email in this file (line 9)</li>";
        echo "<li>Delete the existing user first</li>";
        echo "<li>Use the debug tool to reset the existing user's password</li>";
        echo "</ul>";
        $checkStmt->close();
    } else {
        $checkStmt->close();
        
        // Hash the password
        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
        
        // Insert new user
        $stmt = $mysqli->prepare("
            INSERT INTO users (username, password_hash, role, terminal_assignment, full_name, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, NOW(), NOW())
        ");
        
        $stmt->bind_param("sssss", $new_username, $password_hash, $new_role, $new_terminal, $new_full_name);
        
        if ($stmt->execute()) {
            $new_user_id = $mysqli->insert_id;
            
            echo "<div class='success'>";
            echo "<h3>✅ IT Admin Account Created Successfully!</h3>";
            echo "<p><strong>User ID:</strong> $new_user_id</p>";
            echo "<p><strong>Email:</strong> $new_username</p>";
            echo "<p><strong>Password:</strong> $new_password</p>";
            echo "<p><strong>Role:</strong> $new_role</p>";
            echo "<p><strong>Terminal:</strong> $new_terminal</p>";
            echo "</div>";
            
            echo "<div class='info'>";
            echo "<h3>📋 Next Steps:</h3>";
            echo "<ol>";
            echo "<li><strong>Login Now:</strong> Go to your login page and use the credentials above</li>";
            echo "<li><strong>Reset Original Password:</strong> Once logged in, go to IT Admin → Users and reset your original IT admin password</li>";
            echo "<li><strong>DELETE THIS FILE:</strong> For security, delete <code>create_emergency_admin.php</code> from your server immediately!</li>";
            echo "</ol>";
            echo "</div>";
            
            echo "<a href='../LOGIN/login.html' class='btn'>Go to Login Page →</a>";
            
        } else {
            echo "<div class='error'>❌ Failed to create user: " . $stmt->error . "</div>";
        }
        
        $stmt->close();
    }
    
} else {
    // Show the form
    echo "<div class='warning'>";
    echo "<strong>⚠️ Warning:</strong> This file creates an IT admin account without authentication. ";
    echo "Delete this file immediately after creating the account!";
    echo "</div>";
    
    echo "<h2>Account Details</h2>";
    echo "<table style='width: 100%; margin: 20px 0;'>";
    echo "<tr><td style='padding: 8px; font-weight: bold;'>Email:</td><td style='padding: 8px;'><code>$new_username</code></td></tr>";
    echo "<tr><td style='padding: 8px; font-weight: bold;'>Password:</td><td style='padding: 8px;'><code>$new_password</code></td></tr>";
    echo "<tr><td style='padding: 8px; font-weight: bold;'>Full Name:</td><td style='padding: 8px;'>$new_full_name</td></tr>";
    echo "<tr><td style='padding: 8px; font-weight: bold;'>Role:</td><td style='padding: 8px;'>$new_role</td></tr>";
    echo "<tr><td style='padding: 8px; font-weight: bold;'>Terminal:</td><td style='padding: 8px;'>$new_terminal</td></tr>";
    echo "</table>";
    
    echo "<div class='info'>";
    echo "<strong>💡 Tip:</strong> If you want to change these details, edit lines 9-13 in this PHP file.";
    echo "</div>";
    
    echo "<form method='POST'>";
    echo "<button type='submit' name='create_account' class='btn'>Create IT Admin Account</button>";
    echo "</form>";
    
    echo "<hr style='margin: 30px 0;'>";
    
    echo "<h3>After Creating the Account:</h3>";
    echo "<ol>";
    echo "<li>Click the button above to create the account</li>";
    echo "<li>Login with the credentials shown</li>";
    echo "<li>Reset your original IT admin password via the dashboard</li>";
    echo "<li><strong>DELETE THIS FILE from your server!</strong></li>";
    echo "</ol>";
}

echo "</div></body></html>";

$mysqli->close();
?>