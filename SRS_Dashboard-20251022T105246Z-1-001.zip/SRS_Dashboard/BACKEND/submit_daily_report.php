<?php
// submit_daily_report.php - Handle daily report submission with images

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $user_id = $_SESSION['user_id'];
    
    // Get form data
    $report_date = $_POST['report_date'] ?? '';
    $shift = $_POST['shift'] ?? '';
    $team = $_POST['team'] ?? '';
    
    // Personnel data
    $screeners_on_duty = intval($_POST['screeners_on_duty'] ?? 0);
    $screeners_off = intval($_POST['screeners_off'] ?? 0);
    $screeners_on_leave = intval($_POST['screeners_on_leave'] ?? 0);
    $screeners_absent = intval($_POST['screeners_absent'] ?? 0);
    
    // Domestic flights
    $domestic_departing_flights = intval($_POST['domestic_departing_flights'] ?? 0);
    $domestic_passengers = intval($_POST['domestic_passengers'] ?? 0);
    $domestic_cancelled_flights = intval($_POST['domestic_cancelled_flights'] ?? 0);
    $domestic_affected_passengers = intval($_POST['domestic_affected_passengers'] ?? 0);
    
    // International flights
    $international_departing_flights = intval($_POST['international_departing_flights'] ?? 0);
    $international_passengers = intval($_POST['international_passengers'] ?? 0);
    $international_cancelled_flights = intval($_POST['international_cancelled_flights'] ?? 0);
    $international_affected_passengers = intval($_POST['international_affected_passengers'] ?? 0);
    
    // Prohibited items
    $blunt_instruments = intval($_POST['blunt_instruments'] ?? 0);
    $liquid_aerosols_gels = intval($_POST['liquid_aerosols_gels'] ?? 0);
    $sharp_objects = intval($_POST['sharp_objects'] ?? 0);
    $workers_tools = intval($_POST['workers_tools'] ?? 0);
    $explosives_incendiary = intval($_POST['explosives_incendiary'] ?? 0);
    $stunning_devices = intval($_POST['stunning_devices'] ?? 0);
    $chemical_toxic = intval($_POST['chemical_toxic'] ?? 0);
    
    $additional_notes = trim($_POST['additional_notes'] ?? '');
    
    // Validate required fields
        if (empty($report_date) || empty($shift) || empty($team)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Date, shift, and team are required']);
            exit();
        }

        // Validate personnel data (all required)
        if ($screeners_on_duty < 0 || $screeners_off < 0 || $screeners_on_leave < 0 || $screeners_absent < 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'All personnel data fields are required and must be 0 or greater']);
            exit();
        }
    
    // Handle image uploads
    $uploaded_images = [];
    $upload_dir = '../uploads/daily_reports/';
    
    // Create directory if it doesn't exist
    if (!file_exists($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    // Process up to 4 images
    for ($i = 1; $i <= 4; $i++) {
        $file_key = "report_image_" . $i;
        
        if (isset($_FILES[$file_key]) && $_FILES[$file_key]['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES[$file_key];
            
            // Validate file type
            $allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
            if (!in_array($file['type'], $allowed_types)) {
                continue; // Skip invalid file types
            }
            
            // Validate file size (max 5MB)
            if ($file['size'] > 5 * 1024 * 1024) {
                continue; // Skip files larger than 5MB
            }
            
            // Generate unique filename
            $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
            $filename = 'daily_' . $user_id . '_' . time() . '_' . $i . '.' . $extension;
            $filepath = $upload_dir . $filename;
            
            // Move uploaded file
            if (move_uploaded_file($file['tmp_name'], $filepath)) {
                $uploaded_images[$i] = $filename;
            }
        }
    }
    
    // Validate image count (2-4 required)
    if (count($uploaded_images) < 2 || count($uploaded_images) > 4) {
        // Delete any uploaded images if validation fails
        foreach ($uploaded_images as $img) {
            if (file_exists($upload_dir . $img)) {
                unlink($upload_dir . $img);
            }
        }
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Please upload between 2-4 images']);
        exit();
    }

    // Get image filenames (or null if not uploaded)
    $image1 = $uploaded_images[1] ?? null;
    $image2 = $uploaded_images[2] ?? null;
    $image3 = $uploaded_images[3] ?? null;
    $image4 = $uploaded_images[4] ?? null;
    
    // Prepare SQL with image fields
    $stmt = $mysqli->prepare("
        INSERT INTO daily_reports (
            user_id, report_date, shift, team,
            screeners_on_duty, screeners_off, screeners_on_leave, screeners_absent,
            domestic_departing_flights, domestic_passengers, domestic_cancelled_flights, domestic_affected_passengers,
            international_departing_flights, international_passengers, international_cancelled_flights, international_affected_passengers,
            blunt_instruments, liquid_aerosols_gels, sharp_objects, workers_tools, 
            explosives_incendiary, stunning_devices, chemical_toxic,
            additional_notes, 
            image1, image2, image3, image4,
            status
        ) VALUES (
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?,
            ?, 
            ?, ?, ?, ?,
            'submitted'
        )
    ");
    
    if ($stmt) {
        $stmt->bind_param(
            "isssiiiiiiiiiiiiiiiiiiiissss",
            $user_id, $report_date, $shift, $team,
            $screeners_on_duty, $screeners_off, $screeners_on_leave, $screeners_absent,
            $domestic_departing_flights, $domestic_passengers, $domestic_cancelled_flights, $domestic_affected_passengers,
            $international_departing_flights, $international_passengers, $international_cancelled_flights, $international_affected_passengers,
            $blunt_instruments, $liquid_aerosols_gels, $sharp_objects, $workers_tools,
            $explosives_incendiary, $stunning_devices, $chemical_toxic,
            $additional_notes,
            $image1, $image2, $image3, $image4
        );
        
        if ($stmt->execute()) {
            $report_id = $stmt->insert_id;
            echo json_encode([
                'success' => true, 
                'message' => 'Daily report submitted successfully',
                'report_id' => $report_id,
                'images_uploaded' => count($uploaded_images)
            ]);
        } else {
            // Delete uploaded images if database insert fails
            foreach ($uploaded_images as $img) {
                if (file_exists($upload_dir . $img)) {
                    unlink($upload_dir . $img);
                }
            }
            
            http_response_code(500);
            echo json_encode(['success' => false, 'message' => 'Error saving report: ' . $stmt->error]);
        }
        
        $stmt->close();
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Database error']);
    }
    
} else {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}

$mysqli->close();
?>