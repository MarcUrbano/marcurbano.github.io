<?php
// generate_report_pdf.php - Generate PDF reports using FPDF

date_default_timezone_set('Asia/Manila');

session_start();

// Check if user is logged in
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    die('Unauthorized access');
}

// Check if user has permission (admin, executive, or superAdmin)
$allowed_roles = ['admin', 'executive', 'it_admin', 'sso', 'supervisor'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    die('Access denied');
}

require_once 'db.php';

// Get parameters
$report_id = intval($_GET['report_id'] ?? 0);
$report_type = $_GET['report_type'] ?? '';

if (!$report_id || !in_array($report_type, ['daily', 'interception'])) {
    die('Invalid parameters');
}

// Fetch report details
if ($report_type === 'daily') {
    $stmt = $mysqli->prepare("
        SELECT dr.*, u.username 
        FROM daily_reports dr
        JOIN users u ON dr.user_id = u.id
        WHERE dr.id = ?
    ");
    $stmt->bind_param("i", $report_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $report = $result->fetch_assoc();
    $stmt->close();
} else {
    $stmt = $mysqli->prepare("
        SELECT ir.*, u.username 
        FROM interception_reports ir
        JOIN users u ON ir.user_id = u.id
        WHERE ir.id = ?
    ");
    $stmt->bind_param("i", $report_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $report = $result->fetch_assoc();
    $stmt->close();
}

if (!$report) {
    die('Report not found');
}

$mysqli->close();

// Simple HTML to PDF conversion (since FPDF requires installation)
// This creates a styled HTML page that can be printed to PDF by the browser

header('Content-Type: text/html; charset=utf-8');

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $report_type === 'daily' ? 'Daily Report' : 'Interception Report'; ?> - <?php echo $report_id; ?></title>
    <style>
        @media print {
            body { margin: 0; }
            .no-print { display: none; }
            @page { size: A4; margin: 1cm; }
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #fff;
            padding: 20px;
        }
        
        .pdf-container {
            max-width: 800px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        
        .header {
            text-align: center;
            border-bottom: 3px solid #313893;
            padding-bottom: 20px;
            margin-bottom: 30px;
        }
        
        .header img {
            width: 80px;
            height: 80px;
            margin-bottom: 10px;
        }
        
        .header h1 {
            color: #313893;
            font-size: 24px;
            margin: 10px 0;
        }
        
        .header h2 {
            color: #666;
            font-size: 18px;
            font-weight: normal;
        }
        
        .report-id {
            background: #f5f5f5;
            padding: 10px;
            border-radius: 5px;
            text-align: center;
            margin-bottom: 20px;
            font-weight: bold;
        }
        
        .section {
            margin-bottom: 25px;
            page-break-inside: avoid;
        }
        
        .section-title {
            background: #313893;
            color: white;
            padding: 10px 15px;
            font-size: 16px;
            font-weight: bold;
            border-radius: 5px 5px 0 0;
        }
        
        .section-content {
            border: 1px solid #ddd;
            border-top: none;
            padding: 15px;
            border-radius: 0 0 5px 5px;
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        
        .info-item {
            padding: 10px;
            background: #f9f9f9;
            border-radius: 5px;
        }
        
        .info-label {
            font-weight: bold;
            color: #313893;
            font-size: 12px;
            margin-bottom: 5px;
        }
        
        .info-value {
            color: #333;
            font-size: 14px;
        }
        
        .full-width {
            grid-column: 1 / -1;
        }
        
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
        
        .status-submitted {
            background: #ffc107;
            color: #000;
        }
        
        .status-approved {
            background: #28a745;
            color: white;
        }
        
        .status-under-review {
            background: #17a2b8;
            color: white;
        }
        
        .footer {
            margin-top: 40px;
            padding-top: 20px;
            border-top: 2px solid #ddd;
            text-align: center;
            color: #666;
            font-size: 12px;
        }
        
        .print-button {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #313893;
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            transition: all 0.3s ease;
        }
        
        .print-button:hover {
            background: #252a6b;
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,0,0,0.15);
        }
        
        @media print {
            .print-button { display: none; }
        }
    </style>
    <script>
        window.onload = function() {
            // Auto-print dialog when page loads (optional)
            // setTimeout(() => window.print(), 500);
        };
        
        function printReport() {
            window.print();
        }
    </script>
</head>
<body>
    <button class="print-button no-print" onclick="printReport()">
        🖨️ Print / Save as PDF
    </button>
    
    <div class="pdf-container">
        <!-- Header -->
        <div class="header">
            <h1>OFFICE FOR TRANSPORTATION SECURITY</h1>
            <h2>NAIA Terminal 1</h2>
            <h2><?php echo $report_type === 'daily' ? 'Daily Report' : 'Interception Report'; ?></h2>
        </div>
        
        <!-- Report ID -->
        <div class="report-id">
            Report ID: <?php echo $report_type === 'daily' ? 'DR-' : 'IR-'; ?><?php echo $report_id; ?>
        </div>
        
        <?php if ($report_type === 'daily'): ?>
            <!-- Daily Report Content -->
            <div class="section">
                <div class="section-title">Report Information</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Date</div>
                            <div class="info-value"><?php echo date('F d, Y', strtotime($report['report_date'])); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Shift</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['shift']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Team</div>
                            <div class="info-value">Team <?php echo htmlspecialchars($report['team']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Status</div>
                            <div class="info-value">
                                <span class="status-badge status-<?php echo $report['status']; ?>">
                                    <?php echo ucfirst($report['status']); ?>
                                </span>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Submitted By</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['username']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Submitted On</div>
                            <div class="info-value"><?php echo date('F d, Y g:i A', strtotime($report['created_at'])); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Personnel Data</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Screeners On Duty</div>
                            <div class="info-value"><?php echo $report['screeners_on_duty']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Screeners Off</div>
                            <div class="info-value"><?php echo $report['screeners_off']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Screeners On Leave</div>
                            <div class="info-value"><?php echo $report['screeners_on_leave']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Screeners Absent</div>
                            <div class="info-value"><?php echo $report['screeners_absent']; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Flight Summary</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Domestic Departing Flights</div>
                            <div class="info-value"><?php echo $report['domestic_departing_flights']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Domestic Passengers</div>
                            <div class="info-value"><?php echo $report['domestic_passengers']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">International Departing Flights</div>
                            <div class="info-value"><?php echo $report['international_departing_flights']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">International Passengers</div>
                            <div class="info-value"><?php echo $report['international_passengers']; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Prohibited Items Intercepted</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Blunt Instruments</div>
                            <div class="info-value"><?php echo $report['blunt_instruments']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Sharp Objects</div>
                            <div class="info-value"><?php echo $report['sharp_objects']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Liquid/Aerosols/Gels</div>
                            <div class="info-value"><?php echo $report['liquid_aerosols_gels']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Workers Tools</div>
                            <div class="info-value"><?php echo $report['workers_tools']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Explosives/Incendiary</div>
                            <div class="info-value"><?php echo $report['explosives_incendiary']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Stunning Devices</div>
                            <div class="info-value"><?php echo $report['stunning_devices']; ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Chemical/Toxic</div>
                            <div class="info-value"><?php echo $report['chemical_toxic']; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($report['additional_notes'])): ?>
            <div class="section">
                <div class="section-title">Additional Notes</div>
                <div class="section-content">
                    <div class="info-item full-width">
                        <div class="info-value"><?php echo nl2br(htmlspecialchars($report['additional_notes'])); ?></div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
        <?php else: ?>
            <!-- Interception Report Content -->
            <div class="section">
                <div class="section-title">Report Information</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Date</div>
                            <div class="info-value"><?php echo date('F d, Y', strtotime($report['report_date'])); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Shift</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['shift']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Team</div>
                            <div class="info-value">Team <?php echo htmlspecialchars($report['team']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Status</div>
                            <div class="info-value">
                                <span class="status-badge status-<?php echo $report['status']; ?>">
                                    <?php echo ucfirst($report['status']); ?>
                                </span>
                            </div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Submitted By</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['username']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Submitted On</div>
                            <div class="info-value"><?php echo date('F d, Y g:i A', strtotime($report['created_at'])); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Passenger Information</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Passenger Name</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['passenger_name']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Occupation</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['occupation']); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Flight Details</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Flight Number</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['flight_number']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Destination</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['destination'] ?: 'N/A'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="section">
                <div class="section-title">Intercepted Item Details</div>
                <div class="section-content">
                    <div class="info-grid">
                        <div class="info-item">
                            <div class="info-label">Intercepted Item</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['intercepted_item']); ?></div>
                        </div>
                        <div class="info-item">
                            <div class="info-label">Quantity</div>
                            <div class="info-value"><?php echo $report['quantity']; ?></div>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($report['xray_operator']) || !empty($report['baggage_pusher'])): ?>
            <div class="section">
                <div class="section-title">Intercepted By</div>
                <div class="section-content">
                    <div class="info-grid">
                        <?php if (!empty($report['xray_operator'])): ?>
                        <div class="info-item">
                            <div class="info-label">X-ray Operator</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['xray_operator']); ?></div>
                        </div>
                        <?php endif; ?>
                        
                        <?php if (!empty($report['baggage_pusher'])): ?>
                        <div class="info-item">
                            <div class="info-label">Baggage Inspector</div>
                            <div class="info-value"><?php echo htmlspecialchars($report['baggage_pusher']); ?></div>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($report['remarks'])): ?>
            <div class="section">
                <div class="section-title">Remarks</div>
                <div class="section-content">
                    <div class="info-item full-width">
                        <div class="info-value"><?php echo nl2br(htmlspecialchars($report['remarks'])); ?></div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        <?php endif; ?>
        
        <!-- Footer -->
        <div class="footer">
            <p><strong>Office for Transportation Security - NAIA Terminal 1</strong></p>
            <p>Generated on <?php echo date('F d, Y g:i A'); ?></p>
            <p>This is a computer-generated report and requires no signature for validity.</p>
        </div>
    </div>
</body>
</html>