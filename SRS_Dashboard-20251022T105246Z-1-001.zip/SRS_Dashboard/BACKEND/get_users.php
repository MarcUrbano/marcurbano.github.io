<?php
// Prevent any output before JSON
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);

session_start();

header('Content-Type: application/json');

// Check authentication
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin or Executive
if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['it_admin', 'executive'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied. Role: ' . ($_SESSION['role'] ?? 'none')]);
    exit();
}

require_once 'db.php';

$terminal = $_GET['terminal'] ?? '';

if (empty($terminal)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Terminal parameter required']);
    exit();
}

try {
    // Check if we're fetching executive/it_admin users
    if ($terminal === 'executive_itadmin') {
        // Get all executives and IT admins regardless of terminal
        $stmt = $mysqli->prepare("
            SELECT 
                u.id,
                u.username,
                u.full_name,
                u.role,
                u.terminal_assignment,
                u.created_at,
                u.updated_at
            FROM users u
            WHERE u.role IN ('executive', 'it_admin')
            ORDER BY u.created_at DESC
        ");
        
        if (!$stmt) {
            throw new Exception('Prepare failed: ' . $mysqli->error);
        }
        
        if (!$stmt->execute()) {
            throw new Exception('Execute failed: ' . $stmt->error);
        }
    } else {
        // Get users for the specified terminal (only user and admin roles)
        $stmt = $mysqli->prepare("
            SELECT 
                u.id,
                u.username,
                u.full_name,
                u.role,
                u.terminal_assignment,
                u.created_at,
                u.updated_at
            FROM users u
            WHERE u.terminal_assignment = ?
            AND u.role IN ('user', 'admin')
            ORDER BY u.created_at DESC
        ");
        
        if (!$stmt) {
            throw new Exception('Prepare failed: ' . $mysqli->error);
        }
        
        $stmt->bind_param("s", $terminal);
        
        if (!$stmt->execute()) {
            throw new Exception('Execute failed: ' . $stmt->error);
        }
    }
    
    $result = $stmt->get_result();
    $users = [];
    
    while ($row = $result->fetch_assoc()) {
        // Get report count for this user
        $reportStmt = $mysqli->prepare("
            SELECT 
                COALESCE((SELECT COUNT(*) FROM daily_reports WHERE user_id = ?), 0) +
                COALESCE((SELECT COUNT(*) FROM interception_reports WHERE user_id = ?), 0) as total_reports
        ");
        
        if (!$reportStmt) {
            // If report tables don't exist, set reports to 0
            $total_reports = 0;
        } else {
            $reportStmt->bind_param("ii", $row['id'], $row['id']);
            $reportStmt->execute();
            $reportResult = $reportStmt->get_result();
            $reportRow = $reportResult->fetch_assoc();
            $total_reports = (int)$reportRow['total_reports'];
            $reportStmt->close();
        }
        
        // Get last activity
        $last_activity = null;
        $activityStmt = $mysqli->prepare("
            SELECT created_at FROM daily_reports WHERE user_id = ?
            UNION ALL
            SELECT created_at FROM interception_reports WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 1
        ");
        
        if ($activityStmt) {
            $activityStmt->bind_param("ii", $row['id'], $row['id']);
            $activityStmt->execute();
            $activityResult = $activityStmt->get_result();
            if ($activityRow = $activityResult->fetch_assoc()) {
                $last_activity = $activityRow['created_at'];
            }
            $activityStmt->close();
        }
        
        $users[] = [
            'id' => $row['id'],
            'username' => $row['username'],
            'full_name' => $row['full_name'],
            'role' => $row['role'],
            'terminal_assignment' => $row['terminal_assignment'],
            'created_at' => $row['created_at'],
            'updated_at' => $row['updated_at'],
            'total_reports' => $total_reports,
            'last_activity' => $last_activity
        ];
    }
    
    $stmt->close();
    
    echo json_encode([
        'success' => true,
        'users' => $users
    ]);
    
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}

$mysqli->close();
?>