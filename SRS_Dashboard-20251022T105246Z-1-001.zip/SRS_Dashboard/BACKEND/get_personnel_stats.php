<?php
// get_personnel_stats.php - Get personnel stats for a specific terminal

date_default_timezone_set('Asia/Manila');
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user has admin, executive, or it_admin role
$allowed_roles = ['admin', 'executive', 'it_admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Get user's terminal assignment and role
$user_terminal = $_SESSION['terminal_assignment'];
$user_role = $_SESSION['role'];

// Get personnel stats for the terminal
if (in_array($user_role, ['executive', 'it_admin'])) {
    // Executive and IT Admin can choose which terminal to view
    $terminal = $_GET['terminal'] ?? $user_terminal;
} else {
    // Admin can only see their own terminal
    $terminal = $user_terminal;
}

// Get count of users in this terminal
$stmt = $mysqli->prepare("
    SELECT 
        COUNT(*) as total_users,
        SUM(CASE WHEN role = 'admin' THEN 1 ELSE 0 END) as admin_count,
        SUM(CASE WHEN role = 'user' THEN 1 ELSE 0 END) as user_count
    FROM users
    WHERE terminal_assignment = ? AND role IN ('admin', 'user')
");

if ($stmt) {
    $stmt->bind_param("s", $terminal);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        echo json_encode([
            'success' => true,
            'terminal' => $terminal,
            'stats' => [
                'total_users' => (int)$row['total_users'],
                'admin_count' => (int)$row['admin_count'],
                'user_count' => (int)$row['user_count']
            ]
        ]);
    } else {
        echo json_encode([
            'success' => true,
            'terminal' => $terminal,
            'stats' => [
                'total_users' => 0,
                'admin_count' => 0,
                'user_count' => 0
            ]
        ]);
    }
    
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>