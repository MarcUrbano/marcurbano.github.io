<?php
// get_all_daily_reports.php - Fetch all daily reports for admin/executive

date_default_timezone_set('Asia/Manila');

session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user has admin, executive, or superAdmin role
$allowed_roles = ['admin', 'executive', 'it_admin'];
if (!in_array($_SESSION['role'], $allowed_roles)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';

// Determine which reports to show based on role
$user_role = $_SESSION['role'];
$user_terminal = $_SESSION['terminal_assignment'];

// Get daily reports with user information - filtered by terminal for regular admins
if ($user_role === 'admin') {
    // Admin can only see reports from users in their same terminal
    
    // For admin role query:
    $stmt = $mysqli->prepare("
        SELECT 
            dr.id, dr.report_date, dr.shift, dr.team, dr.status, dr.created_at,
            dr.screeners_on_duty, dr.domestic_departing_flights, dr.international_departing_flights,
            dr.blunt_instruments, dr.liquid_aerosols_gels, dr.sharp_objects,
            u.username, u.id as user_id, u.terminal_assignment
        FROM daily_reports dr
        JOIN users u ON dr.user_id = u.id
        WHERE u.terminal_assignment = ?
        ORDER BY dr.created_at DESC 
        LIMIT 100
    ");

    $stmt->bind_param("s", $user_terminal);
} else {
    
    // Executive and IT Admin can see all reports
$stmt = $mysqli->prepare("
    SELECT 
        dr.id, dr.report_date, dr.shift, dr.team, dr.status, dr.created_at,
        dr.screeners_on_duty, dr.domestic_departing_flights, dr.international_departing_flights,
        dr.blunt_instruments, dr.liquid_aerosols_gels, dr.sharp_objects,
        u.username, u.id as user_id, u.terminal_assignment
    FROM daily_reports dr
    JOIN users u ON dr.user_id = u.id
    ORDER BY dr.created_at DESC 
    LIMIT 100
");
}

if ($stmt) {
    // Execute the query for all roles
    $stmt->execute();
    
    // Get results
    $result = $stmt->get_result();
    
    $reports = [];
    while ($row = $result->fetch_assoc()) {
        // Calculate if report is still editable (24 hours)
        $created_time = strtotime($row['created_at']);
        $current_time = time();
        $hours_elapsed = ($current_time - $created_time) / 3600;
        $row['can_edit'] = $hours_elapsed < 24;
        $row['hours_remaining'] = max(0, 24 - $hours_elapsed);
        
        $reports[] = $row;
    }
    
    echo json_encode(['success' => true, 'reports' => $reports]);
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>