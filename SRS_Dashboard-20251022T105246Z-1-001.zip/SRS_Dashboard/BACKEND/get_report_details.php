<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

require_once 'db.php';

$report_id = intval($_GET['report_id'] ?? 0);
$report_type = $_GET['report_type'] ?? 'daily';
$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role']; // Get the user's role

if ($report_id <= 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid report ID']);
    exit();
}

// Check if user is admin/executive/superAdmin
$is_privileged = in_array($user_role, ['admin', 'executive', 'it_admin']);

if ($report_type === 'daily') {
    if ($is_privileged) {
        // Admins can view any report
        $stmt = $mysqli->prepare("
            SELECT dr.*, u.username 
            FROM daily_reports dr
            JOIN users u ON dr.user_id = u.id
            WHERE dr.id = ?
        ");
        $stmt->bind_param("i", $report_id);
    } else {
        // Regular users can only view their own reports
        $stmt = $mysqli->prepare("
            SELECT * FROM daily_reports 
            WHERE id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $report_id, $user_id);
    }
} else {
    if ($is_privileged) {
        // Admins can view any interception report
        $stmt = $mysqli->prepare("
            SELECT ir.*, u.username 
            FROM interception_reports ir
            JOIN users u ON ir.user_id = u.id
            WHERE ir.id = ?
        ");
        $stmt->bind_param("i", $report_id);
    } else {
        // Regular users can only view their own reports
        $stmt = $mysqli->prepare("
            SELECT * FROM interception_reports 
            WHERE id = ? AND user_id = ?
        ");
        $stmt->bind_param("ii", $report_id, $user_id);
    }
}

if ($stmt) {
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $report = $result->fetch_assoc();
        
        // Check if editable
        $created_time = strtotime($report['created_at']);
        $hours_elapsed = (time() - $created_time) / 3600;
        $report['can_edit'] = $hours_elapsed < 24;
        $report['hours_remaining'] = max(0, 24 - $hours_elapsed);
        
        echo json_encode(['success' => true, 'report' => $report]);
    } else {
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'Report not found']);
    }
    $stmt->close();
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error']);
}

$mysqli->close();
?>