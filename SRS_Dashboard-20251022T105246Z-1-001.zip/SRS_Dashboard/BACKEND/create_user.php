<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Check if user is IT Admin
if ($_SESSION['role'] !== 'it_admin') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Access denied']);
    exit();
}

require_once 'db.php';
require_once 'log_it_admin_action.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

$username = trim($input['username'] ?? '');
$password = $input['password'] ?? '';
$full_name = trim($input['full_name'] ?? '');
$role = $input['role'] ?? '';
$terminal_assignment = $input['terminal_assignment'] ?? '';

// Validate inputs
if (empty($username) || empty($password) || empty($role) || empty($terminal_assignment)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'All fields are required']);
    exit();
}

// Validate email format
if (!filter_var($username, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid email format']);
    exit();
}

// Validate role
$allowed_roles = ['user', 'admin', 'executive', 'it_admin'];
if (!in_array($role, $allowed_roles)) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid role']);
    exit();
}

// Check if username already exists
$checkStmt = $mysqli->prepare("SELECT id FROM users WHERE username = ?");
$checkStmt->bind_param("s", $username);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows > 0) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email already exists']);
    $checkStmt->close();
    $mysqli->close();
    exit();
}
$checkStmt->close();

// Hash password
$password_hash = password_hash($password, PASSWORD_DEFAULT);

// Insert new user
$stmt = $mysqli->prepare("
    INSERT INTO users (username, password_hash, role, terminal_assignment, full_name, created_at, updated_at)
    VALUES (?, ?, ?, ?, ?, NOW(), NOW())
");

$stmt->bind_param("sssss", $username, $password_hash, $role, $terminal_assignment, $full_name);

if ($stmt->execute()) {
    $new_user_id = $mysqli->insert_id;
    
    // Log IT admin action
    $it_admin_id = $_SESSION['user_id'];
    $it_admin_name = $_SESSION['username'] ?? 'Unknown IT Admin';
    $description = "Created new user: {$username} (Role: {$role}, Full Name: {$full_name})";
    logITAdminAction($mysqli, $it_admin_id, $it_admin_name, 'Add User', $description);
    
    echo json_encode([
        'success' => true,
        'message' => 'User created successfully',
        'user_id' => $new_user_id
    ]);
} else {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Failed to create user']);
}

$stmt->close();
$mysqli->close();
?>