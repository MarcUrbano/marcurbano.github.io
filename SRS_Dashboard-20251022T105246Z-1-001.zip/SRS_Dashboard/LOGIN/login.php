<?php
// login.php - Handle login authentication


session_start();

// Regenerate session ID to prevent session fixation
session_regenerate_id(true);

// Include database connection
require_once '../BACKEND/db.php';

// Initialize error message
$error_message = '';

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Get and sanitize input
    $email = trim($_POST['name'] ?? '');
    $password = $_POST['password'] ?? '';
    
    // Validate inputs
    if (empty($email) || empty($password)) {
        $error_message = 'Please enter both email and password';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = 'Please enter a valid email address';
    } else {
        
        // Prepare statement to prevent SQL injection
        $stmt = $mysqli->prepare("SELECT id, username, password_hash, role, full_name, terminal_assignment FROM users WHERE username = ? LIMIT 1");
        
        if ($stmt) {
            // Bind parameters
            $stmt->bind_param("s", $email);
            
            // Execute query
            $stmt->execute();
            
            // Get result
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                // User found
                $user = $result->fetch_assoc();
                
                // Verify password
                if (password_verify($password, $user['password_hash'])) {
                    // Password correct - Login successful
                    
                    // Regenerate session ID for security
                    session_regenerate_id(true);
                    
                    // Store user data in session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['full_name'] = $user['full_name'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['terminal_assignment'] = $user['terminal_assignment'];  // ADD THIS LINE
                    $_SESSION['logged_in'] = true;
                    $_SESSION['login_time'] = time();
                    
                    // Redirect based on role - FIXED PATHS
                    switch ($user['role']) {
                        case 'user':
                            header('Location: ../ACCOUNTS/user.php');
                            exit();
                        case 'admin':
                            header('Location: ../ACCOUNTS/admin.php');
                            exit();
                        case 'executive':
                            header('Location: ../ACCOUNTS/executive.php');
                            exit();
                        case 'it_admin':
                            header('Location: ../ACCOUNTS/it_admin.php');
                            exit();
                        default:
                            $error_message = 'Invalid user role';
                    }
                } else {
                    // Password incorrect
                    $error_message = 'Invalid email or password';
                }
            } else {
                // User not found
                $error_message = 'Invalid email or password';
            }
            
            // Close statement
            $stmt->close();
        } else {
            $error_message = 'Database error occurred';
        }
    }
    
    // If we reach here, login failed
    if (!empty($error_message)) {
        $_SESSION['login_error'] = $error_message;
        header('Location: login.html?error=1');
        exit();
    }
}

// If accessed directly without POST, redirect to login page
header('Location: login.html');
exit();

?>